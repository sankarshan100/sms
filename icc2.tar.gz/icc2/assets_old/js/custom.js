$(document).ready(function() {
  function setHeight() {
    windowHeight = $(window).innerHeight();
    $('.rightsec').css('min-height', windowHeight);
  };
  setHeight();
  
  $(window).resize(function() {
    setHeight();
  });
});


$(document).ready(function() {
	$('.AddBtn').click( function(){
		$('.MainPopUp').fadeIn();
	});
	$('.close_icon').click( function(){
		$('.MainPopUp').fadeOut();
	});

	$('.blockBtn').click( function(){
		$(this).parent().find('.MainPopUp').fadeIn();
	});
        $('.noBtn').click( function(){
		$('.MainPopUp').fadeOut();
	});

});

$(document).ready(function() {
	$('.EditBtn').click( function(){
		$('.EditPopUp').fadeIn();
	});
	$('.close_icon').click( function(){
		$('.EditPopUp').fadeOut();
	});

});
$(document).ready(function() {
    $('#datatable').DataTable();
} );