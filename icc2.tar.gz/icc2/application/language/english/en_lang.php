<?php

// webservices
$lang['invalid_json']               =   'Invalid Json';
$lang['verification_code_sent']     =   "You've Successfully Send Verification Code on mobile no";
$lang['mobile_exist']               =   "User already exist";
$lang['verification_correct']       =   "Verification Code is Correct";
$lang['verification_incorrect']     =   "Verification Code is Incorrect";
$lang['email_exist']                =   "Phone Already Exists";
$lang['user_register']              =   "User Successfully registered";
$lang['invalid_token']              =   "Invalid Token";
$lang['home_page']                  =   "Home page feeds";
$lang['invalid_credential']         =   "Invalid credentials";
$lang['group_add']                  =   "Group added successfully";
$lang['video_add']                  =   "Video uploaded successfully";
$lang['channel_add']                =   "Channel added successfully";
$lang['group_feed']                 =   "Group Feeds";
$lang['channels']                   =   "Channels List";    
$lang['video_added_profile']        =   "Video added to your profile successfully";
$lang['category_list']              =   "Category list";
$lang['video_page_details']         =   "Video page details found";
$lang['user_friend_list']           =   "User friend list";
$lang['profiling']                  =   "Profiling list";
$lang['group_not_exist']            =   "Group does not exist";
$lang['no_member']                  =   "There is no member in this group";
$lang['no_group_feed']              =   "There is no group";
$lang['member_already']             =   "The user is already the member of this group";
$lang['member_add']                 =   "Member added successfully";
$lang['member_delete']              =   "Member deleted successfully";
$lang['not_member']                 =   "The user is not the member of the group";
$lang['leave_group']                =   "You have successfully left the group";
$lang['block_group']                =   "Group blocked successfully";
$lang['already_subscribe']          =   "You have already subscribed to the channel";
$lang['subscribe']                  =   "Channel subscribed successfully";
$lang['unsubscribe']                =   "Channel Unsubscribed  successfully";
$lang['not_subscribed']             =   "Channel not subscribed";
$lang['left_group']                 =   "You have left the group successfully";
$lang['block_group']                =   "Group blocked successfully";
$lang['store_list']                 =   "Stores List";
$lang['store_list_not_found']       =   "No stores found";
$lang['update_profile']             =   "Profile updated successfully";
$lang['my_profile']                 =   "User profile details";
$lang['logout']                     =   "User logout successfully";
$lang['professional_list']          =   "Professional List";
$lang['service_list']               =   "Service List";
$lang['forgot']               		=   "Password has been mailed to you.";
?>

