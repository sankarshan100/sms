<?php

defined('BASEPATH') OR exit('No direct script access allowed');

/*
  | -------------------------------------------------------------------------
  | URI ROUTING
  | -------------------------------------------------------------------------
  | This file lets you re-map URI requests to specific controller functions.
  |
  | Typically there is a one-to-one relationship between a URL string
  | and its corresponding controller class/method. The segments in a
  | URL normally follow this pattern:
  |
  | example.com/class/method/id/
  |
  | In some instances, however, you may want to remap this relationship
  | so that a different class/function is called than the one
  | corresponding to the URL.
  |
  | Please see the user guide for complete details:
  | 
  | http://codeigniter.com/user_guide/general/routing.html
  |
  | -------------------------------------------------------------------------
  | RESERVED ROUTES
  | -------------------------------------------------------------------------
  |
  | There are three reserved routes:
  |
  | $route['default_controller'] = 'welcome';
  |
  | This route indicates which controller class should be loaded if the
  | URI contains no data. In the above example, the "welcome" class
  | would be loaded.
  |
  | $route['404_override'] = 'errors/page_missing';
  |
  | This route will tell the Router which controller/method to use if those
  | provided in the URL cannot be matched to a valid route.
  |
  | $route['translate_uri_dashes'] = FALSE;
  |
  | This is not exactly a route, but allows you to automatically route
  | controller and method names that contain dashes. '-' isn't a valid
  | class or method name character, so it requires translation.
  | When you set this option to TRUE, it will replace ALL dashes in the
  | controller and method URI segments.
  |
  | Examples: my-controller/index -> my_controller/index
  |   my-controller/my-method -> my_controller/my_method
 */


/* Admin routing starts */
$route['admin']                = "admin/Index/login";
$route['dashboard']            = "admin/Index/dashboard";
$route['forgotPassword']       = "admin/Index/forgotPassword";
$route['userForgotPassword']   = "admin/Index/userForgotPassword";


/*User Sectio*/
$route['manage_users']         = "admin/User/manageUsers";
$route['edit_user']            = "admin/User/editUser";
$route['send_notification']    = "admin/User/sendNotification";
$route['extend_trail_period']  = "admin/User/extendTrailPeriod";
$route['view_user_detail']     = "admin/User/getUserDetail";
$route['delete_user']          = "admin/User/deleteUser";

/*Store Section*/
$route['manage_stores']         = "admin/Store/manageStores";
$route['view_store_detail']     = "admin/Store/getStoreDetail";
$route['edit_store']            = "admin/Store/editStore";
$route['delete_store']          = "admin/Store/deleteStore";


/* Feedback management */
$route['manage_feedbacks']      = "admin/Feedback/manageFeedbacks";
$route['reply_feedback']      = "admin/Feedback/replyFeedback";
$route['delete_feedback']       = "admin/Feedback/deleteFeedback";


/*Services Section*/
$route['manage_services']         = "admin/Service/manageServices";
$route['view_service_detail']     = "admin/Service/getServiceDetail";
$route['delete_service']          = "admin/Service/deleteService";

/*Appontment Section*/
$route['manage_appointments']      = "admin/Store/manageAppointments";
$route['update_status']      = "admin/Store/updateStatus";


/* Web SERVICES */

// Login webservices
$route['registration1'] = 'webservices/LoginController/registration1';
$route['registration'] = 'webservices/LoginController/registration';
$route['login'] = 'webservices/LoginController/login';
$route['verify_phone'] = 'webservices/LoginController/verify_phone';
$route['verify_code'] = 'webservices/LoginController/verify_code';
$route['forgot-password'] = 'webservices/LoginController/forgot_password';
$route['change_password'] = 'webservices/LoginController/change_password';
$route['getStores'] = 'webservices/UserController/storeList';
$route['createStore'] = 'webservices/UserController/addNewStore';
$route['updateStoreInfo'] = 'webservices/UserController/updateStore';
$route['removeStore'] = 'webservices/UserController/removeStore';
$route['update-profile'] = 'webservices/UserController/updateUserProfile';
$route['get-profile'] = 'webservices/UserController/getUserProfile';
$route['user-status'] = 'webservices/UserController/userStatus';
$route['logout'] = 'webservices/LoginController/user_logout';
$route['professional-list'] = 'webservices/UserController/professionalList';
$route['getServices'] = 'webservices/UserController/serviceList';
$route['add-store'] = 'webservices/UserController/saveStore';
$route['add-service'] = 'webservices/UserController/addService';
$route['delete-service'] = 'webservices/UserController/deleteService';
$route['store-details'] = 'webservices/UserController/storeDetails';
$route['getAppointments'] = 'webservices/UserController/appointmentList';
$route['getAppointmentDetail'] = 'webservices/UserController/appointmentDetails';
//$route['appointment-status-change'] = 'webservices/UserController/changeAppointmentStatus';
$route['cancelAppointment'] = 'webservices/UserController/changeAppointmentStatus';
$route['acceptAppointment'] = 'webservices/UserController/changeAppointmentStatus';
$route['appointment-update'] = 'webservices/UserController/updateAppointmentDetails';

$route['createStore'] = 'webservices/UserController/addNewStore';
$route['createService'] = 'webservices/UserController/addService';
$route['removeService'] = 'webservices/UserController/removeService';
$route['searchStores'] = 'webservices/UserController/searchStores';
$route['submitFeedbackToAdmin'] = 'webservices/UserController/submitFeedbackToAdmin';
$route['removeProfessional'] = 'webservices/UserController/removeProfessionals';

$route['searchProfessionals'] = 'webservices/UserController/professionalList';
$route['getProfessionalDetail'] = 'webservices/UserController/professionalList';
$route['getUserDetail'] = 'webservices/UserController/getUserDetail';
$route['makeAppointment'] = 'webservices/UserController/makeAppointment';
$route['listAppointment'] = 'webservices/UserController/listAppointment';
$route['updateAppointment'] = 'webservices/UserController/updateAppointment';
$route['markFavouriteToAnyStoreORProfessional'] = 'webservices/UserController/markFavouriteToAnyStoreORProfessional';
$route['getServicesforSelectedProfessional'] = 'webservices/UserController/getServicesforSelectedProfessional';
$route['getServicesforSelectedStore'] = 'webservices/UserController/getServicesforSelectedStore';
$route['getProfessionalsForSelectedServices'] = 'webservices/UserController/getProfessionalsForSelectedServices';
$route['getProfessionalsForSelectedStore'] = 'webservices/UserController/getProfessionalsForSelectedStore';
$route['AddWalkin'] = 'webservices/UserController/AddWalkin';
$route['GetAllWalkin'] = 'webservices/UserController/GetAllWalkin';
$route['getNotifications'] = 'webservices/UserController/getNotifications';


// Users webservices
$route['getAllSoloProfessionals'] = 'webservices/UserController/getAllSoloProfessionals';
$route['admin-settings'] = 'webservices/UserController/adminSettings';
$route['give_rating_feedback'] = 'webservices/UserController/giveRatingFeedback';
$route['request_to_leave_store'] = 'webservices/UserController/requestToLeaveStore';
$route['favourite_stores'] = 'webservices/UserController/favoriteStores';
$route['favourite_professionals'] = 'webservices/UserController/favouriteProfessionals';
$route['submit_rating_for_user'] = 'webservices/UserController/giveRatingFeedback';
$route['send_push_to_user'] = 'webservices/UserController/sendPushToUser';
$route['add_stripe_customer_id'] = 'webservices/UserController/addStripeCustomerKey';
$route['get_stripe_customer_id'] = 'webservices/UserController/getStripeCustomerKey';
$route['get_all_professionals_selected_date'] = 'webservices/UserController/getAllProfessionalsSelectedDate';
$route['get_professional_availibility'] = 'webservices/UserController/getProfessionalAvailibility';
$route['get_all_individual_professionals_selectedDate'] = 'webservices/UserController/getAllIndividualProfessionalsSelectedDate';
$route['save_plan_details'] = 'webservices/UserController/savePlanDetails';

?>