<?php

class Admin_model extends CI_Model {
    
    private $_id = "";
    private $_email = "";
    private $_password = "";
    private $_new_password = "";
    private $_confirm_password = "";
    private $_created_at = "";

    function getId() {
        return $this->_id;
    }

    function getEmail() {
        return $this->_email;
    }

    function getPassword() {
        return $this->_password;
    }

    function getCreated_at() {
        return $this->_created_at;
    }

    function setId($id) {
        $this->_id = $id;
    }

    function setEmail($email) {
        $this->_email = $email;
    }

    function setPassword($password) {
        $this->_password = $password;
    }

    function setCreated_at($created_at) {
        $this->_created_at = $created_at;
    }
    function getNew_password() {
        return $this->_new_password;
    }

    function getConfirm_password() {
        return $this->_confirm_password;
    }

    function setNew_password($new_password) {
        $this->_new_password = $new_password;
    }

    function setConfirm_password($confirm_password) {
        $this->_confirm_password = $confirm_password;
    }

    //check for admin user login
    public function checkAdminLogin(){ 
        $query  = $this->db->select('*')->from('tbl_admin')
                                        ->where('email', $this->getEmail())
                                        ->where('password',$this->getPassword())->get();
       
        if($query->num_rows() > 0){
            $data = $query->row_array();
            return $data;
        }else{
            $data = array();
            return $data;
        }
    }
    
    //check admin email exist
    public function checkEmailExist(){
        $query = $this->db->select('*')->from('tbl_admin')
                                       ->where('email',$this->getEmail())
                                       ->get();
        if($query->num_rows() > 0){
            $data = $query->row_array();
            return $data;
        }else{
            $data = array();
            return $data;
        }
    }
    
    //set new password
    public function setNewPassword(){
        $data['password'] = md5($this->getNew_password());
        $this->db->set($data)->where('email',$this->getEmail())->update('tbl_admin');
        if($this->db->affected_rows() > 0){
            return TRUE;
        }else{
            return FALSE;
        }
    }
    
}

?>