<?php
class Store_model extends CI_Model {
   
    public function getStoreDetail($storeId){
        $query = $this->db->where('id',$storeId)->get('tbl_stores');
        if($query->num_rows() > 0){
            $rows = $query->row_array();
            return $rows;
        }else{
            return false;
        }
    }
    
    //get all services
    public function servicesDetail($serviceId){
        $ids = convertingValues($serviceId);
        $lists = $this->db->where_in('id',$ids)->get('tbl_services')->result_array();
        return $lists;
    }
    
    //get all services
    public function professionalsDetail($professionalsId){
        $ids = convertingValues($professionalsId);
        $lists = $this->db->where_in('id',$ids)->get('tbl_users')->result_array();
        return $lists;
    }
    
    //delete store
    public function deleteStore($storeId){
        $this->db->set('is_deleted','0')
                ->where('id',$storeId)
                ->update('tbl_stores');
        return TRUE;
    }
    
    //get all clients
    public function clientLists($storeId){
        $lists = array();
        $query = $this->db->select('tbl_appointment.*,tbl_users.email,'
                            . 'tbl_users.first_name,tbl_users.last_name,tbl_users.mobile,tbl_users.image')
                        ->from('tbl_appointment')
                        ->join('tbl_users','tbl_appointment.user_id = tbl_users.id','left')
                        ->where('status','1')
                        ->where('store_id',$storeId)
                        ->group_by('tbl_users.id')
                        ->get();
        if($query->num_rows() > 0){
            $lists = $query->result_array();
        }
        return $lists;
    }

//function to get all the appointments booked
    public function getAllAppointments($from="",$to=""){
        $data = array();
        $query = $this->db->select('tap.user_id,tap.service_id,tap.id,tap.store_id,tap.professional_id,tap.service_price,tu.first_name as customerFirstName,'
                                    . 'tu.last_name as customerLastName,tu.email as customerEmail,tu.mobile as customerMobile,'
                                    . 'tap.no_of_seat,tap.service_time,tuf.first_name as professionalFirstName,'
                                    . 'tuf.last_name as professionalLastName,tuf.email,tuf.mobile,ts.service_name,st.name as storeName,tap.appointment_Date_time,tap.status')
                        ->from('tbl_appointment as tap')
                        ->join('tbl_services as ts','tap.service_id = ts.id','left')
                        ->join('tbl_stores as st','tap.store_id = st.id','left')
                        ->join('tbl_users as tu','tap.user_id = tu.id','left')
                        ->join('tbl_users as tuf','tap.professional_id = tuf.id','left');
	if($from != ""){
            $from_date = date('Y-m-d',strtotime($from));
            $query = $this->db->where('DATE(STR_TO_DATE(appointment_Date_time,"%d/%m/%Y")) >=', $from_date);
           
        }
        if($to != ""){
            $to_date = date('Y-m-d',strtotime($to));
            $query = $this->db->where('DATE(STR_TO_DATE(appointment_Date_time,"%d/%m/%Y")) <=', $to_date);
        }
            $query = $this->db->order_by('tap.created_on','desc')->get();
        if($query->num_rows() > 0){
            $data = $query->result_array();
           
        }
        return $data;
    }
    
    //function to get the data related to appointments booked
    public function updateStatus($appointmentId,$status){
        $this->db->set('status',$status)
                    ->where('id',$appointmentId)
                    ->update('tbl_appointment');
        return TRUE;
    }
}
?>