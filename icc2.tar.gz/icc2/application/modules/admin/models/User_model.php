<?php
class User_model extends CI_Model {
    
    private $_id = "";
    private $_email = "";
    private $_password = "";
    private $_user_type = "";
    private $_social_media_type ="";
    private $_sign_up_type = "";
    private $_mobile = "";
    private $_latitude = "";
    private $_longitude = "";
    private $_verify_code = "";
    private $_notification = "";
    private $_device_type = "";
    private $_device_token = "";
    private $_user_name = "";
    private $_image = "";
    private $_is_login = "";
    private $_identity_proof = "";
    private $_is_phone_verify = "";
    private $_gender = "";
    private $_from = "";
    private $_to = "";
    
    function getFrom() {
        return $this->_from;
    }

    function getTo() {
        return $this->_to;
    }

    function setFrom($from) {
        $this->_from = $from;
    }

    function setTo($to) {
        $this->_to = $to;
    }

    function getGender() {
        return $this->_gender;
    }

    function setGender($gender) {
        $this->_gender = $gender;
    }

    function getId() {
        return $this->_id;
    }

    function getEmail() {
        return $this->_email;
    }

    function getPassword() {
        return $this->_password;
    }

    function getUser_type() {
        return $this->_user_type;
    }

    function getSocial_media_type() {
        return $this->_social_media_type;
    }

    function getSign_up_type() {
        return $this->_sign_up_type;
    }

    function getMobile() {
        return $this->_mobile;
    }

    function getLatitude() {
        return $this->_latitude;
    }

    function getLongitude() {
        return $this->_longitude;
    }

    function getVerify_code() {
        return $this->_verify_code;
    }

    function getNotification() {
        return $this->_notification;
    }

    function getDevice_type() {
        return $this->_device_type;
    }

    function getDevice_token() {
        return $this->_device_token;
    }

    function getUser_name() {
        return $this->_user_name;
    }

    function getImage() {
        return $this->_image;
    }

    function getIs_login() {
        return $this->_is_login;
    }

    function getIdentity_proof() {
        return $this->_identity_proof;
    }

    function getIs_phone_verify() {
        return $this->_is_phone_verify;
    }

    function setId($id) {
        $this->_id = $id;
    }

    function setEmail($email) {
        $this->_email = $email;
    }

    function setPassword($password) {
        $this->_password = $password;
    }

    function setUser_type($user_type) {
        $this->_user_type = $user_type;
    }

    function setSocial_media_type($social_media_type) {
        $this->_social_media_type = $social_media_type;
    }

    function setSign_up_type($sign_up_type) {
        $this->_sign_up_type = $sign_up_type;
    }

    function setMobile($mobile) {
        $this->_mobile = $mobile;
    }

    function setLatitude($latitude) {
        $this->_latitude = $latitude;
    }

    function setLongitude($longitude) {
        $this->_longitude = $longitude;
    }

    function setVerify_code($verify_code) {
        $this->_verify_code = $verify_code;
    }

    function setNotification($notification) {
        $this->_notification = $notification;
    }

    function setDevice_type($device_type) {
        $this->_device_type = $device_type;
    }

    function setDevice_token($device_token) {
        $this->_device_token = $device_token;
    }

    function setUser_name($user_name) {
        $this->_user_name = $user_name;
    }

    function setImage($image) {
        $this->_image = $image;
    }

    function setIs_login($is_login) {
        $this->_is_login = $is_login;
    }

    function setIdentity_proof($identity_proof) {
        $this->_identity_proof = $identity_proof;
    }

    function setIs_phone_verify($is_phone_verify) {
        $this->_is_phone_verify = $is_phone_verify;
    }

     //get all ACTIVE users
    public function getAllActiveUsers(){
        $this->db->where('is_deleted','1');
        if($this->getGender() != ""){
            $this->db->where('gender',$this->getGender());
        }
        if($this->getUser_type() != ""){
            $this->db->where('user_type',$this->getUser_type());
        }
        if($this->getFrom() != ""){
            $from_date = date('Y-m-d',strtotime($this->getFrom()));
            $this->db->where('DATE(created_on) >=', $from_date);
           
        }
        if($this->getTo() != ""){
            $to_date = date('Y-m-d',strtotime($this->getTo()));
             $this->db->where('DATE(created_on) <=', $to_date);
        }
        $query = $this->db->order_by('created_on','desc')->get('tbl_users');
        if($query->num_rows() > 0){
            $rows = $query->result_array();
            return $rows;
        }else{
            return false;
        }
    }
    
    public function getDashboardUsers(){
        $query=$this->db
                ->where('is_deleted','1')
                ->order_by('created_on','desc')
                ->limit(3)
                ->get('tbl_users');
        if($query->num_rows() > 0){
            $rows = $query->result_array();
            return $rows;
        }else{
            return false;
        }
    }
    
    public function getAllStores(){
        $query = $this->db->where('is_deleted','1')
                            ->order_by('created_on','desc')->get('tbl_stores');
        if($query->num_rows() > 0){
            $rows = $query->result_array();
            return $rows;
        }else{
            return false;
        }
    }
    
    public function getUserDetail($userId){
        $query = $this->db->where('id',$userId)->get('tbl_users');
        if($query->num_rows() > 0){
            $rows = $query->row_array();
            return $rows;
        }else{
            return false;
        }
    }
    
    public function updateNewExpiry($expiryDate,$userId){
        $this->db->set('end_date',$expiryDate)
                          ->where('id',$userId)
                          ->update('tbl_users');
        return true;
    }
    
    public function lastServiceDetail($userId){
        $query = $this->db->select('tbl_appointment.*,tbl_services.service_name,'
                            . 'tbl_services.price,tbl_services.service_description,tbl_users.first_name,tbl_users.last_name')
                            ->from('tbl_appointment')
                            ->join('tbl_users','tbl_appointment.professional_id =  tbl_users.id','left')
                            ->join('tbl_services','tbl_appointment.service_id =  tbl_services.id','left')
                            ->where('tbl_appointment.user_id',$userId)
                            ->where('service_id !=','0')
                            ->where('status','1')
                            ->order_by('tbl_appointment.created_on','desc')
                            ->limit(1)
                            ->get();
        if($query->num_rows() > 0){
            $data = $query->row_array();
        }
        return $data;
    }
    
    public function recentProfessions($userId){
        $query = $this->db->select('tbl_appointment.*,tbl_users.email,'
                            . 'tbl_users.first_name,tbl_users.last_name,tbl_users.mobile,tbl_users.image')
                            ->from('tbl_appointment')
                            ->join('tbl_users','tbl_appointment.professional_id = tbl_users.id','left')
                            ->where('user_id',$userId)
                            ->where('professional_id !=',"")
                            ->where('status','1')
                            ->order_by('created_on','desc')
                            ->get();
        
        if($query->num_rows() > 0){
            $data = $query->result_array();
        }
        return $data;
    }
    
    public function recentStores($userId){
        $query = $this->db->select('tbl_appointment.*,tbl_stores.email,'
                            . 'tbl_stores.name,tbl_stores.address,tbl_stores.mobile,tbl_stores.image,tbl_stores.description,tbl_stores.store_open_time,store_'
                            . 'close_time,services.professionals')
                            ->from('tbl_appointment')
                            ->join('tbl_stores','tbl_appointment.store_id = tbl_stores.id','left')
                            ->where('user_id',$userId)
                            ->where('tbl_stores !=',"")
                            ->where('status','1')
                            ->order_by('created_on','desc')
                            ->get();
        
        if($query->num_rows() > 0){
            $data = $query->result_array();
        }
        return $data;
    }
    public function deleteUser($userId){
        $this->db->set('is_deleted','0')
                  ->where('id',$userId)
                   ->update('tbl_users');
        return TRUE;
    }
}

?>