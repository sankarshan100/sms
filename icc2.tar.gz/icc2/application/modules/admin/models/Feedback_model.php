<?php
class Feedback_model extends CI_Model {
    
    private $_user_id = "";
    private $_feedback = "";
    private $_feedback_type = "";
    private $_user_type = "";
    
    function getUser_id() {
        return $this->_user_id;
    }

    function getFeedback() {
        return $this->_feedback;
    }

    function getFeedback_type() {
        return $this->_feedback_type;
    }

    function getUser_type() {
        return $this->_user_type;
    }

    function setUser_id($user_id) {
        $this->_user_id = $user_id;
    }

    function setFeedback($feedback) {
        $this->_feedback = $feedback;
    }

    function setFeedback_type($feedback_type) {
        $this->_feedback_type = $feedback_type;
    }

    function setUser_type($user_type) {
        $this->_user_type = $user_type;
    }

    /* function for fetching all the feedbacks*/
    public function getFeedbacks(){
        $lists = array();
        $this->db->select('tbl_feedback.*,tbl_users.first_name,tbl_users.last_name,tbl_users.email,tbl_users.image')
                    ->from('tbl_feedback')
                    ->join('tbl_users','tbl_feedback.user_id =  tbl_users.id','left')
                    ->where('tbl_feedback.user_id!=','1')
                    ->where('tbl_feedback.is_deleted','0');
        if($this->getFeedback_type() != ""){
            $this->db->where('feedback_type',$this->getFeedback_type());
        }
        $query = $this->db->order_by('tbl_feedback.created_on','desc')->get();
        if($query->num_rows() > 0){
            $lists = $query->result_array();
        }
        return $lists;
    }
    
    //send reply 
    public function replyFeedback($feedback_id,$reply,$to_id,$feedback_type,$user_type){
        $data['user_id'] = 1;
        $data['feedback_to'] = $to_id;
        $data['feedback'] = $reply;
        $data['feedback_message'] = $reply;
        $data['feedback_type'] = $feedback_type;
        $data['user_type'] = $user_type;
        
        $this->db->set($data)->insert('tbl_feedback');
        return TRUE;
    }
    
    public function getConversationFeedback($user_id){
        $query = $this->db->where('user_id',$user_id)
                        ->or_where('feedback_to',$user_id)
                        ->where('is_deleted','0')
                        ->order_by('created_on','asc')
                        ->get('tbl_feedback');
        if($query->num_rows() > 0){
            $data = $query->result_array();
        }
            return $data;    
    }
    
    public function deleteFeedback($id){
        $this->db->set('is_deleted','1')
                ->where('user_id',$id)
                ->or_where('feedback_to',$id)
                  ->update('tbl_feedback');
        return TRUE;
    }
    
}

?>