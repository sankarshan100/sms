<div class="content-wrapper">
    <div class="container-fluid">

        <div class="row">
            <div class="col-md-12">

                <h2 class="page-title">Services Management</h2>
                
                <!-- Zero Configuration Table -->
                <div class="panel panel-default">
                    <div class="panel-heading">Services List View</div>
                    <div class="panel-body">
                        <div class="note note-success">
                            <h4 class="block"></h4>
                            <p style="font-size: 15px;color:green;text-align: center;">
                                <?php 
                                    if($this->session->userdata('errorMsg') != ""){
                                       echo $this->session->userdata('errorMsg');
                                       $this->session->unset_userdata('errorMsg');
                                    }

                                    if($this->session->userdata('successMsg') != ""){
                                       echo $this->session->userdata('successMsg');
                                       $this->session->unset_userdata('successMsg');
                                    }
                                ?>
                            </p>
                        </div>
                        <table id="zctb" class="display table table-striped table-bordered table-hover" cellspacing="0" width="100%">
                            <thead>
                                <tr>
                                    <th>Service Name</th>
                                    <th>Price</th>
                                    <th>Owner Name</th>
                                    <th>User Type</th>
                                    <th>Service Time</th>
                                    <th>Service Description</th>
                                    <th>Action</th>
                                </tr>
                            </thead>

                            <tbody>
                                <?php foreach ($services as $key=>$value){ ?>
                                <tr>
                                    <td><?php echo $value['service_name']; ?></td>
                                    <td><?php echo $value['price']; ?></td>
                                    <td><?php if($value['first_name'] != ""){
                                                echo ucfirst($value['first_name'])." ".ucfirst($value['last_name']); 
                                            }else{
                                                echo "-";
                                            } ?></td>
                                    <td>
                                        <?php if($value['user_type'] == '3'){ echo "Store Admin";}
                                              else if($value['user_type'] == '1'){ echo "Professional";}
                                              else if($value['user_type'] == '2'){ echo "User";}else {echo "-";}?></td>
                                    <td><?php echo $value['service_time']; ?></td>
                                    <td><?php echo $value['service_description']; ?></td>
                                    <td><div class="col-md-4 col-sm-6 col-lg-3">
                                           <a href = "<?php echo base_url(); ?>view_service_detail?service_id=<?php echo $value['id']?>" style="color:#000;">
                                                <i class="fa fa-eye"></i> 
                                            </a> </div>
                                        <div class="col-md-4 col-sm-6 col-lg-3">
<a href="<?php echo base_url();?>delete_service?service_id=<?php echo $value['id'] ?>" onclick='return confirm("Are you sure you want to delete this service?")' style="color:#000;"><i class="fa fa-fw"></i> </a> 
                                        </div>

                                    </td>
                                </tr>
                                <?php }?>
                                
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
</div>