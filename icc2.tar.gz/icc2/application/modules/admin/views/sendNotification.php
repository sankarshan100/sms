<div class="content-wrapper">
    <div class="container-fluid">
        <div class="row">
            <div class="col-md-12">
                    <h2 class="page-title">Send User Push Notification / Email </h2>
                        <div class="portlet-body">
                                    <div class="note note-success">
                                        <h4 class="block"></h4>
                                        <p style="font-size: 15px;color:green;text-align: center;">
                                            <?php 
                                                if($this->session->userdata('errorMsg') != ""){
                                                   echo $this->session->userdata('errorMsg');
                                                   $this->session->unset_userdata('errorMsg');
                                                }
                                                
                                                if($this->session->userdata('successMsg') != ""){
                                                   echo $this->session->userdata('successMsg');
                                                   $this->session->unset_userdata('successMsg');
                                                }
                                            ?>
                                        </p>
                                    </div>
                                    <form class="form-horizontal" method="post" name="send_notification_form" id="send_notification_form" action="">
                                        <input type="hidden" name="user_id" value="<?php echo $this->input->get('user_id')?>" />
                                        <div class="form-group">
                                            <label class="col-md-3 control-label" for="title">Notification title:</label>
                                            <div class="col-md-5">
                                                <input id="notific8_text" type="text" class="form-control" value="" name="title" id="title" placeholder="Enter a title ..."> </div>
                                        </div>
                                        
                                        <div class="form-group">
                                                <label class="col-md-3 control-label" for="message">Message</label>
                                                <div class="col-md-5">
                                                        <textarea class="form-control" id="message" name="message" rows="3" placeholder="Enter a message ..." name="message"></textarea>
                                                </div>
                                                
                                            </div>
                                        
                                        <div class="form-group">
                                            <label class="col-md-3 control-label" for="title">Sending type ?</label>
                                            <div class="col-md-5">
                                                <label class="checkbox">
                                                    <input type="checkbox" id="notific8_sticky" value="1" name="send_type[]"> Push Notifcation</label>
                                            
                                                <label class="checkbox">
                                                    <input type="checkbox" id="notific8_sticky" value="2" name="send_type[]"> Email </label>
                                            </div>
                                        </div>
                                        <div class="form-group">
                                            <label class="col-md-3 control-label" for="title"></label>
                                            <div class="col-md-3">
                                                <input type="submit" name="submit" class="btn purple btn-block" value="Send" style="background: #3e454c;color:#fff;font-size:16px;">
                                            </div>
                                        </div>
                                    </form>
                                </div>
                     </div>
            </div>
        </div>
   
</div>
<style>
    .checkbox input[type="checkbox"], .checkbox input[type="radio"] {
    opacity: 1;
    z-index: 1;
}
</style>
<script src="<?php echo base_url();?>js/jquery.js"></script>
<script src="<?php echo base_url();?>js/jquery.validate.js"></script>
<script type="text/javascript">
    $("#send_notification_form").validate({
        rules: {
            title: "required",
            message:"required"
    }
  }
        
      });
</script>