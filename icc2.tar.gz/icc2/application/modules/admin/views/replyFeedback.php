<div class="content-wrapper">
    <div class="container-fluid">
        <div class="row">
            <div class="col-md-12">
                    <h2 class="page-title">Send Reply To User</h2>
                        <div class="portlet-body">
                              <h4 class="block">User Message</h4>
                              <div style = "width: 100%;height:350px;overflow: scroll;">
                        <?php if(count($messages) > 0){
                            foreach($messages as $key => $value){
                        ?>
                              <?php if($value['user_id'] != 1){?>  
                              <div class="alert alert-info">
                                    <strong>User Reply : </strong> <?php echo $value['feedback']; ?>
                                </div>  
                              <?php }else{ ?>
                                <div class="alert alert-warning">
                                    <strong>Super Admin :</strong>  <?php echo $value['feedback']; ?>
                                </div>
                              <?php      
                            }}
                        }   ?>
                                  </div>
                                    <div class="note note-success">
                                        <h4 class="block"></h4>
                                        <p style="font-size: 15px;color:green;text-align: center;">
                                            <?php 
                                                if($this->session->userdata('errorMsg') != ""){
                                                   echo $this->session->userdata('errorMsg');
                                                   $this->session->unset_userdata('errorMsg');
                                                }
                                                
                                                if($this->session->userdata('successMsg') != ""){
                                                   echo $this->session->userdata('successMsg');
                                                   $this->session->unset_userdata('successMsg');
                                                }
                                            ?>
                                        </p>
                                    </div>
                                    <form action="" id="reply-form" method="post" class="form-horizontal form-bordered">
                            <div class="form-group">
                                <input type="hidden" name="feedback_id" value="<?php echo $this->input->get('feedback_id') ?>" />
                                <input type="hidden" name="user_id" value="<?php echo $this->input->get('user_id') ?>" />
                                <input type="hidden" name="user_type" value="<?php echo $this->input->get('user_type') ?>" />
                                <input type="hidden" name="feedback_type" value="<?php echo $this->input->get('feedback_type') ?>" />
                                <label class="col-md-3 control-label" for="message">Reply</label>
                                
                                <div class="col-md-5">
                                    <textarea class="form-control" id="reply" name="reply" rows="3" placeholder="Enter a message ..." ></textarea>
                                    
                                </div>
                            </div>
                                      
                            <div class="form-actions">
                                <div class="row">
                                    <div class="col-md-offset-3 col-md-9">
                                        <a  href="<?php echo base_url() ?>reply_feedback?feedback_id=<?php echo $this->input->get('feedback_id') ?>" >
                                        <button style="background:#3e454c;color:#fff;font-size:12px;width:100px;height:45px;" type="submit" name="submit" value="Submit" class="btn red">
                                            <i class="fa fa-check"></i> Submit</button>
                                            </a>
                                        <a  href="<?php echo base_url() ?>reply_feedback?feedback_id=<?php echo $this->input->get('feedback_id') ?>" >
                                            <button style="background:#3e454c;color:#fff;font-size:12px;width:100px;height:45px;" type="button" class="btn default">Cancel</button>
                                        </a>
                                    </div>
                                </div>
                            </div>
                        </form>
                                </div>
                     </div>
            </div>
        </div>
   
</div>