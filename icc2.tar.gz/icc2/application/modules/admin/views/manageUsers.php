<div class="content-wrapper">
    <div class="container-fluid">

        <div class="row">
            <div class="col-md-12">

                <h2 class="page-title">Users Management</h2>

                <!-- Zero Configuration Table -->
                <div class="panel panel-default">
                    <div class="panel-heading">Users List View</div>
                    <form action=""  name="filters" id="filters">
                        <div class="form-group" style="margin-top:20px;">
                            <label class="control-label col-md-3">Filters</label>
                            <div class="col-md-3">
                                <select class="bs-select form-control input-small" name="gender" >
                                    <option value="">Select Gender</option>
                                    <option value="1" <?php if($this->input->get('gender') == "1") { echo 'selected="selected"';}?>>Male</option>
                                    <option value="2"<?php if($this->input->get('gender') == "2") { echo 'selected="selected"';}?>>Female</option>
                                </select>
                            </div>  
                            <div class="col-md-3">
                                <select class="bs-select form-control" name="user_type">
                                    <option value="">Select User Type</option>
                                    <option value="1" <?php if($this->input->get('user_type') == "1") { echo 'selected="selected"';}?>>Professionals</option>
                                    <option value="2" <?php if($this->input->get('user_type') == "2") { echo 'selected="selected"';}?>>Users</option>
                                    <option value="3" <?php if($this->input->get('user_type') == "3") { echo 'selected="selected"';}?>>Store admin</option>
                                </select>
                            </div>
                            
                               <div class="form-group col-sm-12" style="margin-top: 20px;">
                                                <label class="control-label col-md-3">Date Range</label>
                                                <div class="col-md-4">
                                                    <div class="input-group input-large date-picker input-daterange" data-date="10/11/2012" data-date-format="mm/dd/yyyy">
                                                        <input type="text" placeholder = "from" class="form-control" value="<?php echo $this->input->get('from');?>" name="from">
                                                        <span class="input-group-addon"> to </span>
                                                        <input type="text" placeholder = "to" class="form-control" value="<?php echo $this->input->get('to');?>" name="to"> </div>
                                                    <!-- /input-group -->
                                                    <span class="help-block"> Select date range </span>
                                                </div>
                                            </div>
                            <input type="submit" class="btn btn-primary" style="background-color:#3e454c;" name="apply" value="Apply" />
                            <a href="<?php echo base_url()?>manage_users" />
                                <button type="button" class="btn btn-primary" style="background-color:#3e454c;" onclick = "reload()"> Reset </button>
                            </a>
                        </div>
                    </form>
                    <div class="note note-success">
                                        <h4 class="block"></h4>
                                        <p style="font-size: 15px;color:green;text-align: center;">
                                            <?php 
                                                if($this->session->userdata('errorMsg') != ""){
                                                   echo $this->session->userdata('errorMsg');
                                                   $this->session->unset_userdata('errorMsg');
                                                }
                                                
                                                if($this->session->userdata('successMsg') != ""){
                                                   echo $this->session->userdata('successMsg');
                                                   $this->session->unset_userdata('successMsg');
                                                }
                                            ?>
                                        </p>
                                    </div>
                    <div class="panel-body">
                        <table id="zctb" class="display table table-striped table-bordered table-hover" cellspacing="0" width="100%">
                            <thead>
                                <tr>
                                    <th>Name</th>
                                    <th>Email Id</th>
                                    <th>Mobile Number</th>
                                    <th>User Type</th>
                                    <th>Profile Pic</th>
                                    <th>Subscription Status</th>
                                    <th>Action</th>
                                </tr>
                            </thead>

                            <tbody>
                                <?php foreach ($users as $value){ ?>
                                <tr>
                                    
                                        <td style="text-align: center;"><?php 
                                            if($value['first_name'] != ""){
                                                echo ucfirst($value['first_name'])." ".ucfirst($value['last_name']); 
                                            }else{
                                                echo "-";
                                            }
                                          ?>
                                        </td>
                                    <td><?php echo $value['email']; ?></td>
                                    <td><?php echo $value['mobile']; ?></td>
                                    <td><?php if($value['user_type']=='3'){ echo "Store Admin";}
                                              else if($value['user_type']=='1'){ echo "Professional";}
                                              else if($value['user_type']=='2'){ echo "User";}else {echo "User";}?></td>
                                    <td><?php 
                                        if($value['image'] != ""){ 
                                            $image = $value['image'];
                                        ?>
                                        
                                        <img src="<?php echo $image;?>" width="50px" height="50px"/>
                                        <?php } else{ ?>
                                            <i class="fa fa-user"></i>
                                        <?php } ?>
                                    </td>
                                    <td>
                                        <?php if($value['is_expire'] !=  "" ){
                                            echo "Subscribed";
                                        }else{
                                            echo "UnSubscribed";
                                        } ?>
                                    </td>
                                    <td><div class="col-md-4 col-sm-6 col-lg-3">
                                            <a href = "<?php echo base_url(); ?>view_user_detail?user_id=<?php echo $value['id']?>" style="color:#000;">
                                                <i class="fa fa-eye"></i> 
                                            </a>
                                        </div>
                                        <div class="col-md-4 col-sm-6 col-lg-3">
                                            <a href="<?php echo base_url();?>delete_user?user_id=<?php echo $value['id'] ?>" style="color:#000;" onclick='return confirm("Are you sure you want to delete this user?")'><i class="fa fa-fw"></i> </a>                                        </div>
                                        <div class="fa-item col-md-3 col-sm-4">
                                            <a href ="<?php echo base_url();?>send_notification?user_id=<?php echo $value['id']?>" style="color:#000;"/>
                                                <i class="fa fa-send"></i>
                                            </a>
                                        </div>
                                        <div class="fa-item" >
                                            <a class="btn red btn-outline sbold" style="color:#000;font-size:12px;" href="<?php echo base_url()?>extend_trail_period?user_id=<?php echo$value['id'] ?>"> Extend Trail Period </a>
                                        </div>
                                    </td>
                                </tr>
                                <?php }?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>