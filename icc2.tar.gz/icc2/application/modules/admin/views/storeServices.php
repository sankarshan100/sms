<div class="content-wrapper">
    <div class="container-fluid">

        <div class="row">
            <div class="col-md-12">

                <h2 class="page-title">Panels and Wells</h2>
                <div class="row">
                    
                    <div class="col-md-4">
                        <div class="panel panel-primary">
                            <div class="panel-heading">
                                <h3 class="panel-title">Panel primary</h3>
                            </div>
                            <div class="panel-body">
                                Panel content
                            </div>
                        </div>

                        <div class="panel panel-success">
                            <div class="panel-heading">
                                <h3 class="panel-title">Panel success</h3>
                            </div>
                            <div class="panel-body">
                                Panel content
                            </div>
                        </div>

                        <div class="panel panel-warning">
                            <div class="panel-heading">
                                <h3 class="panel-title">Panel warning</h3>
                            </div>
                            <div class="panel-body">
                                Panel content
                            </div>
                        </div>
                    </div>
                    
                </div>

                
            </div>
        </div>
    </div>
</div>
</div>
