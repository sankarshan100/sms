<div class="content-wrapper">
    <div class="container-fluid">

        <div class="row">
            <div class="col-md-12">

                <h2 class="page-title">Feedback Management</h2>

                <!-- Zero Configuration Table -->
                <div class="panel panel-default">
                    <div class="panel-heading">Users Feedback List View</div>
                    <form action=""  name="filters" id="filters">
                        <div class="form-group" style="margin-top:20px;">
                            <label class="control-label col-md-3">Filters</label>
                            <div class="col-md-3">
                                <select class="bs-select form-control" name="feedback_type">
                                    <option value="">Select Feedback To Type</option>
                                    <option value="1" <?php if($this->input->get('feedback_type') == "1") { echo 'selected="selected"';}?>>Store admin</option>
                                    <option value="2" <?php if($this->input->get('feedback_type') == "2") { echo 'selected="selected"';}?>>Professionals</option>
                                </select>
                            </div>
                            <input type="submit" class="btn btn-primary" style="background-color:#3e454c;" name="apply" value="Apply" />
                            <a href="<?php echo base_url()?>manage_feedbacks" />
                                <button type="button" class="btn btn-primary" style="background-color:#3e454c;" onclick = "reload()"> Reset </button>
                            </a>
                        </div>
                    </form>
                    <div class="note note-success">
                                        <h4 class="block"></h4>
                                        <p style="font-size: 15px;color:green;text-align: center;">
                                            <?php 
                                                if($this->session->userdata('errorMsg') != ""){
                                                   echo $this->session->userdata('errorMsg');
                                                   $this->session->unset_userdata('errorMsg');
                                                }
                                                
                                                if($this->session->userdata('successMsg') != ""){
                                                   echo $this->session->userdata('successMsg');
                                                   $this->session->unset_userdata('successMsg');
                                                }
                                            ?>
                                        </p>
                                    </div>
                    <div class="panel-body">
                        <table id="zctb" class="display table table-striped table-bordered table-hover" cellspacing="0" width="100%">
                            <thead>
                                <tr>
                                    <th>Name</th>
                                    <th>Email</th>
                                    <th>Feedback Message</th>
                                    <th>Feedback Type</th>
                                    <th>Profile Pic</th>
                                    <th>Action</th>
                                </tr>
                            </thead>

                            <tbody>
                                <?php foreach ($lists as $key => $value){ ?>
                                <tr>
                                    
                                        <td style="text-align: center;"><?php 
                                            if($value['first_name'] != ""){
                                                echo ucfirst($value['first_name'])." ".ucfirst($value['last_name']); 
                                            }else{
                                                echo "-";
                                            }
                                          ?>
                                        </td>
                                    <td><?php echo $value['email']; ?></td>
                                    <td><?php echo $value['feedback']; ?></td>
                                    <td><?php if($value['feedback_type'] == '1'){ echo "Store Admin";}
                                              else if($value['feedback_type']=='2'){ echo "Professional";}
                                              else {echo "User";}?></td>
                                    <td><?php 
                                        if($value['image'] != ""){ 
                                            $image = $value['image'];
                                        ?>
                                        
                                        <img src="<?php echo $image;?>" width="50px" height="50px"/>
                                        <?php } else{ ?>
                                            <i class="fa fa-user"></i>
                                        <?php } ?>
                                    </td>
                                    <td>
                                        <div class="col-md-4 col-sm-6 col-lg-3">

                                            <a href="<?php echo base_url();?>delete_feedback?user_id=<?php echo $value['user_id'] ?>" onclick='return confirm("Are you sure you want to delete this entry?")'><i class="fa fa-fw"></i> </a>


                                        </div>
                                        <div class="fa-item" >
                                            <a href="<?php echo base_url()?>reply_feedback?feedback_id=<?php echo $value['id']; ?>&user_id=<?php echo $value['user_id'] ?>&feedback_type=<?php echo $value['feedback_type'] ?>&user_type=<?php echo $value['user_type']?>" style="color:#fff!important;">
                                                <button type="button" class="btn red" style="background:#3e454c;color:#fff;font-size:12px;width:100px;height:45px;">
                                                Reply</button></a>
                                        </div>
                                    </td>
                                </tr>
                                <?php }?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>