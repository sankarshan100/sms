<link href="http://fonts.googleapis.com/css?family=Open+Sans:400,300,600,700&subset=all" rel="stylesheet" type="text/css" />
<link href="<?php echo base_url(); ?>assets/global/plugins/simple-line-icons/simple-line-icons.min.css" rel="stylesheet" type="text/css" />
<link href="<?php echo base_url(); ?>assets/global/plugins/bootstrap/css/bootstrap.min.css" rel="stylesheet" type="text/css" />
<link href="<?php echo base_url(); ?>assets/global/plugins/bootstrap-switch/css/bootstrap-switch.min.css" rel="stylesheet" type="text/css" />
<!-- END GLOBAL MANDATORY STYLES -->
<!-- BEGIN PAGE LEVEL PLUGINS -->
<link href="<?php echo base_url(); ?>assets/global/plugins/bootstrap-fileinput/bootstrap-fileinput.css" rel="stylesheet" type="text/css" />
<!-- END PAGE LEVEL PLUGINS -->
<!-- BEGIN THEME GLOBAL STYLES -->
<link href="<?php echo base_url(); ?>assets/global/css/components.min.css" rel="stylesheet" id="style_components" type="text/css" />
<link href="<?php echo base_url(); ?>assets/global/css/plugins.min.css" rel="stylesheet" type="text/css" />
<!-- END THEME GLOBAL STYLES -->
<!-- BEGIN PAGE LEVEL STYLES -->
<link href="<?php echo base_url(); ?>assets/pages/css/profile.min.css" rel="stylesheet" type="text/css" />
<!-- END PAGE LEVEL STYLES -->
<!-- BEGIN THEME LAYOUT STYLES -->
<link href="<?php echo base_url(); ?>assets/layouts/layout/css/layout.min.css" rel="stylesheet" type="text/css" />
<link href="<?php echo base_url(); ?>assets/layouts/layout/css/themes/darkblue.min.css" rel="stylesheet" type="text/css" id="style_color" />
<link href="<?php echo base_url(); ?>assets/layouts/layout/css/custom.min.css" rel="stylesheet" type="text/css" />

<div class="content-wrapper">
    <div class="container-fluid" style="background-color:#b4bcc8;">
        <h3 class="page-title" style="font-size:25px;margin-top:10px;color:#fff;"> Store Detail
        </h3>

        <div class="row">
            <div class="col-md-12">
                <!-- BEGIN PROFILE SIDEBAR -->
                <div class="profile-sidebar">
                    <!-- PORTLET MAIN -->
                    <div class="portlet light profile-sidebar-portlet " style="height:300px ! important;">
                        <!-- SIDEBAR USERPIC -->
                        <div class="profile-userpic">
                            <?php if ($storeDetail['image'] != "") { ?>
                                <img src="<?php echo base_url() . $storeDetail['image']; ?>" class="img-responsive" alt=""> 
                            <?php } else { ?>
                                <img src="<?php echo base_url(); ?>assets/img/avatar.jpg" class="img-responsive" alt=""> 
                            <?php } ?>
                        </div>
                        <!-- END SIDEBAR USERPIC -->
                        <!-- SIDEBAR USER TITLE -->
                        <div class="profile-usertitle">
                            <?php if ($storeDetail['name'] != "") { ?>
                                <div class="profile-usertitle-name"> <?php echo ucfirst($storeDetail['name']); ?> </div>
                            <?php } ?>
                            <div class="profile-usertitle-job">  </div>
                        </div>
                        <!-- END SIDEBAR USER TITLE -->
                        <div class="profile-userbuttons">
                            <div> Open Timings : <?php echo $storeDetail['store_open_time']; ?> </div>
                            <div> Close TImings :<?php echo $storeDetail['store_close_time']; ?> </div>
                        </div>

                    </div>


                    <!-- END PORTLET MAIN -->
                </div>
                <!-- END BEGIN PROFILE SIDEBAR -->
                <!-- BEGIN PROFILE CONTENT -->
                <div class="profile-content">
                    <div class="row">
                        <div class="col-md-12">
                            <div class="portlet light ">
                                <div class="portlet-title tabbable-line">
                                    <div class="caption caption-md">
                                        <i class="icon-globe theme-font hide"></i>
                                        <span class="caption-subject font-blue-madison bold uppercase">Profile Account</span>
                                    </div>
                                    <ul class="nav nav-tabs">
                                        <li class="active">
                                            <a href="#tab_1_1" data-toggle="tab">Personal Info</a>
                                        </li>
                                        <li>
                                            <a href="#tab_1_2" data-toggle="tab">Services</a>
                                        </li>
                                        <li>
                                            <a href="#tab_1_3" data-toggle="tab">Professionals</a>
                                        </li>
                                        <li>
                                            <a href="#tab_1_4" data-toggle="tab">Clients</a>
                                        </li>
                                    </ul>
                                </div>
                                <div class="portlet-body">
                                    <div class="tab-content">
                                        <!-- PERSONAL INFO TAB -->
                                        <div class="tab-pane active" id="tab_1_1">
                                            <form role="form" action="#">
                                                <div class="form-group">
                                                    <label class="control-label">First Name</label>
                                                    <input type="text" class="form-control" readonly="true" value="<?php if ($storeDetail['name'] != "") {
                                echo ucfirst($storeDetail['name']);
                            } else {
                                echo "-";
                            } ?>"> </div>

                                                <div class="form-group">
                                                    <label class="control-label">Mobile Number</label>
                                                    <input type="text" readonly="true" value="<?php if ($storeDetail['mobile'] != "") {
                                echo ucfirst($storeDetail['mobile']);
                            } else {
                                echo "-";
                            } ?>" class="form-control"> </div>
                                                <div class="form-group">
                                                    <label class="control-label">Address</label>
                                                    <input type="text" readonly="true" value="<?php if ($storeDetail['address'] != "") {
                                echo ucfirst($storeDetail['address']);
                            } else {
                                echo "-";
                            } ?>" class="form-control"> </div>
                                                <div class="form-group">
                                                    <label class="control-label">Email</label>
                                                    <input type="text" readonly="true" value="<?php if ($storeDetail['email'] != "") {
                                echo ucfirst($storeDetail['email']);
                            } else {
                                echo "-";
                            } ?>" class="form-control"> </div>

                                            </form>
                                        </div>
                                        <!-- END PERSONAL INFO TAB -->
                                        <!-- services TAB -->
                                        <div class="tab-pane" id="tab_1_2">

                                            <div class="portlet light bordered">
                                                <div class="portlet-title tabbable-line">
                                                    <div class="caption">
                                                        <i class="icon-bubbles font-dark hide"></i>
                                                        <span class="caption-subject font-dark bold uppercase">Services List</span>
                                                    </div>
                                                </div>
                                                <div class="portlet-body">
                                                    <div class="tab-content">
                                                        <div class="tab-pane active" id="portlet_comments_1">
                                                            <!-- BEGIN: Comments -->
                                                            <div class="mt-comments">
                                                                <?php if(count($services) > 0){
                                                                    
                                                                foreach($services as $key => $value){
?>
                                                                <div class="mt-comment">
                                                                    <div class="mt-comment-body">
                                                                        <div class="mt-comment-info">
                                                                            <span class="mt-comment-author"><?php echo ucfirst($value['service_name']); ?></span>
                                                                            <span class="mt-comment-date"><?php echo date('Y-m-d H:i A',strtotime($value['created_on'])) ;?></span>
                                                                        </div>
                                                                        <span class="mt-comment-text">Cost: <?php echo ucfirst($value['price']); ?></span>
                                                                        <br>
                                                                        <div class="mt-comment-text">Description: <?php echo $value['service_description']; ?></div>
                                                                    </div>
                                                                </div>
                                                                <?php }
                                                                } ?>
        </div>
                                                            
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <!---- Professionals tab..-->
                                        <div class="tab-pane" id="tab_1_3">

                                            <div class="portlet light bordered">
                                                <div class="portlet-title tabbable-line">
                                                    <div class="caption">
                                                        <i class="icon-bubbles font-dark hide"></i>
                                                        <span class="caption-subject font-dark bold uppercase">Professionals List</span>
                                                    </div>
                                                </div>
                                                <div class="portlet-body">
                                                    <div class="tab-content">
                                                        <div class="tab-pane active" id="portlet_comments_1">
                                                            <!-- BEGIN: Comments -->
                                                            <div class="mt-comments">
                                                                <?php if(count($professionals) > 0){
                                                                    
                                                                foreach($professionals as $key => $value){
?>
                                                                <div class="mt-comment">
                                                                    
                                                                        <div class="mt-comment-img">
                                                                            <?php if($value['image'] != "") {?>
                                                                            <img src="<?php echo $value['image'];?>" > 
                                                                <?php }else{ ?>
                                                                            <img src="<?php echo base_url();?>assets/img/avatar.jpg" />
                                                                <?php } ?>
                                                                        </div>
                                                                    <div class="mt-comment-body">
                                                                        <div class="mt-comment-info">
                                                                             <span class="mt-comment-author"><?php echo ucfirst($value['first_name']) ." ".ucfirst($value['last_name']); ?></span>
                                                                            <span class="mt-comment-date"><?php echo date('Y-m-d H:i A',strtotime($value['created_on'])) ;?></span>
                                                                        </div>
                                                                        <span class="mt-comment-text">Contact: <?php if($value['mobile'] != "") {echo ucfirst($value['mobile']); } else { echo "-" ;}; ?></span>
                                                                        <br>
                                                                        <div class="mt-comment-text">Email Id: <?php if($value['email'] != "") {echo $value['email']; } else { echo "-" ;};?></div>
                                                                    </div>
                                                                   
                                                                </div>
                                                                <?php }
                                                                } ?>
                                                           </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        
                                        <!--Clients -->
                                        <div class="tab-pane" id="tab_1_4">

                                            <div class="portlet light bordered">
                                                <div class="portlet-title tabbable-line">
                                                    <div class="caption">
                                                        <i class="icon-bubbles font-dark hide"></i>
                                                        <span class="caption-subject font-dark bold uppercase">Clients List</span>
                                                    </div>
                                                </div>
                                                <div class="portlet-body">
                                                    <div class="tab-content">
                                                        <div class="tab-pane active" id="portlet_comments_1">
                                                            <!-- BEGIN: Comments -->
                                                            <div class="mt-comments">
                                                                <?php if(count($clients) > 0){
                                                                    
                                                                foreach($clients as $key => $value){
?>
                                                                <div class="mt-comment">
                                                                    
                                                                        <div class="mt-comment-img">
                                                                            <?php if($value['image'] != "") {?>
                                                                            <img src="<?php echo $value['image'];?>" > 
                                                                <?php }else{ ?>
                                                                            <img src="<?php echo base_url();?>assets/img/avatar.jpg" />
                                                                <?php } ?>
                                                                        </div>
                                                                    <div class="mt-comment-body">
                                                                        <div class="mt-comment-info">
                                                                             <span class="mt-comment-author"><?php echo ucfirst($value['first_name']) ." ".ucfirst($value['last_name']); ?></span>
                                                                            <span class="mt-comment-date"><?php echo date('Y-m-d H:i A',strtotime($value['created_on'])) ;?></span>
                                                                        </div>
                                                                        <span class="mt-comment-text">Contact: <?php if($value['mobile'] != "") {echo ucfirst($value['mobile']); } else { echo "-" ;}; ?></span>
                                                                        <br>
                                                                        <div class="mt-comment-text">Email Id: <?php if($value['email'] != "") {echo $value['email']; } else { echo "-" ;};?></div>
                                                                        
                                                                    </div>
                                                                   
                                                                </div>
                                                                <?php }
                                                                } ?>
                                                           </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <style>
        .profile-userbuttons {
            text-align: center;
            margin-top: 10px;
        }
        .profile-userbuttons .btn:last-child {
            margin-right: 0;
        }.btn.red:not(.btn-outline) {
            color: #fff;
            background-color: #e7505a;
            border-color: #e7505a;
            width:50%;
        }
        .profile-userbuttons button {
            text-transform: uppercase;
            font-size: 11px;
            font-weight: 600;
            padding: 6px 15px;
        }
        .btn-circle {
            border-radius: 25px!important;
            overflow: hidden;
        }
        .btn, .form-control {
            box-shadow: none!important;
        }
        .btn {
            outline: 0!important;
        }
        .mt-comments .mt-comment .mt-comment-img>img {
    border-radius: 50%!important;
    width:40px;
    height:30px;
}
    </style>