<div class="login-page bk-img" style="background-image: url(<?php echo base_url();?>assets/img/login-bg.jpg);">
    <div class="form-content">
        <div class="container">
            <div class="row">
                <div class="col-md-6 col-md-offset-3">
                    <h1 class="text-center text-bold text-light mt-4x">Sign in</h1>
                    <?php
                        if ($this->session->userdata('errorMsg') != "") { 
        //                    ?>

                            <div class="alert alert-danger toBeHidden" role="alert"> 
                                <?php echo $this->session->userdata('errorMsg');
                                    $this->session->unset_userdata('errorMsg');
                                ?>
                            </div>

                            <?php
                        }else{
        //                ?>
                            <div class="success" role="alert"> 
                                <?php echo $this->session->userdata('successMsg');
                                    $this->session->unset_userdata('successMsg');
                                ?>
                            </div>
                        <?php } ?>
                    <div class="well row pt-2x pb-3x bk-light">
                        <div class="col-md-8 col-md-offset-2">
                            <form action="<?php echo base_url();?>admin" method="post" name="loginAdmin" id="loginAdmin" class="mt">

                                <label for="" class="text-uppercase text-sm">Your Username or Email</label>
                                <input type="text" name="username" placeholder="Username" class="form-control mb">

                                <label for="" class="text-uppercase text-sm">Password</label>
                                <input type="password" name="password" placeholder="Password" class="form-control mb">

                                <div class="checkbox checkbox-circle checkbox-info">
                                    <input id="checkbox7" type="checkbox" checked>
                                    <label for="checkbox7">
                                        Keep me signed in
                                    </label>
                                </div>

                                <input class="btn btn-primary btn-block" name="submit" value="Submit" type="submit">
                            </form>
                        </div>
                    </div>
                    <div class="text-center text-light">
                        <a href="<?php echo base_url();?>forgotPassword" class="text-light">Forgot password?</a>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<script>
        jQuery.validator.setDefaults({
            debug: false,
            success: "valid"
        });
            $("#loginAdmin").validate({
                rules: {
                    username: {
                        required: true,
                        email:true
                    },
                    password: {
                        required: true
                    }
                }
            });
       </script>