<link href="http://fonts.googleapis.com/css?family=Open+Sans:400,300,600,700&subset=all" rel="stylesheet" type="text/css" />
        
        <link href="<?php echo base_url(); ?>assets/global/plugins/simple-line-icons/simple-line-icons.min.css" rel="stylesheet" type="text/css" />
        <link href="<?php echo base_url(); ?>assets/global/plugins/bootstrap/css/bootstrap.min.css" rel="stylesheet" type="text/css" />
        <link href="<?php echo base_url(); ?>assets/global/plugins/bootstrap-switch/css/bootstrap-switch.min.css" rel="stylesheet" type="text/css" />
        <!-- END GLOBAL MANDATORY STYLES -->
        <!-- BEGIN PAGE LEVEL PLUGINS -->
        <link href="<?php echo base_url(); ?>assets/global/plugins/bootstrap-fileinput/bootstrap-fileinput.css" rel="stylesheet" type="text/css" />
        <!-- END PAGE LEVEL PLUGINS -->
        <!-- BEGIN THEME GLOBAL STYLES -->
        <link href="<?php echo base_url(); ?>assets/global/css/components.min.css" rel="stylesheet" id="style_components" type="text/css" />
        <link href="<?php echo base_url(); ?>assets/global/css/plugins.min.css" rel="stylesheet" type="text/css" />
        <!-- END THEME GLOBAL STYLES -->
        <!-- BEGIN PAGE LEVEL STYLES -->
        <link href="<?php echo base_url(); ?>assets/pages/css/profile.min.css" rel="stylesheet" type="text/css" />
        <!-- END PAGE LEVEL STYLES -->
        <!-- BEGIN THEME LAYOUT STYLES -->
        <link href="<?php echo base_url(); ?>assets/layouts/layout/css/layout.min.css" rel="stylesheet" type="text/css" />
        <link href="<?php echo base_url(); ?>assets/layouts/layout/css/themes/darkblue.min.css" rel="stylesheet" type="text/css" id="style_color" />
        <link href="<?php echo base_url(); ?>assets/layouts/layout/css/custom.min.css" rel="stylesheet" type="text/css" />
         
<div class="content-wrapper">
    <div class="container-fluid" style="background-color:#b4bcc8;">
        <h3 class="page-title" style="font-size:25px;margin-top:10px;color:#fff;"> User Profile | Account
                    </h3>
        
            <div class="row">
                        <div class="col-md-12">
                            <!-- BEGIN PROFILE SIDEBAR -->
                            <div class="profile-sidebar">
                                <!-- PORTLET MAIN -->
                                <div class="portlet light profile-sidebar-portlet " style="height:300px ! important;">
                                    <!-- SIDEBAR USERPIC -->
                                    <div class="profile-userpic">
                                        <?php if($userDetail['image'] != ""){?>
                                            <img src="<?php echo base_url().$userDetail['image']; ?>" class="img-responsive" alt=""> 
                                        <?php } else { ?>
                                            <img src="<?php echo base_url();?>assets/img/avatar.jpg" class="img-responsive" alt=""> 
                                        <?php }?>
                                    </div>
                                    <!-- END SIDEBAR USERPIC -->
                                    <!-- SIDEBAR USER TITLE -->
                                    <div class="profile-usertitle">
                                        <?php if($userDetail['first_name'] != ""){ ?>
                                            <div class="profile-usertitle-name"> <?php echo ucfirst($userDetail['first_name'])." ".ucfirst($userDetail['last_name']);?> </div>
                                        <?php } ?>
                                        <div class="profile-usertitle-job"> <?php if($userDetail['user_type']=='3'){ echo "Store Admin";}
                                              else if($userDetail['user_type']=='1'){ echo "Professional";}
                                              else if($userDetail['user_type']=='2'){ echo "User";}else {echo "User";}?> </div>
                                    </div>
                                    <!-- END SIDEBAR USER TITLE -->
                                    <div class="profile-userbuttons">
                                        <button type="button" class="btn btn-circle red btn-sm">Message</button>
                                    </div>
                                    
                                </div>
                                
                                
                                <!-- END PORTLET MAIN -->
                            </div>
                            <!-- END BEGIN PROFILE SIDEBAR -->
                            <!-- BEGIN PROFILE CONTENT -->
                            <div class="profile-content">
                                <div class="row">
                                    <div class="col-md-12">
                                        <div class="portlet light ">
                                            <div class="portlet-title tabbable-line">
                                                <div class="caption caption-md">
                                                    <i class="icon-globe theme-font hide"></i>
                                                    <span class="caption-subject font-blue-madison bold uppercase">Profile Account</span>
                                                </div>
                                                <ul class="nav nav-tabs">
                                                    <li class="active">
                                                        <a href="#tab_1_1" data-toggle="tab">Personal Info</a>
                                                    </li>
                                                    <li>
                                                        <a href="#tab_1_2" data-toggle="tab">Services</a>
                                                    </li>
                                                    <li>
                                                        <a href="#tab_1_3" data-toggle="tab">Professionals</a>
                                                    </li>
                                                </ul>
                                            </div>
                                            <div class="portlet-body">
                                                <div class="tab-content">
                                                    <!-- PERSONAL INFO TAB -->
                                                    <div class="tab-pane active" id="tab_1_1">
                                                        <form role="form" action="#">
                                                            <div class="form-group">
                                                                <label class="control-label">First Name</label>
                                                                <input type="text" class="form-control" readonly="true" value="<?php if($userDetail['first_name']!=""){ echo ucfirst($userDetail['first_name']); } else { echo "-" ;} ?>"> </div>
                                                            <div class="form-group">
                                                                <label class="control-label">Last Name</label>
                                                                <input type="text" class="form-control" readonly="true" value="<?php if($userDetail['last_name'] != ""){ echo ucfirst($userDetail['last_name']); } else{ echo "-";} ?>"> </div>
                                                            <div class="form-group">
                                                                <label class="control-label">Mobile Number</label>
                                                                <input type="text" readonly="true" value="<?php if($userDetail['mobile'] != ""){ echo ucfirst($userDetail['mobile']); } else{ echo "-";} ?>" class="form-control"> </div>
                                                            <div class="form-group">
                                                                <label class="control-label">Address</label>
                                                                <input type="text" readonly="true" value="<?php if($userDetail['address'] != ""){ echo ucfirst($userDetail['address']); } else{ echo "-";} ?>" class="form-control"> </div>
                                                            <div class="form-group">
                                                                <label class="control-label">Email</label>
                                                                <input type="text" readonly="true" value="<?php if($userDetail['email'] != ""){ echo ucfirst($userDetail['email']); } else{ echo "-";} ?>" class="form-control"> </div>
                                                            <div class="form-group">
                                                                <label class="control-label">Country</label>
                                                                <input type="text" readonly="true" value="<?php if($userDetail['country'] != ""){ echo ucfirst($userDetail['country']); } else{ echo "-";} ?>" class="form-control"> </div>
                                                           
                                                            <div class="form-group">
                                                                <label class="control-label">Date Of Birth</label>
                                                                <input type="text" readonly="true" value="<?php if($userDetail['dob'] != ""){ echo ucfirst($userDetail['dob']); } else{ echo "-";} ?>" class="form-control"> </div>
                                                        </form>
                                                    </div>
                                                    
                                                    <div class="tab-pane" id="tab_1_2">

                                            <div class="portlet light bordered">
                                                <div class="portlet-title tabbable-line">
                                                    <div class="caption">
                                                        <i class="icon-bubbles font-dark hide"></i>
                                                        <span class="caption-subject font-dark bold uppercase">Services List</span>
                                                    </div>
                                                </div>
                                                <div class="portlet-body">
                                                    <div class="tab-content">
                                                        <div class="tab-pane active" id="portlet_comments_1">
                                                            <!-- BEGIN: Comments -->
                                                            <div class="mt-comments">
                                                                <?php if(count($serviceDetail) > 0){
                                                                    ?>
                                                                <div class="mt-comment">
                                                                    <div class="mt-comment-body">
                                                                        <div class="mt-comment-info">
                                                                            <div> <b>Last Service Detail : </b></div>
                                                                            <br><span></span>
                                                                            <span class="mt-comment-author"><?php echo ucfirst($serviceDetail['service_name']); ?></span>
                                                                            <span class="mt-comment-date"><?php echo date('Y-m-d H:i A',strtotime($serviceDetail['created_on'])) ;?></span>
                                                                        </div>
                                                                        <span class="mt-comment-text">Cost: <?php echo ucfirst($serviceDetail['price']); ?></span>
                                                                        
                                                                        <div class="mt-comment-text">Description: <?php echo $serviceDetail['service_description']; ?></div>
                                                                        
                                                                        <div class="mt-comment-text">No of Seats: <?php echo $serviceDetail['no_of_seat']; ?></div>
                                                                        
                                                                        <div class="mt-comment-text">Service Time: <?php echo $serviceDetail['service_time']; ?></div>
                                                                    </div>
                                                                </div>
                                                                <?php }
                                                                 ?>
        </div>
                                                            
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                                    <!-- -->
                                                    <div class="tab-pane" id="tab_1_3">

                                            <div class="portlet light bordered">
                                                <div class="portlet-title tabbable-line">
                                                    <div class="caption">
                                                        <i class="icon-bubbles font-dark hide"></i>
                                                        <span class="caption-subject font-dark bold uppercase">Professionals List</span>
                                                    </div>
                                                </div>
                                                <div class="portlet-body">
                                                    <div class="tab-content">
                                                        <div class="tab-pane active" id="portlet_comments_1">
                                                            <!-- BEGIN: Comments -->
                                                            <div class="mt-comments">
                                                                <?php if(count($recentProfessions) > 0){
                                                                    foreach($recentProfessions as $key => $val){
                                                                    ?>
                                                                <div class="mt-comment">
                                                                    <div class="mt-comment-body">
                                                                        <div class="mt-comment-info">
                                                                            <span class="mt-comment-author"><?php echo ucfirst($val['first_name'])." ".ucfirst($val['last_name']); ?></span>
                                                                            <span class="mt-comment-date"><?php echo date('Y-m-d H:i A',strtotime($val['created_on'])) ;?></span>
                                                                        </div>
                                                                        <span class="mt-comment-text">Email Id: <?php echo ucfirst($val['email']); ?></span>
                                                                        
                                                                        <div class="mt-comment-text">Contact: <?php echo $val['mobile']; ?></div>
                                                                        
                                                                    </div>
                                                                </div>
                                                                <?php }
                                                                }
                                                                 ?>
        </div>
                                                            
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                                    
                                                    </div>
                                                    <!-- END PERSONAL INFO TAB -->
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
    </div>
</div>
    </div>
    <style>
        .profile-userbuttons {
    text-align: center;
    margin-top: 10px;
}
        .profile-userbuttons .btn:last-child {
    margin-right: 0;
}.btn.red:not(.btn-outline) {
    color: #fff;
    background-color: #e7505a;
    border-color: #e7505a;
    width:50%;
}
 .profile-userbuttons button {
    text-transform: uppercase;
    font-size: 11px;
    font-weight: 600;
    padding: 6px 15px;
}
    .btn-circle {
    border-radius: 25px!important;
    overflow: hidden;
}
    .btn, .form-control {
    box-shadow: none!important;
}
    .btn {
    outline: 0!important;
}</style>