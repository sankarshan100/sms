<div class="content-wrapper">
    <div class="container-fluid">

        <div class="row">
            <div class="col-md-12">

                <h2 class="page-title">Stores Management</h2>
                
                <!-- Zero Configuration Table -->
                <div class="panel panel-default">
                    <div class="panel-heading">Store List View</div>
                    <div class="panel-body">
                        <div class="note note-success">
                            <h4 class="block"></h4>
                            <p style="font-size: 15px;color:green;text-align: center;">
                                <?php 
                                    if($this->session->userdata('errorMsg') != ""){
                                       echo $this->session->userdata('errorMsg');
                                       $this->session->unset_userdata('errorMsg');
                                    }

                                    if($this->session->userdata('successMsg') != ""){
                                       echo $this->session->userdata('successMsg');
                                       $this->session->unset_userdata('successMsg');
                                    }
                                ?>
                            </p>
                        </div>
                        <table id="zctb" class="display table table-striped table-bordered table-hover" cellspacing="0" width="100%">
                            <thead>
                                <tr>
                                    <th>Name</th>
                                    <th>Address</th>
                                    <th>Mobile Number</th>
                                    <th>Open Time</th>
                                    <th>Close Time</th>
                                    <th>Action</th>
                                </tr>
                            </thead>

                            <tbody>
                                <?php foreach ($stores as $key=>$value){ ?>
                                <tr>
                                    <td><?php echo $value['name']; ?></td>
                                    <td><?php echo $value['address']; ?></td>
                                    <td><?php echo $value['mobile']; ?></td>
                                    <td><?php echo $value['store_open_time']; ?></td>
                                    <td><?php echo $value['store_close_time']; ?></td>
                                    <td><div class="col-md-4 col-sm-6 col-lg-3">
                                           <a href = "<?php echo base_url(); ?>view_store_detail?store_id=<?php echo $value['id']?>" style="color:#000;">
                                                <i class="fa fa-eye"></i> 
                                            </a> </div>
                                        <div class="col-md-4 col-sm-6 col-lg-3">
<a href="<?php echo base_url();?>delete_store?store_id=<?php echo $value['id'] ?>" onclick='return confirm("Are you sure you want to delete this store?")' style="color:#000;"><i class="fa fa-fw"></i> </a> 
                                        </div>

                                    </td>
                                </tr>
                                <?php }?>
                                
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
</div>