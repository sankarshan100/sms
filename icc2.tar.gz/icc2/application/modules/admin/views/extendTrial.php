<div class="content-wrapper">
    <div class="container-fluid">
        <div class="row">
            <div class="col-md-12">
                    <h2 class="page-title">Extend User Trail Period for few months </h2>
                        <div class="portlet-body">
                                    <div class="note note-success">
                                        <h4 class="block"></h4>
                                        <p style="font-size: 15px;color:green;text-align: center;">
                                            <?php 
                                                if($this->session->userdata('errorMsg') != ""){
                                                   echo $this->session->userdata('errorMsg');
                                                   $this->session->unset_userdata('errorMsg');
                                                }
                                                
                                                if($this->session->userdata('successMsg') != ""){
                                                   echo $this->session->userdata('successMsg');
                                                   $this->session->unset_userdata('successMsg');
                                                }
                                            ?>
                                        </p>
                                    </div>
                                    <form class="form-horizontal" method="post" name="send_notification_form" id="send_notification_form" action="">
                                        <input type="hidden" name="user_id" value="<?php echo $this->input->get('user_id')?>" />
                                        <div class="form-group">
                                            <label class="col-md-3 control-label" for="title">Trail Period</label>
                                            <div class="col-md-5">
                                                <input id="notific8_text" type="text" class="form-control" value="" name="period" id="period" placeholder="Enter the month in integers ..."> </div>
                                        </div>
                                        
                                        <div class="form-group">
                                            <label class="col-md-3 control-label" for="title"></label>
                                            <div class="col-md-3">
                                                <input type="submit" name="submit" class="btn purple btn-block" value="Submit" style="background: #3e454c;color:#fff;font-size:16px;">
                                            </div>
                                        </div>
                                    </form>
                                </div>
                     </div>
            </div>
        </div>
</div>