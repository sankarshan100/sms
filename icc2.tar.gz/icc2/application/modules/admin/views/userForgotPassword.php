<div class="login-page bk-img" style="background-image: url(<?php echo base_url();?>assets/img/login-bg.jpg);">
    <div class="form-content">
        <div class="container">
            <div class="row">
                <div class="col-md-6 col-md-offset-3">
                    <h1 class="text-center text-bold text-light mt-4x">Change Password</h1>
                    <div class="well row pt-2x pb-3x bk-light">
                        <div class="col-md-8 col-md-offset-2">
                            <form action="<?php echo base_url();?>userForgotPassword" method="post" name="userForgotPassword" id="userForgotPassword" class="mt">

                                
                                <label class="text-uppercase text-sm">New Password</label>
                                <input type="password" class="form-control mb" name="new_password" id="new_password" placeholder="">
                          

                            
                                <label class="text-uppercase text-sm">Re-enter Password</label>
                                <input type="password" class="form-control mb" name="confirm_password" id="confirm_password" placeholder="">
                            
                                
                                <input type="hidden" name="userEmail" value="<?php echo base64_decode(trim($this->input->get('email'))); ?>" />
                                <input class="btn btn-primary btn-block" type="submit" name="submit" value="Save">
                           
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<script src="<?php echo base_url();?>js/jquery.validate.js"></script>
        <script>
        jQuery.validator.setDefaults({
            debug: false,
            success: "valid"
        });
            
              $("#userForgotPassword").validate({
                rules: {
                    
                    new_password: {
                        required: true
                    },
                    confirm_password: {
                        required: true,
                        equalTo: "#new_password"
                    }
                }
            });
       </script>
       </body>
</html>