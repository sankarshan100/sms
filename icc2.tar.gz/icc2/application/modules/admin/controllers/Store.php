<?php
/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
class Store extends MX_Controller{
    public function __construct() {
        parent::__construct();
        $this->load->model('Store_model');
    }
    
   //all active store details
    public function manageStores(){
        $this->load->model('User_model');
        $userObj = new User_model();
        $data['stores'] = $userObj->getAllStores();
        $data['header']         = array('view' => 'templates/header', 'data' => $data);
        $data['sidebar']        = array('view' => 'templates/common_sidebar', 'data' => $data);
        $data['main_content']   = array('view' => 'manageStores', 'data' => $data);
        $data['footer']         = array('view' => 'templates/footer', 'data' => $data);
        $this->load->view('templates/common_template', $data);
        
    }
    
    //all active services of particular store
    public function allServices(){
        $data['header']         = array('view' => 'templates/header', 'data' => $data);
        $data['sidebar']         = array('view' => 'templates/common_sidebar', 'data' => $data);
        $data['main_content']   = array('view' => 'storeServices', 'data' => $data);
        $data['footer']         = array('view' => 'templates/footer', 'data' => $data);
        $this->load->view('templates/common_template', $data);
    }
    
    //edit user section
    public function editStore(){
        $data['header']         = array('view' => 'templates/header', 'data' => $data);
        $data['sidebar']        = array('view' => 'templates/common_sidebar', 'data' => $data);
        $data['main_content']   = array('view' => 'editStore', 'data' => $data);
        $data['footer']         = array('view' => 'templates/footer', 'data' => $data);
        $this->load->view('templates/common_template', $data);
    }
    
    public function getStoreDetail(){
        /* get user detailed infomration */
        $storeObj = new Store_model();
        $data['storeDetail'] = $storeObj->getStoreDetail($this->input->get('store_id'));
        
        //get services list provided by store
        $data['services'] = $storeObj->servicesDetail($data['storeDetail']['services']);
        
        //get all professionals attached with that particular store
        $data['professionals'] = $storeObj->professionalsDetail($data['storeDetail']['professionals']);
        
        //clients list
        $data['clients'] = $storeObj->clientLists($this->input->get('store_id'));
        
        $data['header']         = array('view' => 'templates/header', 'data' => $data);
        $data['sidebar']        = array('view' => 'templates/common_sidebar', 'data' => $data);
        $data['main_content']   = array('view' => 'storeDetail', 'data' => $data);
        $data['footer']         = array('view' => 'templates/footer', 'data' => $data);
        $this->load->view('templates/common_template', $data);
    }
    
    public function deleteStore(){
        /* get user detailed infomration */
        $storeObj = new Store_model();
        $is_deleted = $storeObj->deleteStore($this->input->get('store_id'));
        if($is_deleted == TRUE){
            $this->session->set_userdata('successMsg','Store deleted successfully');
            redirect('manage_stores');
        }
    }
    
     //all active store details
    public function manageAppointments(){
        $this->load->model('Store_model');
        $storeObj = new Store_model();

if($this->input->get('from') != ""){
            $from = $this->input->get('from');
        }
        if($this->input->get('to') != ""){
            $to = $this->input->get('to');
        }
        $data['appointments'] = $storeObj->getAllAppointments($from,$to);
        //echo "<pre>";print_r($data['appointments']);die;
        
        $data['header']         = array('view' => 'templates/header', 'data' => $data);
        $data['sidebar']        = array('view' => 'templates/common_sidebar', 'data' => $data);
        $data['main_content']   = array('view' => 'manageAppointments', 'data' => $data);
        $data['footer']         = array('view' => 'templates/footer', 'data' => $data);
        $this->load->view('templates/common_template', $data);
        
    }
    
     //all active store details
    public function updateStatus(){
        $this->load->model('Store_model');
        $storeObj = new Store_model();
        $isUpdated = $storeObj->updateStatus($this->input->get('appointment_id'),$this->input->get('status'));
        if($isUpdated == TRUE){
            if($this->input->get('status') == '1'){
                $this->session->set_userdata('successMsg','Appointment is accepted successfully');
            }else{
                $this->session->set_userdata('successMsg','Appointment is cancelled successfully');
            }
            redirect('manage_appointments');
        }
        
        $data['header']         = array('view' => 'templates/header', 'data' => $data);
        $data['sidebar']        = array('view' => 'templates/common_sidebar', 'data' => $data);
        $data['main_content']   = array('view' => 'manageAppointments', 'data' => $data);
        $data['footer']         = array('view' => 'templates/footer', 'data' => $data);
        $this->load->view('templates/common_template', $data);
        
    }
}

