<?php
/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
class User extends MX_Controller{
    public function __construct() {
        parent::__construct();
        $this->load->model('User_model');
        $this->load->library('form_validation');
        $this->load->helper('user_helper');
        $this->load->helper('csv_helper');
    }
    
    //user management section
    public function manageUsers(){
        $userObj = new User_model();
        if($this->input->get('gender') != ""){
            $userObj->setGender($this->input->get('gender'));
        }
        if($this->input->get('user_type') != ""){
            $userObj->setUser_type($this->input->get('user_type'));
        }
        if($this->input->get('from') != ""){
            $userObj->setFrom($this->input->get('from'));
        }
        if($this->input->get('to') != ""){
            $userObj->setTo($this->input->get('to'));
        }
        $data['users'] = $userObj->getAllActiveUsers();
        
        //array_to_csv($data['users'],'Users_'.date('dMy').'.csv');
        
        //echo "users";echo "<pre>";print_r($data);die;
        $data['header']         = array('view' => 'templates/header', 'data' => $data);
        $data['sidebar']        = array('view' => 'templates/common_sidebar', 'data' => $data);
        $data['main_content']   = array('view' => 'manageUsers', 'data' => $data);
        $data['footer']         = array('view' => 'templates/footer', 'data' => $data);
        $this->load->view('templates/common_template', $data);
    }
    
    //edit user section
    public function editUser(){
        $data['header']         = array('view' => 'templates/header', 'data' => $data);
        $data['sidebar']        = array('view' => 'templates/common_sidebar', 'data' => $data);
        $data['main_content']   = array('view' => 'editUser', 'data' => $data);
        $data['footer']         = array('view' => 'templates/footer', 'data' => $data);
        $this->load->view('templates/common_template', $data);
        
    }
    
    //Send User notification or email section
    public function sendNotification(){
        if($this->input->post('submit') == 'Send'){
            //SET VALIDATION RULES
            $this->form_validation->set_rules('title', 'title', 'required');
            $this->form_validation->set_rules('message', 'message', 'required');
            $this->form_validation->set_rules('send_type[]', 'send_type', 'required');
            if ($this->form_validation->run() == FALSE)
            {   
                $this->session->set_userdata('errorMsg',validation_errors());
                redirect(base_url()."send_notification");
            }
            
            /* get user detailed infomration */
            $userObj = new User_model();
            $userDetail = $userObj->getUserDetail($this->input->post('user_id'));
            
            /*** send email function **/
            $subject = $this->input->post('title');
            $message = $this->input->post('message');
            $from_email = "admin@admin.com";
            $to_email = $userDetail['email'];
            
            if($this->input->post('send_type') != ""){
                $sendType = $this->input->post('send_type');
                if(count($sendType) > 1){
                   
                    //send both push notification & email
                    /*** send email function **/
                    sendEmailGlobal($from_email="sankarshan@techaheadcorp.com",$to_email,$subject,$message);
                    
                    /** send push **/
                    generatePush($userDetail['device_type'], $userDetail['device_token'], $message);
                    
                    $this->session->set_userdata('successMsg','Push notification and email sent successfully');
                    
                }elseif($sendType[0] == 1){
                   
                    /** send push **/
                    generatePush($userDetail['device_type'], $userDetail['device_token'], $message);
                    $this->session->set_userdata('successMsg','Push notification sent successfully');
                }else{
                    /*** send email function **/
                    sendEmailGlobal($from_email,$to_email,$subject,$message);
                    $this->session->set_userdata('successMsg','Email sent successfully');
                }
            }
        }
        $data['header']         = array('view' => 'templates/header', 'data' => $data);
        $data['sidebar']        = array('view' => 'templates/common_sidebar', 'data' => $data);
        $data['main_content']   = array('view' => 'sendNotification', 'data' => $data);
        $data['footer']         = array('view' => 'templates/footer', 'data' => $data);
        $this->load->view('templates/common_template', $data);
        
    }
    
    //function to extend the users trial period
    public function extendTrailPeriod(){
        if($this->input->post('user_id') != ""){
            
             //SET VALIDATION RULES
            $this->form_validation->set_rules('period', 'period', 'required');
            if ($this->form_validation->run() == FALSE)
            {   
                $this->session->set_userdata('errorMsg',validation_errors());
                redirect(base_url()."extend_trail_period?user_id=".$this->input->post('user_id'));
            }
            /* get user detailed infomration */
            $userObj = new User_model();
            $userDetail = $userObj->getUserDetail($this->input->post('user_id'));
            
            if($userDetail['end_date'] == ""){
                $endDate = date('Y-m-d H:i:s');
            }else{
                $endDate = $userDetail['end_date'];
            }
            $months = $this->input->post('period');
            $newExpiry = date('Y-m-d H:i:s', strtotime("+$months months", strtotime($endDate)));
            
            //update user new expiry time
            if($userObj->updateNewExpiry($newExpiry,$this->input->post('user_id')) == TRUE){
                $this->session->set_userdata('successMsg','Expiry time updated successfully');
                redirect('manage_users');
            }
        }
        $data['header']         = array('view' => 'templates/header', 'data' => $data);
        $data['sidebar']        = array('view' => 'templates/common_sidebar', 'data' => $data);
        $data['main_content']   = array('view' => 'extendTrial', 'data' => $data);
        $data['footer']         = array('view' => 'templates/footer', 'data' => $data);
        $this->load->view('templates/common_template', $data);
    }
    
    //function to get the user detail
    public function getUserDetail(){
        /* get user detailed infomration */
        $userObj = new User_model();
        $data['userDetail'] = $userObj->getUserDetail($this->input->get('user_id'));

        //last service detail info where service_id not to be 0
        $data['serviceDetail'] = $userObj->lastServiceDetail($this->input->get('user_id'));
        
        //recent get 5 professionals and related stores
        $data['recentProfessions'] = $userObj->recentProfessions($this->input->get('user_id'));
        
        $data['header']         = array('view' => 'templates/header', 'data' => $data);
        $data['sidebar']        = array('view' => 'templates/common_sidebar', 'data' => $data);
        $data['main_content']   = array('view' => 'userDetail', 'data' => $data);
        $data['footer']         = array('view' => 'templates/footer', 'data' => $data);
        $this->load->view('templates/common_template', $data);
    }
    
    public function deleteUser(){
        $userObj = new User_model();
        $is_deleted = $userObj->deleteUser($this->input->get('user_id'));
        if($is_deleted == TRUE){
            $this->session->set_userdata('successMsg',"User deleted successfully");
            redirect('manage_users');
        }
    }
    
    public function exportUsers(){
        $userObj = new User_model();
        if($this->input->get('gender') != ""){
            $userObj->setGender($this->input->get('gender'));
        }
        if($this->input->get('user_type') != ""){
            $userObj->setUser_type($this->input->get('user_type'));
        }
        if($this->input->get('from') != ""){
            $userObj->setFrom($this->input->get('from'));
        }
        if($this->input->get('to') != ""){
            $userObj->setTo($this->input->get('to'));
        }
        $data['users'] = $userObj->getAllActiveUsers();
        //echo "<pre>";print_r($data['users']);die;
        $var = array_to_csv($data['users'],'Users_'.date('dMy').'.csv');
    }
}

