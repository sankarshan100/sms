<?php
/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
class Feedback extends MX_Controller{
    public function __construct() {
        parent::__construct();
        $this->load->model('Feedback_model');
        $this->load->library('form_validation');
        $this->load->helper('user_helper');
    }
    
    //user management section
    public function manageFeedbacks(){
        $feedbackObj = new Feedback_model();
        if($this->input->get('feedback_type') != ""){
            $feedbackObj->setFeedback_type($this->input->get('feedback_type'));
        }
        $data['lists'] = $feedbackObj->getFeedbacks();
        
        $data['header']         = array('view' => 'templates/header', 'data' => $data);
        $data['sidebar']        = array('view' => 'templates/common_sidebar', 'data' => $data);
        $data['main_content']   = array('view' => 'manageFeedbacks', 'data' => $data);
        $data['footer']         = array('view' => 'templates/footer', 'data' => $data);
        $this->load->view('templates/common_template', $data);
    }
 
     //user management section
    public function replyFeedback(){
        $feedbackObj = new Feedback_model();
        
        if($this->input->post('submit') == 'Submit'){
         //SET VALIDATION RULES
            $this->form_validation->set_rules('reply', 'reply', 'required');
            if ($this->form_validation->run() == FALSE)
            {  
                $this->session->set_userdata('errorMsg',validation_errors());
                redirect(base_url()."reply_feedback?feedback_id=".$this->input->post('feedback_id')."&user_id=".$this->input->post('user_id')."&feedback_type=".$this->input->post('feedback_type')."&user_type=".$this->input->post('user_type'));
            }

            //send reply to user
            if($this->input->post('reply') != ""){
                $feedbackObj->setFeedback($this->input->post('reply'));
                $feedbackObj->replyFeedback($this->input->post('feedback_id'),$this->input->post('reply'),$this->input->post('user_id'),$this->input->post('feedback_type'),$this->input->post('user_type'));
                $this->session->set_userdata('successMsg','Reply sent successfully');
                redirect('manage_feedbacks');
            }
        }
        
        $data['messages'] = $feedbackObj->getConversationFeedback($this->input->get('user_id'));
        
        $data['header']         = array('view' => 'templates/header', 'data' => $data);
        $data['sidebar']        = array('view' => 'templates/common_sidebar', 'data' => $data);
        $data['main_content']   = array('view' => 'replyFeedback', 'data' => $data);
        $data['footer']         = array('view' => 'templates/footer', 'data' => $data);
        $this->load->view('templates/common_template', $data);
    }
    
    public function deleteFeedback(){
        $feedbackObj = new Feedback_model();
        $is_deleted =$feedbackObj->deleteFeedback($this->input->get('user_id'));
        if($is_deleted == TRUE){
            $this->session->set_userdata('successMsg','Feedback deleted successfully');
            redirect('manage_feedbacks');
        }
    }
}

