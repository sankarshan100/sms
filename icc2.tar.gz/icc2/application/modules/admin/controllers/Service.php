<?php

/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
class Service extends MX_Controller{
    public function __construct() {
        parent::__construct();
        $this->load->model('Services_model');
    }
    
    //all services list
    public function manageServices(){
        $serviceObj = new Services_model();
        $data['services'] = $serviceObj->getAllServices();
        $data['header']         = array('view' => 'templates/header', 'data' => $data);
        $data['sidebar']        = array('view' => 'templates/common_sidebar', 'data' => $data);
        $data['main_content']   = array('view' => 'manageServices', 'data' => $data);
        $data['footer']         = array('view' => 'templates/footer', 'data' => $data);
        $this->load->view('templates/common_template', $data);
    }
    
    //function to get information for particualr service
    public function getServiceDetail(){
        $serviceObj = new Services_model();
        if($this->input->post('submit') == 'Save Changes'){
            //SET VALIDATION RULES
            $this->form_validation->set_rules('service_name', 'service_name', 'required');
            if ($this->form_validation->run() == FALSE)
            {   
                $this->session->set_userdata('errorMsg',validation_errors());
                redirect(base_url()."view_service_detail?service_id=".$this->input->post('service_id'));
            }
            
            //update the service name
            $isUpdated = $serviceObj->updateService($this->input->post('service_id'),$this->input->post('service_name'));
            if($isUpdated == TRUE){
                $this->session->set_userdata('successMsg','Service name is updated successfully');
                redirect(base_url()."manage_services");
            }
            
        }
        //service info
        $data['serviceInfo']   = $serviceObj->serviceDetail($this->input->get('service_id'));

        //store related to particular providing service
        $data['storeServices'] = $serviceObj->storeRelatedServiceDetail($this->input->get('service_id'));
        
        $data['header']         = array('view' => 'templates/header', 'data' => $data);
        $data['sidebar']        = array('view' => 'templates/common_sidebar', 'data' => $data);
        $data['main_content']   = array('view' => 'serviceDetail', 'data' => $data);
        $data['footer']         = array('view' => 'templates/footer', 'data' => $data);
        $this->load->view('templates/common_template', $data);
    }
    
    public function deleteService(){
        /* get user detailed infomration */
        $serviceObj = new Services_model();
        $is_deleted = $serviceObj->deleteService($this->input->get('service_id'));
        if($is_deleted == TRUE){
            $this->session->set_userdata('successMsg','Service deleted successfully');
            redirect('manage_services');
        }
    }
}
