<?php
class Index extends MX_Controller{
     function __construct() {

        $this->load->library('form_validation');
        
        $this->load->library('email');
        $this->load->helper('form');
        $this->load->helper('url');
        $this->load->library("pagination");
        $this->load->library('encrypt');
        $this->load->helper('date');
        $this->lang->load("en");
        $this->load->model('Admin_model');
        $this->load->model('User_model');
    }

    public function login() {
        if($this->input->post('submit') == 'Submit'){ 
            $loginObj = new Admin_model();
            $loginObj->setEmail(trim($_POST['username']));
            $loginObj->setPassword(md5(trim($_POST['password'])));
            $adminLogin = $loginObj->checkAdminLogin(); //check for admin exists (login credentials)
            //print_r($adminLogin);die;
            if(count($adminLogin) > 0){ 
                $this->session->set_userdata('loginDetails',$adminLogin);
                redirect('dashboard');
            }else{ 
                $this->session->set_userdata('errorMsg', $this->lang->line('invalid_data'));
                redirect(base_url()."admin");
            }
        }
        $data['header']         = array('view' => 'templates/login_header', 'data' => $data);
        $data['main_content']   = array('view' => 'login', 'data' => $data);
        $data['footer']         = array('view' => 'templates/footer', 'data' => $data);
        $this->load->view('templates/login_template', $data);
    }
    
    public function dashboard() {
        $userObj = new User_model();
        $data['users'] = $userObj->getDashboardUsers();
        $data['header']         = array('view' => 'templates/header', 'data' => $data);
        $data['sidebar']        = array('view' => 'templates/common_sidebar', 'data' => $data);
        $data['main_content']   = array('view' => 'dashboard', 'data' => $data);
        $data['footer']         = array('view' => 'templates/footer', 'data' => $data);
        $this->load->view('templates/common_template', $data);
    }
    
    //forgot password display
    public function forgotPassword(){
        if($this->input->post('send') == 'Send'){ 
            $forgotPwdObj = new Admin_model();
            $forgotPwdObj->setEmail(trim($this->input->post('username')));
            if($forgotPwdObj->checkEmailExist()){
               
            }else{
                $this->session->set_userdata('errorMsg',$this->lang->line('invalid_email'));
                redirect(base_url()."forgotPassword");
            }
            //encode email
            $encodedEmail = base64_encode(trim($this->input->post('username')));
            
            $link         = $this->config->base_url()."userForgotPassword?email=".$encodedEmail;
             
            $config['wordwrap']     = TRUE;
            $config['mailtype']     = 'html';
            $this->load->library('email');
            $this->email->initialize($config);
            $this->email->from('sms', 'SMSApp');
            $this->email->to(trim($this->input->post('username')));
            $this->email->subject('Password Reset Link');
            $emailMessage   ='<div style="max-width:640px; margin:auto; padding:0 20px;border:1px solid #d4d2d2;">
                                <p style="text-align:center;margin:30px 0 30px 0;">
                                        <p style="color:#c51225;font-weight:bold;   font-size:25px; text-align:center; margin:0px;">Weather Mix App<span style="color:#256d95; font-size:25px;"></span></p>
                                </p>  
                                <p style="font-size:14px; font-family:Verdana, Geneva, sans-serif; color:#202020; margin:20px 0;">Hello ,</p>
                                <p style="font-size:14px; font-family:Verdana, Geneva, sans-serif; color:#202020; margin:20px 0;"></p>     
                                <p style="font-size:14px; font-family:Verdana, Geneva, sans-serif; color:#202020; margin:20px 0;"><a href="'.$link.'">Click Here</a></b></p>
                                <p style="font-size:14px; font-family:Verdana, Geneva, sans-serif; color:#202020; margin:20px 0;">OR copy the link given below in you web browser address bar.</p>  
                                <p style="font-size:14px; font-family:Verdana, Geneva, sans-serif; color:#202020; margin:20px 0;"><a href="'.$link.'">'.$link.'</a></p>      
                                <p style="font-size:14px; font-family:Verdana, Geneva, sans-serif; color:#202020; margin:20px 0;">Warm Regards,<br />
                        WeatherMix</p>
                            </div>';
            
            $this->email->message($emailMessage);

            $this->email->send();
            $this->session->set_userdata('SuccessMsg',$this->lang->line('forgot_email'));
            redirect('admin');
        }
        $data['header']         = array('view' => 'templates/login_header', 'data' => $data);
        $data['main_content']   = array('view' => 'forgotPassword', 'data' => $data);
        $data['footer']         = array('view' => 'templates/footer', 'data' => $data);
        $this->load->view('templates/login_template', $data);
    }
    
    //reset password 
    public function userForgotPassword(){ 
        $userEmail = base64_decode(trim($this->input->get('email')));
        if($this->input->post('submit') == 'Save'){
            $adminLoginObj = new Admin_model();
            $adminLoginObj->setEmail($this->input->post('userEmail'));
            $adminLoginObj->setNew_password($this->input->post('new_password'));
            
            if($adminLoginObj->setNewPassword()){ 
               $this->session->set_userdata('successMsg',$this->lang->line('password_changed'));
                   redirect("admin");
               }else{ 
                   $this->session->set_userdata('errorMsg',$this->lang->line('error_password'));
                   redirect('userForgotPassword'); 
               }

        }

        $data['header']         = array('view' => 'templates/login_header', 'data' => $data);
        $data['main_content']   = array('view' => 'userForgotPassword', 'data' => $data);
        $data['footer']         = array('view' => 'templates/footer', 'data' => $data);
        $this->load->view('templates/login_template', $data);
        
        
        
    }
    
}
?>