<?php

class UserController extends CI_Controller {

    function __construct() {
        parent::__construct();
        $this->lang->load('en');
    }

    /**
     * @author Sankarshan Pandey
     * @access public
     * @path  http://52.38.132.133/verify_phone
     * @use   to send the cverification code to the user
     *  */
    function storeList() {

        /*
         * { "device_type": "iOS", "latitude": "78235", "longitude": "62532", "user_type":"1","user_id":"23","store_id":"16"}
         */
        $json = file_get_contents('php://input');

        if (!empty($json)) {

            $json = json_decode($json, true);
            $this->load->model('Stores_model');
            $webObj = new Stores_model();
            $data = $webObj->getStoreList($json);
            //echo "<pre>";print_r($data);die;
            if (!empty($data)) {
                response(true, '200', $this->lang->line('store_list'), ($data));
            } else {
                response(false, '404', $this->lang->line('store_list_not_found'));
            }
        } else {

            response(false, '404', $this->lang->line('invalid_json'));
        }
    }

    /**
     * @author Sankarshan Pandey
     * @access public
     * @path  http://52.38.132.133/verify_phone
     * @use   to send the cverification code to the user
     *  */
    function addNewStore() {
        /*
         * 

          { "store_id":"33",
          "device_type": "iOS",
          "latitude": "78235",
          "longitude": "62532",
          "user_type": "2",
          "user_id": "23",
          "store_name": "sdfhsdjf",
          "address": "Noida, UP",
          "contact_number": "+31-0458723562",
          "store_openTime": "HH:MM am",
          "store_CloseTime": "HH:MM am",
          "store_CloseDates": [
          "YYYY-MM-DD",
          "YYYY-MM-DD",
          "YYYY-MM-DD"
          ],
          "services": "1,3,5,6",
          "professionals": "34,55,76,23"
          }

         */
        $json = file_get_contents('php://input');

        if (!empty($json)) {

            $json = json_decode($json, true);
            $this->load->model('Stores_model');
            $webObj = new Stores_model();
            //echo "<pre>";print_r($json);die;
            $data = $webObj->addStore($json);
            if (!empty($data)) {
                response(true, '200', 'Store added successfully', ($data));
            } else {
                response(false, '404', 'Something went wrong may be user is not available');
            }
        } else {

            response(false, '404', $this->lang->line('invalid_json'));
        }
    }

    /**
     * @author Sankarshan Pandey
     * @access public
     * @path  http://52.38.132.133/verify_phone
     * @use   to send the cverification code to the user
     *  */
    function updateUserProfile() {

        /*
         * 
          {
          "gender": "1",
          "dob": "1",
          "country": "1",
          "id": "1",
          "name": "Prashant",
          "mobile": "+918527333451",
          "first_name": "",
          "last_name": "",
          "nick_name": "",
          "user_type": "",
          "address": "",
          "latitude": "",
          "longitude": "",
          "availability": [
          {
          "day": "Monday",
          "start_time": "12.00",
          "end_time": "16.00"
          },
          {
          "day": "Tuesday",
          "start_time": "12.00",
          "end_time": "16.00"
          }
          ]
          }
         */
        //$json = file_get_contents('php://input');
        $json = $this->input->post('json');
        if (!empty($json)) {
            $json = json_decode($json, true);
            $this->load->model('Login_model');
            $webObj = new Login_model();
            //print_r($json);die;
            $webObj->setId($json['id']);
            $webObj->set_name($json['name']);
            $webObj->set_mobile_no($json['mobile']);
            $webObj->set_first_name($json['first_name']);
            $webObj->set_last_name($json['last_name']);
            $webObj->set_address($json['address']);
            $webObj->set_nick_name($json['nick_name']);
            $webObj->set_latitude($json['latitude']);
            $webObj->set_longitude($json['longitude']);
            //if (isset($_FILES['profile_pic']) && $_FILES['profile_pic']['name'] != '') {
            //$_image_url = fileImageUpload('profile_pic', 'profile_pic');
            $webObj->set_image_url($json['image']);
            //}
            $data = $webObj->updateDetails($json['availability'],$json);
            response(true, '200', $this->lang->line('update_profile'), $data);
        } else {

            response(false, '404', $this->lang->line('invalid_json'));
        }
    }

    /**
     * @author Sankarshan Pandey
     * @access public
     * @path  http://52.38.132.133/verify_phone
     * @use   to send the cverification code to the user
     *  */
    function getUserProfile() {

        /*
         * 
          {
          "id":"1"
          }
         */
        $json = file_get_contents('php://input');

        if (!empty($json)) {
            $json = json_decode($json, true);
            $this->load->model('Login_model');
            $webObj = new Login_model();
            $webObj->setId($json['id']);
            $userdata = $webObj->getMyProfile();
            //  echo "<pre>";print_r($userdata);die;
            response(true, '200', $this->lang->line('my_profile'), $userdata);
        } else {

            response(false, '404', $this->lang->line('invalid_json'));
        }
    }

    /**
     * @author Sankarshan Pandey
     * @access public
     * @path  http://52.38.132.133/verify_phone
     * @use   to send the cverification code to the user
     *  */
    function userStatus() {

        /*
         * 
          {
          "id":"1"
          }
         */
        $json = file_get_contents('php://input');

        if (!empty($json)) {
            $json = json_decode($json, true);
            $this->load->model('Login_model');
            $webObj = new Login_model();
            $webObj->setId($json['id']);
            $userdata = $webObj->getUserStatus();
            response(true, '200', $this->lang->line('my_profile'), $userdata);
        } else {

            response(false, '404', $this->lang->line('invalid_json'));
        }
    }

    /**
     * @author Sankarshan Pandey
     * @access public
     * @path  http://52.38.132.133/verify_phone
     * @use   to send the cverification code to the user
     *  */
    function professionalList() {

        /*
         * 
          {
          "id":"1"
          }
         */
        $json = file_get_contents('php://input');

        if (!empty($json)) {
            $json = json_decode($json, true);
            $this->load->model('Login_model');
            $webObj = new Login_model();
            $webObj->setId($json['id']);
            $userdata = $webObj->getProfessionalsList();
            response(true, '200', $this->lang->line('professional_list'), $userdata);
        } else {

            response(false, '404', $this->lang->line('invalid_json'));
        }
    }

    /**
     * @author Sankarshan Pandey
     * @access public
     * @path  http://52.38.132.133/verify_phone
     * @use   to send the cverification code to the user
     *  */
    function serviceList() {

        /*
         * 
          {
          "device_type": "iOS",
          "latitude": "78235",
          "longitude": "62532",
          "user_type": "1",
          "user_id": "23"
          }
         */
        $json = file_get_contents('php://input');

        if (!empty($json)) {
            $json = json_decode($json, true);
            $this->load->model('Service_model');
            $webObj = new Service_model();
            $webObj->setId($json['id']);
            $userdata = $webObj->getAllServices($json);
            response(true, '200', $this->lang->line('service_list'), $userdata);
        } else {

            response(false, '404', $this->lang->line('invalid_json'));
        }
    }

    function saveStore() {

        /*
         * 
          {
          "id": "1",
          "store_name": "Prashant",
          "address": "A/521 Barra-6 Kanpur",
          "number": "+918527333451",
          "email": "juhm@gmail.com",
          "availability": [
          {
          "day": "Monday",
          "start_time": "12.00",
          "end_time": "16.00"
          },
          {
          "day": "Tuesday",
          "start_time": "12.00",
          "end_time": "16.00"
          }
          ],
          "description": "sdbsndvn",
          "professionals": "1,2,3",
          "services": "1,2,3",
          "latitude": "97.832372",
          "longitude": "54.626262"
          }
         */
        $json = $this->input->post('json');

        if (!empty($json)) {
            $json = json_decode($json, true);
            $this->load->model('Service_model');
            $webObj = new Service_model();
            $webObj->setId($json['id']);
            $image = fileImageUpload('store_pic', 'image');
            //$webObj->setCreated_on($created_on);
            $userdata = $webObj->saveStore($json, $image);
            response(true, '200', $this->lang->line('service_list'), $userdata);
        } else {

            response(false, '404', $this->lang->line('invalid_json'));
        }
    }

    /**
     * @author Sankarshan Pandey
     * @access public
     * @path  http://52.38.132.133/verify_phone
     * @use   to send the cverification code to the user
     *  */
    function addService() {

        /*
         * 
          { "service_id":"6",
          "device_type": "iOS",
          "user_type": "1",
          "user_id": "23",
          "service_name": "haircut",
          "service_time": "HH:MM",
          "service_price": "$5.8",
          "service_image": "imagename",
          "store_id": "345"
          }
         */
        $json = file_get_contents('php://input');

        if (!empty($json)) {
            $json = json_decode($json, true);
            $this->load->model('Service_model');
            $webObj = new Service_model();
            $userdata = $webObj->saveService($json);
            response(true, '200', 'Service added', array());
        } else {

            response(false, '404', $this->lang->line('invalid_json'));
        }
    }

    /**
     * @author Sankarshan Pandey
     * @access public
     * @path  http://52.38.132.133/verify_phone
     * @use   to send the cverification code to the user
     *  */
    function deleteService() {

        /*
         * 
          {
          "service_id": "1"
          }
         */
        $json = file_get_contents('php://input');

        if (!empty($json)) {
            $json = json_decode($json, true);
            $this->load->model('Service_model');
            $webObj = new Service_model();
            $webObj->setId($json['service_id']);
            $userdata = $webObj->deleteService();
            response(true, '200', $this->lang->line('professional_list'), $userdata);
        } else {
            response(false, '404', $this->lang->line('invalid_json'));
        }
    }

    /**
     * @author Sankarshan Pandey
     * @access public
     * @path  http://52.38.132.133/verify_phone
     * @use   to send the cverification code to the user
     *  */
    function storeDetails() {

        /*
         * 
          {
          "store_id": "1"
          }
          }
         */
        $json = file_get_contents('php://input');

        if (!empty($json)) {
            $json = json_decode($json, true);
            $this->load->model('Service_model');
            $webObj = new Service_model();
            $webObj->setId($json['store_id']);
            $userdata = $webObj->storeDetails();
            response(true, '200', $this->lang->line('professional_list'), $userdata);
        } else {
            response(false, '404', $this->lang->line('invalid_json'));
        }
    }

    /**
     * @author Sankarshan Pandey
     * @access public
     * @path  http://52.38.132.133/verify_phone
     * @use   to send the cverification code to the user
     *  */
    function appointmentList() {

        /*
         * 
          {
          "device_type": "iOS",
          "user_type": "1",
          "user_id": "23",
          "filter_option": "1,2,3,4"
          }
         */
        $json = file_get_contents('php://input');

        if (!empty($json)) {
            $json = json_decode($json, true);
            $this->load->model('Appointment_model');
            $webObj = new Appointment_model();
            $userdata = $webObj->getAppointmentList($json);
            response(true, '200', "Appointment list", $userdata);
        } else {
            response(false, '404', $this->lang->line('invalid_json'));
        }
    }

    /**
     * @author Sankarshan Pandey
     * @access public
     * @path  http://52.38.132.133/verify_phone
     * @use   to send the cverification code to the user
     *  */
    function changeAppointmentStatus() {

        /*
         * 
          {
          "appointment_id": "1",
          "status": "1,2" 1=accept,2=cancel,
          "reason":"ssds"
          }

         */
        $json = file_get_contents('php://input');

        if (!empty($json)) {
            $json = json_decode($json, true);
            $this->load->model('Appointment_model');
            $webObj = new Appointment_model();
            $webObj->setId($json['appointment_id']);
            $webObj->setStatus($json['status']);
            $userdata = $webObj->updateAppointmentStatus($json['reason']);
            $data['status'] = $json['status'];
            $data['user_id'] = $userdata['user_id'];
            $appointmentDetails= getAppointmentDetails($json['appointment_id']);
            $professionalDetails= getUserDetails($json['user_id']);
            if ($json['status'] == '1') {
                $data['notification'] = $professionalDetails['first_name']." ".$professionalDetails['last_name']." has accepted your appointment request";
                sendPushIphone($appointmentDetails['device_token'],$data['message'],'1',$data);
                $msg = "Appointment Accepted successfully";
            } else if ($json['status'] == '2') {
                $data['notification'] = 'Your appointment has been rejected.';
                $msg = "Appointment canceled successfully";
            }
            $this->db->set($data)->insert('tbl_notifications');
            response(true, '200', $msg, $userdata);
        } else {
            response(false, '404', $this->lang->line('invalid_json'));
        }
    }

    /**
     * @author Sankarshan Pandey
     * @access public
     * @path  http://52.38.132.133/verify_phone
     * @use   to send the cverification code to the user
     *  */
    function updateAppointmentDetails() {

        /*
         * 
          {
          "appointment_id": "1",
          "datetime":"2016-07-08 00:00:00"
          }

         */
        $json = file_get_contents('php://input');

        if (!empty($json)) {
            $json = json_decode($json, true);
            $this->load->model('Appointment_model');
            $webObj = new Appointment_model();
            $webObj->setId($json['appointment_id']);
            $webObj->setCreated_on($json['datetime']);
            $userdata = $webObj->updateAppointmentDetail();
            response(true, '200', $this->lang->line('professional_list'), $userdata);
        } else {
            response(false, '404', $this->lang->line('invalid_json'));
        }
    }

    function appointmentDetails() {

        /*
         * 
          {
          "device_type": "iOS",
          "user_type": "1",
          "appointment_id": "23",
          "user_id": "34"
          }
         */
        $json = file_get_contents('php://input');

        if (!empty($json)) {
            $json = json_decode($json, true);
            $this->load->model('Appointment_model');
            $webObj = new Appointment_model();
            $userdata = $webObj->getAppointmentDetails($json);
            response(true, '200', 'Appointment Details', $userdata);
        } else {
            response(false, '404', $this->lang->line('invalid_json'));
        }
    }

    /**
     * @author Sankarshan Pandey
     * @access public
     * @path  http://52.38.132.133/verify_phone
     * @use   to send the cverification code to the user
     *  */
    function updateStore() {

        /*
         * 

          {
          "id":"16",
          "device_type": "iOS",
          "latitude": "78235",
          "longitude": "62532",
          "user_type": "2",
          "user_id": "48",
          "store_name": "sdfhsdjf",
          "address": "Noida, UP",
          "contact_number": "+31-0458723562",
          "store_openTime": "HH:MM am",
          "store_CloseTime": "HH:MM am",
          "store_CloseDates": [
          "d1d1/M1M1/yyyy",
          "d2d2/M2M2/yyyy",
          "d3d3/M3M3/yyyy"
          ],
          "services": "1,3,5,6",
          "professionals": "34,55,76,23"
          }

         */
        $json = file_get_contents('php://input');

        if (!empty($json)) {

            $json = json_decode($json, true);
            $this->load->model('Stores_model');
            $webObj = new Stores_model();
            $data = $webObj->addStore($json);
            if (!empty($data)) {
                response(true, '200', $this->lang->line('store_list'), ($data));
            } else {
                response(false, '404', $this->lang->line('store_list_not_found'));
            }
        } else {

            response(false, '404', $this->lang->line('invalid_json'));
        }
    }

    /**
     * @author Sankarshan Pandey
     * @access public
     * @path  http://52.38.132.133/verify_phone
     * @use   to send the cverification code to the user
     *  */
    function removeStore() {

        /*
         * 

          { "device_type": "iOS", "user_id":"23","store_id":"345"}

         */
        $json = file_get_contents('php://input');

        if (!empty($json)) {

            $json = json_decode($json, true);
            $this->load->model('Stores_model');
            $webObj = new Stores_model();
            $data = $webObj->removeStore($json);
            if (!empty($data)) {
                response(true, '200', $this->lang->line('store_list'), ($data));
            } else {
                response(false, '404', $this->lang->line('store_list_not_found'));
            }
        } else {

            response(false, '404', $this->lang->line('invalid_json'));
        }
    }

    function removeService() {

        /*
         * 

          {
          "device_type": "iOS",
          "user_id": "23",
          "service_id": "345",
          "store_id": "34"
          }

         */
        $json = file_get_contents('php://input');

        if (!empty($json)) {

            $json = json_decode($json, true);
            $this->load->model('Stores_model');
            $webObj = new Stores_model();
            $data = $webObj->removeService($json);
            response(true, '200', 'Service removed', ($data));
        } else {

            response(false, '404', $this->lang->line('invalid_json'));
        }
    }

    function submitFeedbackToAdmin() {

        /*
         * 

          {
          "device_type": "iOS",
          "user_type": "1",
          "user_id": "34",
          "feedback_message": "All over good, Even we can add something like this on abc screen."
          }

         */
        $json = file_get_contents('php://input');

        if (!empty($json)) {

            $json = json_decode($json, true);
            $this->load->model('Stores_model');
            $webObj = new Stores_model();
            $data = $webObj->saveFeedback($json);
            response(true, '200', 'Feedback sent', ($data));
        } else {

            response(false, '404', $this->lang->line('invalid_json'));
        }
    }

    /**
     * @author Sankarshan Pandey
     * @access public
     * @path  http://52.38.132.133/verify_phone
     * @use   to send the cverification code to the user
     *  */
    function searchStores() {

        /*
          {
          "device_type": "iOS",
          "latitude": "78235",
          "longitude": "62532",
          "user_type": "1",
          "user_id": "23",
          "filter_option": "1,2,3,4",
          "search_keyword": "abc store"
          }
         */
        $json = file_get_contents('php://input');

        if (!empty($json)) {

            $json = json_decode($json, true);
            $this->load->model('Stores_model');
            $webObj = new Stores_model();
            $data = $webObj->getStoreList($json);
            if (!empty($data)) {
                response(true, '200', $this->lang->line('store_list'), ($data));
            } else {
                response(false, '404', $this->lang->line('store_list_not_found'));
            }
        } else {

            response(false, '404', $this->lang->line('invalid_json'));
        }
    }

    function AddWalkin() {

        /*
          {
          "id":"1",
          "device_type": "iOS",
          "user_type": "2",
          "user_id": "34",
          "person_name": "dfsgsfg person",
          "person_contact_number": "+352534653465",
          "service_name": "haircut","service_price":"23","walkin_date":"","walkin_time":""
          }
         */
        $json = file_get_contents('php://input');

        if (!empty($json)) {

            $json = json_decode($json, true);
            $this->load->model('Stores_model');
            $webObj = new Stores_model();
            $data = $webObj->addWalkIn($json);
            if (!empty($data)) {
                response(true, '200', 'Walki added successfully', ($data));
            } else {
                response(false, '404', $this->lang->line('store_list_not_found'));
            }
        } else {

            response(false, '404', $this->lang->line('invalid_json'));
        }
    }

    function GetAllWalkin() {

        /*
          { "device_type": "iOS", "user_id":"34", "user_type":"2"}
         */
        $json = file_get_contents('php://input');

        if (!empty($json)) {

            $json = json_decode($json, true);
            $this->load->model('Stores_model');
            $webObj = new Stores_model();
            $data = $webObj->getAllWalkIns($json);
            if (!empty($data)) {
                response(true, '200', 'Walkin list', ($data));
            } else {
                response(false, '404', $this->lang->line('store_list_not_found'));
            }
        } else {

            response(false, '404', $this->lang->line('invalid_json'));
        }
    }

    function removeProfessionals() {

        /*
          {
          "device_type": "iOS",
          "user_id": "23",
          "store_id": "345",
          "professional_id": "64",
          "reason": "you are not punctual with time, reviews are not good from clients."
          }
         */
        $json = file_get_contents('php://input');

        if (!empty($json)) {

            $json = json_decode($json, true);
            $this->load->model('Stores_model');
            $webObj = new Stores_model();
            $data = $webObj->removeProfessionalFromStores($json);
            response(true, '200', 'Removed', ($data));
        } else {

            response(false, '404', $this->lang->line('invalid_json'));
        }
    }

    function getProfessionalDetails() {

        /*
         * 
          {
          "id":"1"
          }
         */
        $json = file_get_contents('php://input');

        if (!empty($json)) {
            $json = json_decode($json, true);
            $this->load->model('Login_model');
            $webObj = new Login_model();
            $userdata = $webObj->getProfessionalDetails($json);
            response(true, '200', 'Professional Details', $userdata);
        } else {

            response(false, '404', $this->lang->line('invalid_json'));
        }
    }

    function getUserDetail() {

        /*
         * 
          {
          "id":"1"
          }
         */
        $json = file_get_contents('php://input');

        if (!empty($json)) {
            $json = json_decode($json, true);
            $this->load->model('Login_model');
            $webObj = new Login_model();
            $userdata = $webObj->getUserDetailsById($json);
            response(true, '200', 'Professional Details', $userdata);
        } else {

            response(false, '404', $this->lang->line('invalid_json'));
        }
    }

    function makeAppointment() {

        /*
         * 
          {
          "device_type": "iOS",
          "user_id": "34",
          "service_id": "5",
          "professional_id": "23",
          "service_price": "$23",
          "appointment_Date_time": "dd/MM/yyyy HH:MM",
          "service_time": "hh:mm"
          }
         */
        $json = file_get_contents('php://input');

        if (!empty($json)) {
            $json = json_decode($json, true);
            //print_r($json);die;
            $this->load->model('Login_model');
            $webObj = new Login_model();
            $userdata = $webObj->makeAppointment($json);



            response(true, '200', 'Appointment saved', $userdata);
        } else {

            response(false, '404', $this->lang->line('invalid_json'));
        }
    }

    function listAppointment() {

        /*
         * 
          {
          "device_type": "iOS",
          "user_id": "34",
          "service_id": "5",
          "professional_id": "23",
          "service_price": "$23",
          "appointment_Date_time": "dd/MM/yyyy HH:MM",
          "service_time": "hh:mm"
          }
         */
        $json = file_get_contents('php://input');

        if (!empty($json)) {
            $json = json_decode($json, true);
            $this->load->model('Login_model');
            $webObj = new Login_model();
            $userdata = $webObj->appointmentList($json);
            response(true, '200', 'Appointment List', $userdata);
        } else {

            response(false, '404', $this->lang->line('invalid_json'));
        }
    }

    function updateAppointment() {

        /*
         * 
          {
          "id":"1",
          "device_type": "iOS",
          "user_id": "34",
          "service_id": "5",
          "professional_id": "23",
          "service_price": "$23",
          "appointment_Date_time": "dd/MM/yyyy HH:MM",
          "service_time": "hh:mm"
          }
         */
        $json = file_get_contents('php://input');

        if (!empty($json)) {
            $json = json_decode($json, true);
            $this->load->model('Login_model');
            $webObj = new Login_model();
            $userdata = $webObj->updateAppointment($json);
            response(true, '200', 'Appointment Updated', $userdata);
        } else {

            response(false, '404', $this->lang->line('invalid_json'));
        }
    }

    function markFavouriteToAnyStoreORProfessional() {

        /*
         * 
          { "device_type": "iOS","user_id":"34","professional_id":"23","store_id":"","isFavourite":"1"}
         */
        $json = file_get_contents('php://input');

        if (!empty($json)) {
            $json = json_decode($json, true);
            $this->load->model('Login_model');
            $webObj = new Login_model();
            $userdata = $webObj->markFavouriteToAnyStoreORProfessional($json);
            response(true, '200', 'Appointment Updated', $userdata);
        } else {

            response(false, '404', $this->lang->line('invalid_json'));
        }
    }

    function getServicesforSelectedProfessional() {

        /*
         * 
          {
          "device_type": "iOS",
          "professional_id": "23",
          "user_id": "34"
          }
         */
        $json = file_get_contents('php://input');

        if (!empty($json)) {
            $json = json_decode($json, true);
            $this->load->model('Service_model');
            $webObj = new Service_model();
            $webObj->setId($json['id']);
            $userdata = $webObj->getAllServicesForSelectedProfessional($json);
            response(true, '200', 'Service List', $userdata);
        } else {

            response(false, '404', $this->lang->line('invalid_json'));
        }
    }

    function getServicesforSelectedStore() {

        /*
         * 
          { "device_type": "iOS","store_id":"23","user_id":"34"}
         */
        $json = file_get_contents('php://input');

        if (!empty($json)) {
            $json = json_decode($json, true);
            $this->load->model('Service_model');
            $webObj = new Service_model();
            $webObj->setId($json['id']);
            $userdata = $webObj->getServicesforSelectedStore($json);
            response(true, '200', 'Service List', $userdata);
        } else {

            response(false, '404', $this->lang->line('invalid_json'));
        }
    }

    function getProfessionalsForSelectedServices() {

        /*
         * 
          { "device_type": "iOS","service_id":"23","user_id":"34"}
         */
        $json = file_get_contents('php://input');

        if (!empty($json)) {
            $json = json_decode($json, true);
            $this->load->model('Service_model');
            $webObj = new Service_model();
            $webObj->setId($json['id']);
            $userdata = $webObj->getProfessionalsForSelectedServices($json);
            response(true, '200', 'Service List', $userdata);
        } else {

            response(false, '404', $this->lang->line('invalid_json'));
        }
    }

    function getProfessionalsForSelectedStore() {

        /*
         * 
          { "device_type": "iOS","store_id":"23","user_id":"34"}
         */
        $json = file_get_contents('php://input');

        if (!empty($json)) {
            $json = json_decode($json, true);
            $this->load->model('Service_model');
            $webObj = new Service_model();
            $webObj->setId($json['id']);
            $userdata = $webObj->getProfessionalsForSelectedStore($json);
            response(true, '200', 'Professionals for selected store', $userdata);
        } else {

            response(false, '404', $this->lang->line('invalid_json'));
        }
    }

    /**
     * @author Sankarshan Pandey
     * @access public
     * @path  http://52.38.132.133/verify_phone
     * @use   to send the cverification code to the user
     *  */
    function getNotifications() {

        /*
         * 
          {
          "user_id": "1"
          }

         */
        $json = file_get_contents('php://input');

        if (!empty($json)) {
            $json = json_decode($json, true);
            $this->load->model('Appointment_model');
            $webObj = new Appointment_model();
            $webObj->setId($json['user_id']);
            $userdata = $webObj->getAllNotifications($json['reason']);

            response(true, '200', 'notification', $userdata);
        } else {
            response(false, '404', $this->lang->line('invalid_json'));
        }
    }

    /**
     * @author Sankarshan Pandey
     * @access public
     * @path  http://52.38.132.133/verify_phone
     * @use   to send the cverification code to the user
     *  */
    function getAllSoloProfessionals() {

        /*
         * { "device_type": "iOS", "latitude": "78235", "longitude": "62532", "user_type":"1","user_id":"23","store_id":"16"}
         */
        $json = file_get_contents('php://input');

        if (!empty($json)) {

            $json = json_decode($json, true);
            
            $query = $this->db->select('professionals')->from('tbl_stores')->get()->result_array();
            
            //echo '<pre>';
            //print_r($query);die;
            $latitude=$json['latitude'];
            $longitude=$json['longitude'];
            $professionalsArray=array();
            
            
            $professionalsQuery= $this->db->select('GROUP_CONCAT(user_id) as user_id')
                    ->from('tbl_professionals')
                    ->get();
            $professionalsRes=$professionalsQuery->row_array();
            if($professionalsQuery->num_rows()>0){
                $professionalsArray= explode(",",$professionalsRes['user_id']);
            }else{
                $professionalsArray= array(0);
            }
            
            $allProfessionalsAssociatedWithStore = array_unique(array_filter($professionalsArray));
            if(!empty($allProfessionalsAssociatedWithStore)){

            }else{
              $allProfessionalsAssociatedWithStore=array(0);
            }
//            print_r($allProfessionalsAssociatedWithStore);
//            die;
            if($latitude!=''){
            $query = $this->db->select('latitude,longitude,id,if(user_name IS NULL,email,user_name) as name,email,if(user_name IS NULL,"",user_name) as user_name,if(image IS NULL,"",image) as professionalImageUrl,mobile,if((select avg(rating) from tbl_rating where rating_to=tbl_users.id) IS NULL,"",(select avg(rating) from tbl_rating where rating_to=tbl_users.id)) as rating,
                ROUND((((acos(sin(('.$latitude.'*pi()/180)) * 
            sin((`latitude`*pi()/180))+cos(('.$latitude.'*pi()/180)) * 
            cos((`latitude`*pi()/180)) * cos((('.$longitude.'- `longitude`)* 
            pi()/180))))*180/pi())*60*1.1515
        )) as distance_KM', FALSE)
                            ->from('tbl_users')
                            ->where('is_deleted', '1')->where_not_in('id', $allProfessionalsAssociatedWithStore);
            $query = $this->db->where('user_type', '1')
                    //->having('distance_KM <=','(3*1.1515)')
                    ->order_by('created_on', 'desc')
                    ->get();
                  }else{
                  $query = $this->db->select('id,if(user_name IS NULL,email,user_name) as name,email,if(user_name IS NULL,"",user_name) as user_name,if(image IS NULL,"",image) as professionalImageUrl,mobile,if((select avg(rating) from tbl_rating where rating_to=tbl_users.id) IS NULL,"",(select avg(rating) from tbl_rating where rating_to=tbl_users.id)) as rating', FALSE)
                            ->from('tbl_users')
                            ->where('is_deleted', '1')->where_not_in('id', $allProfessionalsAssociatedWithStore);
            $query = $this->db->where('user_type', '1')
                    ->order_by('created_on', 'desc')
                    ->get();  
                  }
            //echo $this->db->last_query();die;
            $data = $query->result_array();
            //echo "<pre>";print_r($data);die;
            if (!empty($data)) {
                response(true, '200', $this->lang->line('store_list'), ($data));
            } else {
                response(false, '404', $this->lang->line('store_list_not_found'));
            }
        } else {

            response(false, '404', $this->lang->line('invalid_json'));
        }
    }

    function adminSettings() {

        $data = $this->db->get('admin_settings')->row_array();
        response(true, '200', 'Admin Setting', ($data));
    }

    function giveRatingFeedback() {

        /*
         * 
          {
          "device_type": "iOS",
          "user_type":"1",
          “user_id":"34",
          “professional_id”:”179”,  // if this is filled then store_id will be empty , only one can be at a time
          “store_id”:”88”, // if this is filled then professional_id will be empty , only one can be at a time
          “rating”:”2”, //rating should be between 1-5
          "feedback_message”:”service was very fair, i would like to suggest my friends to go there.”
          }


         */
        $json = file_get_contents('php://input');

        if (!empty($json)) {
            $json = json_decode($json, true);
            $data['user_type'] = $json['user_type'];
            $data['rating_to'] = $json['professional_id'];
            $data['store_id'] = $json['store_id'];
            $data['store_owner_id'] = $json['store_owner_id'];
            $data['rating_by'] = $json['user_id'];
            $data['rating'] = $json['rating'];
            $data['feedback_message'] = $json['feedback_message'];
            $this->db->set($data)->insert('tbl_rating');
            response(true, '200', 'rating', $data);
        } else {
            response(false, '404', $this->lang->line('invalid_json'));
        }
    }

    function requestToLeaveStore() {

        /*
          {
          "device_type": "iOS",
          "user_id": "23",
          "store_id": "345",
          "is_push_send": "1",
          "reason": "I  am not comfortable with available time."
          }
         */
        $json = file_get_contents('php://input');

        if (!empty($json)) {
            $json = json_decode($json, true);
            $data['user_id'] = $json['user_id'];
            $data['notification'] = $json['reason'];
            $data['store_id'] = $json['store_id'];
            $this->db->set($data)->insert('tbl_notifications');
            response(true, '200', 'rating', $data);
        } else {
            response(false, '404', $this->lang->line('invalid_json'));
        }
    }

    function favoriteStores() {

        /*
          {
          "user_id": "22",
          "user_type": "3",
          "latitude": "32.234",
          "longitude": "31.234",
          "filter_option": "0"
          }
         */
        $json = file_get_contents('php://input');

        if (!empty($json)) {
            $json = json_decode($json, true);
            $data = $this->db->select('ts.*')->from('favorite_items as fi')
                            ->join('tbl_stores as ts', 'ts.id=fi.store_id', 'left')
                            ->get()->result_array();
            response(true, '200', 'rating', $data);
        } else {
            response(false, '404', $this->lang->line('invalid_json'));
        }
    }

    function favouriteProfessionals() {

        /*
          {
          "user_id": "22",
          "user_type": "3",
          "latitude": "32.234",
          "longitude": "31.234",
          "filter_option": "0"
          }
         */
        $json = file_get_contents('php://input');

        if (!empty($json)) {
            $json = json_decode($json, true);
            $data = $this->db->select('ts.*')->from('favorite_items as fi')
                            ->join('tbl_users as ts', 'ts.id=fi.professional_id', 'left')
                            ->get()->result_array();
            response(true, '200', 'rating', $data);
        } else {
            response(false, '404', $this->lang->line('invalid_json'));
        }
    }

    function sendPushToUser(){

        /*
          {
  "user_type": "2",
  "other_user_id": "23,25,27",
  "user_id": "21",
  "message": "i have created an appointment for you"
}
         */
        $json = file_get_contents('php://input');

        if (!empty($json)) {

            $json = json_decode($json, true);
            //print_r($json);die;
            $other_user_id=explode(",",$json['other_user_id']);
            $data = $this->db->where_in('id',$other_user_id)->get('tbl_users')->result_array();
            foreach ($data as $key=>$value){
            sendPushIphone($value['device_token'],$json['message'],'1',$json);
            }
            response(true, '200', 'Push Sent', array());
        } else {
            response(false, '404', $this->lang->line('invalid_json'));
        }
    }
    
    function addStripeCustomerKey() {

        /*
          {
          "user_id": "22",
          "stripe_cust_id": "3"
          }
         */
        $json = file_get_contents('php://input');

        if (!empty($json)) {
            $json = json_decode($json, true);
            $data = $this->db->set('customer_stripe_id',$json['stripe_cust_id'])->where('id',$json['user_id'])->update('tbl_users');
            response(true, '200', 'rating', $data);
        } else {
            response(false, '404', $this->lang->line('invalid_json'));
        }
    }
    
    function getStripeCustomerKey() {

        /*
          {
          "user_id": "22"
          }
         */
        $json = file_get_contents('php://input');

        if (!empty($json)) {
            $json = json_decode($json, true);
            $data = $this->db->select('customer_stripe_id')->where('id',$json['user_id'])->from('tbl_users')->get();
            $row=$data->row_array();
            response(true, '200', 'rating', $row);
        } else {
            response(false, '404', $this->lang->line('invalid_json'));
        }
    }
    
    function getAllProfessionalsSelectedDate() {
        
        /*
          {
          "store_id": "22"
          "selected_date":""
          }
         */
        $json = file_get_contents('php://input');

        if (!empty($json)) {
            $json = json_decode($json, true);
            $day = strtolower(date('D', strtotime($json['selected_date'])));
            $row=array();
            $professionalData=array();
            $query = $this->db->select('professionals,store_openDays')
                    ->from('tbl_stores')
                    ->where('id',$json['store_id'])
                    ->get();
            if($query->num_rows()>0){
            $row=$query->row_array();
            $storeOpenDays=  json_decode($row['store_openDays'],true);
            if(count($storeOpenDays)>0){
                $i=0;
                foreach ($storeOpenDays as $key=>$value){
                    if(strtolower($value['day'])==$day && $value['isOpen']=='1'){
                        $i++;
                        break;
                    }
                }
                if($i>0){
                    
                    $professionalIds=  json_decode($row['professionals']);
                    if(count($professionalIds)>0){
                    $professionalData=  $this->db->where_in('id',$professionalIds)
                            ->get('tbl_users')->result_array();
                    }
                    
                }
            }
            }
            response(true, '200', 'rating', $professionalData);
        } else {
            response(false, '404', $this->lang->line('invalid_json'));
        }
    }
    
    function getProfessionalAvailibility() {

        /*
          {
          "professional_id": "22","date":"2017-10-12:11:00:00"
          }
         */
        $json = file_get_contents('php://input');

        if (!empty($json)) {
            $json = json_decode($json, true);
            //echo date("H:i:s");die;
            $date=date("D",strtotime($json['date']));
            //echo $date;die;
            $data = $this->db->select('id,user_id,day,start_time,end_time')->where('user_id',$json['professional_id'])
                    ->where('is_booked','0')
                    ->where('LOWER(day)',  strtolower($date))
                    ->from('tbl_availability')
                    ->get();
            $row=$data->result_array();
            $today=date('Y-m-d',strtotime($json['date']));
            foreach ($row as $key=>$value){
                
                $getBookedSlotsQuery=  $this->db->query("SELECT * FROM `tbl_booked_time_slots` where slot_id='$value[id]' and DATE(booked_date)='$today'");
                if($getBookedSlotsQuery->num_rows()>0){
                    $row[$key]['is_booked']='1';
                }else{
                    $row[$key]['is_booked']='0';
                }
                
            }
            response(true, '200', 'Availibility', $row);
        } else {
            response(false, '404', $this->lang->line('invalid_json'));
        }
    }
    
    
    function getAllIndividualProfessionalsSelectedDate() {
        
        /*
          {
          "store_id": "22"
          "selected_date":""
          }
         */
        $json = file_get_contents('php://input');

        if (!empty($json)) {
            $json = json_decode($json, true);
            $day = (date('D', strtotime($json['selected_date'])));
            $row=array();
            $professionalData=array();
            $query = $this->db->select('user_id')
                    ->from('tbl_availability')
                    ->where('day',$day)
                    ->group_by('user_id')
                    ->get();
            //echo $this->db->last_query();die;
            $row=$query->result_array();
            foreach ($row as $key=>$value){
            $professionalIdsRes[]=$value['user_id'];
            }
            //print_r($professionalIdsRes);
            $storePQuery= $this->db->select('GROUP_CONCAT(user_id) as user_id')
                    ->from('tbl_professionals')
                    ->where('store_id',$json['store_id'])
                    ->get()->row_array();
            
            $storeRes= (explode(",",$storePQuery['user_id']));
            //print_r($storeRes);
            $professionalIds = array_intersect($professionalIdsRes, $storeRes);
            //print_r($professionalIds);die;
            if(count($professionalIds)>0){
            $professionalData=  $this->db
                    ->where_in('id',$professionalIds)
                    ->get('tbl_users')
                    ->result_array();
            }
            response(true, '200', 'Professionals', $professionalData);
        } else {
            response(false, '404', $this->lang->line('invalid_json'));
        }
    }
    
    function savePlanDetails() {

        /*
          {
          "is_trial": "1",
          "user_id":"322"
          }
         */
        $json = file_get_contents('php://input');

        if (!empty($json)) {
            $json = json_decode($json, true);
            $response=array();
            $data['is_trail']=$json['is_trial'];            
            $data['start_date']=date('y-m-d H:i:s');
            $data['end_date']=date("Y-m-d", strtotime("+1 month",strtotime($data['start_date'])));
            $this->db->set($data)->where('id',$json['user_id'])->update('tbl_users');            
            response(true, '200', 'updated', $response);
        } else {
            response(false, '404', $this->lang->line('invalid_json'));
        }
    }
    

}
