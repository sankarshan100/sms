<?php

class UserController extends CI_Controller {

    function __construct() {
        parent::__construct();
        $this->lang->load('en');
    }

    /**
     * @author Sankarshan Pandey
     * @access public
     * @path  http://52.38.132.133/verify_phone
     * @use   to send the cverification code to the user
     *  */
    function storeList() {

        /*
         * { "device_type": "iOS", "latitude": "78235", "longitude": "62532", "user_type":"1","user_id":"23","store_id":"16"}
         */
        $json = file_get_contents('php://input');

        if (!empty($json)) {

            $json = json_decode($json, true);
            $this->load->model('Stores_model');
            $webObj = new Stores_model();
            $data = $webObj->getStoreList($json);
			//echo "<pre>";print_r($data);die;
            if (!empty($data)) {
                response(true, '200', $this->lang->line('store_list'), ($data));
            } else {
                response(false, '404', $this->lang->line('store_list_not_found'));
            }
        } else {

            response(false, '404', $this->lang->line('invalid_json'));
        }
    }

    /**
     * @author Sankarshan Pandey
     * @access public
     * @path  http://52.38.132.133/verify_phone
     * @use   to send the cverification code to the user
     *  */
    function addNewStore() {
        /*
         * 

          { "store_id":"33",
          "device_type": "iOS",
          "latitude": "78235",
          "longitude": "62532",
          "user_type": "2",
          "user_id": "23",
          "store_name": "sdfhsdjf",
          "address": "Noida, UP",
          "contact_number": "+31-0458723562",
          "store_openTime": "HH:MM am",
          "store_CloseTime": "HH:MM am",
          "store_CloseDates": [
          "YYYY-MM-DD",
          "YYYY-MM-DD",
          "YYYY-MM-DD"
          ],
          "services": "1,3,5,6",
          "professionals": "34,55,76,23"
          }

         */
        $json = file_get_contents('php://input');

        if (!empty($json)) {
            
            $json = json_decode($json, true);
            $this->load->model('Stores_model');
            $webObj = new Stores_model();
            $data = $webObj->addStore($json);
            if (!empty($data)) {
                response(true, '200', 'Store added successfully', ($data));
            } else {
                response(false, '404', 'Something went wrong may be user is not available');
            }
        } else {

            response(false, '404', $this->lang->line('invalid_json'));
        }
    }

    /**
     * @author Sankarshan Pandey
     * @access public
     * @path  http://52.38.132.133/verify_phone
     * @use   to send the cverification code to the user
     *  */
    function updateUserProfile() {

        /*
         * 
          {
          "id":"1",
          "name": "Prashant",
          "mobile": "+918527333451",
          "availability": [
          {
          "day": "Monday",
          "start_time": "12.00",
          "end_time": "16.00"
          },
          {
          "day": "Tuesday",
          "start_time": "12.00",
          "end_time": "16.00"
          }
          ]
          }
         */
        //$json = file_get_contents('php://input');
        $json = $this->input->post('json');
        if (!empty($json)) {
            $json = json_decode($json, true);
            $this->load->model('Login_model');
            $webObj = new Login_model();
            //print_r($json);die;
            $webObj->setId($json['id']);
            $webObj->set_name($json['name']);
            $webObj->set_mobile_no($json['mobile']);
            //if (isset($_FILES['profile_pic']) && $_FILES['profile_pic']['name'] != '') {
                //$_image_url = fileImageUpload('profile_pic', 'profile_pic');
            $webObj->set_image_url($json['image']);
            //}
            $data = $webObj->updateDetails($json['availability']);
            response(true, '200', $this->lang->line('update_profile'), $data);
        } else {

            response(false, '404', $this->lang->line('invalid_json'));
        }
    }

    /**
     * @author Sankarshan Pandey
     * @access public
     * @path  http://52.38.132.133/verify_phone
     * @use   to send the cverification code to the user
     *  */
    function getUserProfile() {

        /*
         * 
          {
          "id":"1"
          }
         */
        $json = file_get_contents('php://input');

        if (!empty($json)) {
            $json = json_decode($json, true);
            $this->load->model('Login_model');
            $webObj = new Login_model();
            $webObj->setId($json['id']);
            $userdata = $webObj->getMyProfile();
          //  echo "<pre>";print_r($userdata);die;
            response(true, '200', $this->lang->line('my_profile'), $userdata);
        } else {

            response(false, '404', $this->lang->line('invalid_json'));
        }
    }

    /**
     * @author Sankarshan Pandey
     * @access public
     * @path  http://52.38.132.133/verify_phone
     * @use   to send the cverification code to the user
     *  */
    function userStatus() {

        /*
         * 
          {
          "id":"1"
          }
         */
        $json = file_get_contents('php://input');

        if (!empty($json)) {
            $json = json_decode($json, true);
            $this->load->model('Login_model');
            $webObj = new Login_model();
            $webObj->setId($json['id']);
            $userdata = $webObj->getUserStatus();
            response(true, '200', $this->lang->line('my_profile'), $userdata);
        } else {

            response(false, '404', $this->lang->line('invalid_json'));
        }
    }

    /**
     * @author Sankarshan Pandey
     * @access public
     * @path  http://52.38.132.133/verify_phone
     * @use   to send the cverification code to the user
     *  */
    function professionalList() {

        /*
         * 
          {
          "id":"1"
          }
         */
        $json = file_get_contents('php://input');

        if (!empty($json)) {
            $json = json_decode($json, true);
            $this->load->model('Login_model');
            $webObj = new Login_model();
            $webObj->setId($json['id']);
            $userdata = $webObj->getProfessionalsList();
            response(true, '200', $this->lang->line('professional_list'), $userdata);
        } else {

            response(false, '404', $this->lang->line('invalid_json'));
        }
    }

    /**
     * @author Sankarshan Pandey
     * @access public
     * @path  http://52.38.132.133/verify_phone
     * @use   to send the cverification code to the user
     *  */
    function serviceList() {

        /*
         * 
          {
          "device_type": "iOS",
          "latitude": "78235",
          "longitude": "62532",
          "user_type": "1",
          "user_id": "23"
          }
         */
        $json = file_get_contents('php://input');

        if (!empty($json)) {
            $json = json_decode($json, true);
            $this->load->model('Service_model');
            $webObj = new Service_model();
            $webObj->setId($json['id']);
            $userdata = $webObj->getAllServices($json);
            response(true, '200', $this->lang->line('service_list'), $userdata);
        } else {

            response(false, '404', $this->lang->line('invalid_json'));
        }
    }

    function saveStore() {

        /*
         * 
          {
          "id": "1",
          "store_name": "Prashant",
          "address": "A/521 Barra-6 Kanpur",
          "number": "+918527333451",
          "email": "juhm@gmail.com",
          "availability": [
          {
          "day": "Monday",
          "start_time": "12.00",
          "end_time": "16.00"
          },
          {
          "day": "Tuesday",
          "start_time": "12.00",
          "end_time": "16.00"
          }
          ],
          "description": "sdbsndvn",
          "professionals": "1,2,3",
          "services": "1,2,3",
          "latitude": "97.832372",
          "longitude": "54.626262"
          }
         */
        $json = $this->input->post('json');

        if (!empty($json)) {
            $json = json_decode($json, true);
            $this->load->model('Service_model');
            $webObj = new Service_model();
            $webObj->setId($json['id']);
            $image = fileImageUpload('store_pic', 'image');
            //$webObj->setCreated_on($created_on);
            $userdata = $webObj->saveStore($json, $image);
            response(true, '200', $this->lang->line('service_list'), $userdata);
        } else {

            response(false, '404', $this->lang->line('invalid_json'));
        }
    }

    /**
     * @author Sankarshan Pandey
     * @access public
     * @path  http://52.38.132.133/verify_phone
     * @use   to send the cverification code to the user
     *  */
    function addService() {

        /*
         * 
          { "service_id":"6",
          "device_type": "iOS",
          "user_type": "1",
          "user_id": "23",
          "service_name": "haircut",
          "service_time": "HH:MM",
          "service_price": "$5.8",
          "service_image": "imagename",
          "store_id": "345"
          }
         */
        $json = file_get_contents('php://input');

        if (!empty($json)) {
            $json = json_decode($json, true);
            $this->load->model('Service_model');
            $webObj = new Service_model();
            $userdata = $webObj->saveService($json);
            response(true, '200', 'Service added', array());
        } else {

            response(false, '404', $this->lang->line('invalid_json'));
        }
    }

    /**
     * @author Sankarshan Pandey
     * @access public
     * @path  http://52.38.132.133/verify_phone
     * @use   to send the cverification code to the user
     *  */
    function deleteService() {

        /*
         * 
          {
          "service_id": "1"
          }
         */
        $json = file_get_contents('php://input');

        if (!empty($json)) {
            $json = json_decode($json, true);
            $this->load->model('Service_model');
            $webObj = new Service_model();
            $webObj->setId($json['service_id']);
            $userdata = $webObj->deleteService();
            response(true, '200', $this->lang->line('professional_list'), $userdata);
        } else {
            response(false, '404', $this->lang->line('invalid_json'));
        }
    }

    /**
     * @author Sankarshan Pandey
     * @access public
     * @path  http://52.38.132.133/verify_phone
     * @use   to send the cverification code to the user
     *  */
    function storeDetails() {

        /*
         * 
          {
          "store_id": "1"
          }
          }
         */
        $json = file_get_contents('php://input');

        if (!empty($json)) {
            $json = json_decode($json, true);
            $this->load->model('Service_model');
            $webObj = new Service_model();
            $webObj->setId($json['service_id']);
            $userdata = $webObj->storeDetails();
            response(true, '200', $this->lang->line('professional_list'), $userdata);
        } else {
            response(false, '404', $this->lang->line('invalid_json'));
        }
    }

    /**
     * @author Sankarshan Pandey
     * @access public
     * @path  http://52.38.132.133/verify_phone
     * @use   to send the cverification code to the user
     *  */
    function appointmentList() {

        /*
         * 
          {
          "device_type": "iOS",
          "user_type": "1",
          "user_id": "23",
          "filter_option": "1,2,3,4"
          }
         */
        $json = file_get_contents('php://input');

        if (!empty($json)) {
            $json = json_decode($json, true);
            $this->load->model('Appointment_model');
            $webObj = new Appointment_model();
            $userdata = $webObj->getAppointmentList($json);
            response(true, '200', "Appointment list", $userdata);
        } else {
            response(false, '404', $this->lang->line('invalid_json'));
        }
    }

    /**
     * @author Sankarshan Pandey
     * @access public
     * @path  http://52.38.132.133/verify_phone
     * @use   to send the cverification code to the user
     *  */
    function changeAppointmentStatus() {

        /*
         * 
          {
          "appointment_id": "1",
          "status": "1,2" 1=accept,2=cancel,
          "reason":"ssds"
          }

         */
        $json = file_get_contents('php://input');

        if (!empty($json)) {
            $json = json_decode($json, true);
            $this->load->model('Appointment_model');
            $webObj = new Appointment_model();
            $webObj->setId($json['appointment_id']);
            $webObj->setStatus($json['status']);
            $userdata = $webObj->updateAppointmentStatus($json['reason']);
            $data['status']=$json['status'];
            $data['user_id']=$userdata['user_id'];
            if($json['status']=='1'){
              $data['notification']='Your appointment has been accepted.';
              $msg="Appointment Accepted successfully";
            }else if($json['status']=='2'){
              $data['notification']='Your appointment has been rejected.';
              $msg="Appointment canceled successfully";
            }
            $this->db->set($data)->insert('tbl_notifications');
            response(true, '200',$msg, $userdata);
        } else {
            response(false, '404', $this->lang->line('invalid_json'));
        }
    }

    /**
     * @author Sankarshan Pandey
     * @access public
     * @path  http://52.38.132.133/verify_phone
     * @use   to send the cverification code to the user
     *  */
    function updateAppointmentDetails() {

        /*
         * 
          {
          "appointment_id": "1",
          "datetime":"2016-07-08 00:00:00"
          }

         */
        $json = file_get_contents('php://input');

        if (!empty($json)) {
            $json = json_decode($json, true);
            $this->load->model('Appointment_model');
            $webObj = new Appointment_model();
            $webObj->setId($json['appointment_id']);
            $webObj->setCreated_on($json['datetime']);
            $userdata = $webObj->updateAppointmentDetail();
            response(true, '200', $this->lang->line('professional_list'), $userdata);
        } else {
            response(false, '404', $this->lang->line('invalid_json'));
        }
    }

    function appointmentDetails() {

        /*
         * 
          {
          "device_type": "iOS",
          "user_type": "1",
          "appointment_id": "23",
          "user_id": "34"
          }
         */
        $json = file_get_contents('php://input');

        if (!empty($json)) {
            $json = json_decode($json, true);
            $this->load->model('Appointment_model');
            $webObj = new Appointment_model();
            $userdata = $webObj->getAppointmentDetails($json);
            response(true, '200','Appointment Details', $userdata);
        } else {
            response(false, '404', $this->lang->line('invalid_json'));
        }
    }

    /**
     * @author Sankarshan Pandey
     * @access public
     * @path  http://52.38.132.133/verify_phone
     * @use   to send the cverification code to the user
     *  */
    function updateStore() {

        /*
         * 

          {
          "id":"16",
          "device_type": "iOS",
          "latitude": "78235",
          "longitude": "62532",
          "user_type": "2",
          "user_id": "48",
          "store_name": "sdfhsdjf",
          "address": "Noida, UP",
          "contact_number": "+31-0458723562",
          "store_openTime": "HH:MM am",
          "store_CloseTime": "HH:MM am",
          "store_CloseDates": [
          "d1d1/M1M1/yyyy",
          "d2d2/M2M2/yyyy",
          "d3d3/M3M3/yyyy"
          ],
          "services": "1,3,5,6",
          "professionals": "34,55,76,23"
          }

         */
        $json = file_get_contents('php://input');

        if (!empty($json)) {

            $json = json_decode($json, true);
            $this->load->model('Stores_model');
            $webObj = new Stores_model();
            $data = $webObj->addStore($json);
            if (!empty($data)) {
                response(true, '200', $this->lang->line('store_list'), ($data));
            } else {
                response(false, '404', $this->lang->line('store_list_not_found'));
            }
        } else {

            response(false, '404', $this->lang->line('invalid_json'));
        }
    }

    /**
     * @author Sankarshan Pandey
     * @access public
     * @path  http://52.38.132.133/verify_phone
     * @use   to send the cverification code to the user
     *  */
    function removeStore() {

        /*
         * 

          { "device_type": "iOS", "user_id":"23","store_id":"345"}

         */
        $json = file_get_contents('php://input');

        if (!empty($json)) {

            $json = json_decode($json, true);
            $this->load->model('Stores_model');
            $webObj = new Stores_model();
            $data = $webObj->removeStore($json);
            if (!empty($data)) {
                response(true, '200', $this->lang->line('store_list'), ($data));
            } else {
                response(false, '404', $this->lang->line('store_list_not_found'));
            }
        } else {

            response(false, '404', $this->lang->line('invalid_json'));
        }
    }

    function removeService() {

        /*
         * 

          {
          "device_type": "iOS",
          "user_id": "23",
          "service_id": "345",
          "store_id": "34"
          }

         */
        $json = file_get_contents('php://input');

        if (!empty($json)) {

            $json = json_decode($json, true);
            $this->load->model('Stores_model');
            $webObj = new Stores_model();
            $data = $webObj->removeService($json);
            response(true, '200', 'Service removed', ($data));
        } else {

            response(false, '404', $this->lang->line('invalid_json'));
        }
    }

    function submitFeedbackToAdmin() {

        /*
         * 

          {
          "device_type": "iOS",
          "user_type": "1",
          "user_id": "34",
          "feedback_message": "All over good, Even we can add something like this on abc screen."
          }

         */
        $json = file_get_contents('php://input');

        if (!empty($json)) {

            $json = json_decode($json, true);
            $this->load->model('Stores_model');
            $webObj = new Stores_model();
            $data = $webObj->saveFeedback($json);
            response(true, '200', 'Feedbak sent', ($data));
        } else {

            response(false, '404', $this->lang->line('invalid_json'));
        }
    }

    /**
     * @author Sankarshan Pandey
     * @access public
     * @path  http://52.38.132.133/verify_phone
     * @use   to send the cverification code to the user
     *  */
    function searchStores() {

        /*
          {
          "device_type": "iOS",
          "latitude": "78235",
          "longitude": "62532",
          "user_type": "1",
          "user_id": "23",
          "filter_option": "1,2,3,4",
          "search_keyword": "abc store"
          }
         */
        $json = file_get_contents('php://input');

        if (!empty($json)) {

            $json = json_decode($json, true);
            $this->load->model('Stores_model');
            $webObj = new Stores_model();
            $data = $webObj->getStoreList($json);
            if (!empty($data)) {
                response(true, '200', $this->lang->line('store_list'), ($data));
            } else {
                response(false, '404', $this->lang->line('store_list_not_found'));
            }
        } else {

            response(false, '404', $this->lang->line('invalid_json'));
        }
    }

    function AddWalkin() {

        /*
          {
          "id":"1",
          "device_type": "iOS",
          "user_type": "2",
          "user_id": "34",
          "person_name": "dfsgsfg person",
          "person_contact_number": "+352534653465",
          "service_name": "haircut","service_price":"23","walkin_date":"","walkin_time":""
          }
         */
        $json = file_get_contents('php://input');

        if (!empty($json)) {

            $json = json_decode($json, true);
            $this->load->model('Stores_model');
            $webObj = new Stores_model();
            $data = $webObj->addWalkIn($json);
            if (!empty($data)) {
                response(true, '200', 'Walki added successfully', ($data));
            } else {
                response(false, '404', $this->lang->line('store_list_not_found'));
            }
        } else {

            response(false, '404', $this->lang->line('invalid_json'));
        }
    }

    function GetAllWalkin() {

        /*
          { "device_type": "iOS", "user_id":"34", "user_type":"2"}
         */
        $json = file_get_contents('php://input');

        if (!empty($json)) {

            $json = json_decode($json, true);
            $this->load->model('Stores_model');
            $webObj = new Stores_model();
            $data = $webObj->getAllWalkIns($json);
            if (!empty($data)) {
                response(true, '200', 'Walkin list', ($data));
            } else {
                response(false, '404', $this->lang->line('store_list_not_found'));
            }
        } else {

            response(false, '404', $this->lang->line('invalid_json'));
        }
    }

    function removeProfessionals() {

        /*
          {
          "device_type": "iOS",
          "user_id": "23",
          "store_id": "345",
          "professional_id": "64",
          "reason": "you are not punctual with time, reviews are not good from clients."
          }
         */
        $json = file_get_contents('php://input');

        if (!empty($json)) {

            $json = json_decode($json, true);
            $this->load->model('Stores_model');
            $webObj = new Stores_model();
            $data = $webObj->removeProfessionalFromStores($json);
            response(true, '200', 'Removed', ($data));
        } else {

            response(false, '404', $this->lang->line('invalid_json'));
        }
    }

    function getProfessionalDetails() {

        /*
         * 
          {
          "id":"1"
          }
         */
        $json = file_get_contents('php://input');

        if (!empty($json)) {
            $json = json_decode($json, true);
            $this->load->model('Login_model');
            $webObj = new Login_model();
            $userdata = $webObj->getProfessionalDetails($json);
            response(true, '200', 'Professional Details', $userdata);
        } else {

            response(false, '404', $this->lang->line('invalid_json'));
        }
    }
    
    function getUserDetail() {

        /*
         * 
          {
          "id":"1"
          }
         */
        $json = file_get_contents('php://input');

        if (!empty($json)) {
            $json = json_decode($json, true);
            $this->load->model('Login_model');
            $webObj = new Login_model();
            $userdata = $webObj->getUserDetailsById($json);
            response(true, '200', 'Professional Details', $userdata);
        } else {

            response(false, '404', $this->lang->line('invalid_json'));
        }
    }
    
    function makeAppointment() {

        /*
         * 
         {
    "device_type": "iOS",
    "user_id": "34",
    "service_id": "5",
    "professional_id": "23",
    "service_price": "$23",
    "appointment_Date_time": "dd/MM/yyyy HH:MM",
    "service_time": "hh:mm"
}
         */
        $json = file_get_contents('php://input');

        if (!empty($json)) {
            $json = json_decode($json, true);
            $this->load->model('Login_model');
            $webObj = new Login_model();
            $userdata = $webObj->makeAppointment($json);

            

            response(true, '200', 'Appointment saved', $userdata);
        } else {

            response(false, '404', $this->lang->line('invalid_json'));
        }
    }
    
    function listAppointment() {

        /*
         * 
         {
    "device_type": "iOS",
    "user_id": "34",
    "service_id": "5",
    "professional_id": "23",
    "service_price": "$23",
    "appointment_Date_time": "dd/MM/yyyy HH:MM",
    "service_time": "hh:mm"
}
         */
        $json = file_get_contents('php://input');

        if (!empty($json)) {
            $json = json_decode($json, true);
            $this->load->model('Login_model');
            $webObj = new Login_model();
            $userdata = $webObj->appointmentList($json);
            response(true, '200', 'Appointment List', $userdata);
        } else {

            response(false, '404', $this->lang->line('invalid_json'));
        }
    }
    
    function updateAppointment() {

        /*
         * 
        {
     "id":"1",   
    "device_type": "iOS",
    "user_id": "34",
    "service_id": "5",
    "professional_id": "23",
    "service_price": "$23",
    "appointment_Date_time": "dd/MM/yyyy HH:MM",
    "service_time": "hh:mm"
}
         */
        $json = file_get_contents('php://input');

        if (!empty($json)) {
            $json = json_decode($json, true);
            $this->load->model('Login_model');
            $webObj = new Login_model();
            $userdata = $webObj->updateAppointment($json);
            response(true, '200', 'Appointment Updated', $userdata);
        } else {

            response(false, '404', $this->lang->line('invalid_json'));
        }
    }
    
    function markFavouriteToAnyStoreORProfessional() {

        /*
         * 
        { "device_type": "iOS","user_id":"34","professional_id":"23","store_id":"","isFavourite":"1"}
         */
        $json = file_get_contents('php://input');

        if (!empty($json)) {
            $json = json_decode($json, true);
            $this->load->model('Login_model');
            $webObj = new Login_model();
            $userdata = $webObj->markFavouriteToAnyStoreORProfessional($json);
            response(true, '200', 'Appointment Updated', $userdata);
        } else {

            response(false, '404', $this->lang->line('invalid_json'));
        }
    }
    
    function getServicesforSelectedProfessional() {

        /*
         * 
        {
    "device_type": "iOS",
    "professional_id": "23",
    "user_id": "34"
}
         */
        $json = file_get_contents('php://input');

        if (!empty($json)) {
            $json = json_decode($json, true);
            $this->load->model('Service_model');
            $webObj = new Service_model();
            $webObj->setId($json['id']);
            $userdata = $webObj->getAllServicesForSelectedProfessional($json);
            response(true, '200', 'Service List', $userdata);
        } else {

            response(false, '404', $this->lang->line('invalid_json'));
        }
    }
    
    function getServicesforSelectedStore() {

        /*
         * 
        { "device_type": "iOS","store_id":"23","user_id":"34"}
         */
        $json = file_get_contents('php://input');

        if (!empty($json)) {
            $json = json_decode($json, true);
            $this->load->model('Service_model');
            $webObj = new Service_model();
            $webObj->setId($json['id']);
            $userdata = $webObj->getServicesforSelectedStore($json);
            response(true, '200', 'Service List', $userdata);
        } else {

            response(false, '404', $this->lang->line('invalid_json'));
        }
    }
    
    function getProfessionalsForSelectedServices() {

        /*
         * 
        { "device_type": "iOS","service_id":"23","user_id":"34"}
         */
        $json = file_get_contents('php://input');

        if (!empty($json)) {
            $json = json_decode($json, true);
            $this->load->model('Service_model');
            $webObj = new Service_model();
            $webObj->setId($json['id']);
            $userdata = $webObj->getProfessionalsForSelectedServices($json);
            response(true, '200', 'Service List', $userdata);
        } else {

            response(false, '404', $this->lang->line('invalid_json'));
        }
    }
    
    function getProfessionalsForSelectedStore() {

        /*
         * 
        { "device_type": "iOS","store_id":"23","user_id":"34"}
         */
        $json = file_get_contents('php://input');

        if (!empty($json)) {
            $json = json_decode($json, true);
            $this->load->model('Service_model');
            $webObj = new Service_model();
            $webObj->setId($json['id']);
            $userdata = $webObj->getProfessionalsForSelectedStore($json);
            response(true, '200', 'Service List', $userdata);
        } else {

            response(false, '404', $this->lang->line('invalid_json'));
        }
    }

    /**
     * @author Sankarshan Pandey
     * @access public
     * @path  http://52.38.132.133/verify_phone
     * @use   to send the cverification code to the user
     *  */
    function getNotifications() {

        /*
         * 
          {
          "user_id": "1"
          }

         */
        $json = file_get_contents('php://input');

        if (!empty($json)) {
            $json = json_decode($json, true);
            $this->load->model('Appointment_model');
            $webObj = new Appointment_model();
            $webObj->setId($json['user_id']);
            $userdata = $webObj->getAllNotifications($json['reason']);
            
            response(true, '200', 'notification', $userdata);
        } else {
            response(false, '404', $this->lang->line('invalid_json'));
        }
    }

}
