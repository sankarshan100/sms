<?php

if (!defined('BASEPATH'))
    exit('No direct script access allowed');

class Index extends CI_Controller {

    public function __construct() {
        parent::__construct();
    }

    function index() {
        echo json_encode(array("isSuccess" => 'true', "Message" => 'Minits webservices', "Result" => array()));
    }

    function showAllTables() {

        $dbname = 'sms';

        if (!mysql_connect('smsproject.crthrmz0na89.us-west-2.rds.amazonaws.com', 'awsuser', 'awsuser123')) {
            echo 'Could not connect to mysql';
            exit;
        }

        $sql = "SHOW TABLES FROM $dbname";
        $result = mysql_query($sql);

        if (!$result) {
            echo "DB Error, could not list tables\n";
            echo 'MySQL Error: ' . mysql_error();
            exit;
        }

        while ($row = mysql_fetch_row($result)) {
            echo "Table: {$row[0]}\n";
        }

        mysql_free_result($result);
    }

}
