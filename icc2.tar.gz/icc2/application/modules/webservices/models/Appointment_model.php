<?php

class Appointment_model extends CI_Model{
    
    private $_id="";
    private $_user_id="";
    private $_service_id="";
    private $_professional_id="";
    private $_date="";
    private $_time="";
    private $_status="";
    private $_created_on="";
    private $_status_by="";
    private $_modified_on="";
    
    function getId() {
        return $this->_id;
    }

    function getUser_id() {
        return $this->_user_id;
    }

    function getService_id() {
        return $this->_service_id;
    }

    function getProfessional_id() {
        return $this->_professional_id;
    }

    function getDate() {
        return $this->_date;
    }

    function getTime() {
        return $this->_time;
    }

    function getStatus() {
        return $this->_status;
    }

    function getCreated_on() {
        return $this->_created_on;
    }

    function getStatus_by() {
        return $this->_status_by;
    }

    function getModified_on() {
        return $this->_modified_on;
    }

    function setId($id) {
        $this->_id = $id;
    }

    function setUser_id($user_id) {
        $this->_user_id = $user_id;
    }

    function setService_id($service_id) {
        $this->_service_id = $service_id;
    }

    function setProfessional_id($professional_id) {
        $this->_professional_id = $professional_id;
    }

    function setDate($date) {
        $this->_date = $date;
    }

    function setTime($time) {
        $this->_time = $time;
    }

    function setStatus($status) {
        $this->_status = $status;
    }

    function setCreated_on($created_on) {
        $this->_created_on = $created_on;
    }

    function setStatus_by($status_by) {
        $this->_status_by = $status_by;
    }

    function setModified_on($modified_on) {
        $this->_modified_on = $modified_on;
    }
    
    function getAppointmentList($postData){
        $professionalId=  $this->getId();
        $query=  $this->db->select('ta.id,if(concat(tu.first_name," ",tu.last_name) IS NULL,"",concat(tu.first_name," ",tu.last_name)) as professionalName,if(concat(tu2.first_name," ",tu2.last_name) IS NULL,"",concat(tu2.first_name," ",tu2.last_name)) as user_name,if(sto.address IS NULL,"",sto.address) as addressOfStore,tu.id as user_id,if(ts.service_name IS NULL,"",ts.service_name) as service_name,ta.created_on as datetime,tu.mobile,if(tu2.image IS NULL,"",tu2.image) as user_image,if(tu.image IS NULL,"",tu.image) as professional_image,ta.status as isAccepted,ta.service_price as appointmentPrice,if(sto.image IS NULL,"",sto.image) as storeImage,if(service_description IS NULL,"",service_description) as service_description',FALSE)
                ->from('tbl_appointment as ta')
                ->join('tbl_users as tu','tu.id=ta.professional_id','left')
                ->join('tbl_users as tu2','tu2.id=ta.user_id','left')
                ->join('tbl_stores as sto','sto.id=ta.store_id','left')
                ->join('tbl_services as ts','ts.id=ta.service_id','left')
                ->where('DATE(appointment_Date_time) >=',date('y-m-d'));
        if($postData['user_type']=='3'){
        $query=  $this->db->where('ta.user_id',$postData['user_id']);
        }else{
        $query=  $this->db->where('ta.professional_id',$postData['user_id']);    
        $query=  $this->db->or_where('ta.user_id',$postData['user_id']);    
        }
        $query=  $this->db->get();
        //echo $this->db->last_query();die;
        $row=$query->result_array();
        if($query->num_rows()>0){
            return $row;
        }else{
            return array();
        }
    }
    
    function getAppointmentDetails($postData){
        
        $query=  $this->db->select('ta.id,if(concat(tu.first_name," ",tu.last_name) IS NULL,"",concat(tu.first_name," ",tu.last_name)) as professionalName,if(concat(tu2.first_name," ",tu2.last_name) IS NULL,"",concat(tu2.first_name," ",tu2.last_name)) as user_name,if(sto.name IS NULL,"",sto.name) as store_name,if(sto.address IS NULL,"",sto.address) as addressOfStore,tu.id as professional_id,if(ts.service_name IS NULL,"",ts.service_name) as service_name,ta.created_on as datetime,tu.mobile,if(tu2.image IS NULL,"",tu2.image) as user_image,ta.status as isAccepted,ta.service_price as appointmentPrice,if(sto.image IS NULL,"",sto.image) as storeImage,if(service_description IS NULL,"",service_description) as service_description,tu.mobile,tu.email as professionalEmail,tu.longitude as professionalLatitude,tu.image as professionalImage,tu.address as professionalAddress,tu.nick_name as professionalNickName,tu.gender as professionalGender,tu.dob as professionalDob,tu.country as professionalCountry,tu2.id userID,tu2.mobile as userMobile,tu2.email as userEmail,tu2.image as userImage,tu2.address as userAddress,tu2.nick_name as userNickName,tu2.gender userGender,tu2.dob as userDob,tu2.country as userCountry',FALSE)
                ->from('tbl_appointment as ta')
                ->join('tbl_users as tu','tu.id=ta.professional_id','left')
                ->join('tbl_users as tu2','tu2.id=ta.user_id','left')
                ->join('tbl_stores as sto','sto.id=ta.store_id','left')
                ->join('tbl_services as ts','ts.id=ta.service_id','left')
                ->where('ta.id',$postData['appointment_id'])
                ->get();
        $row=$query->row_array();
        if($query->num_rows()>0){
            return $row;
        }else{
            return array();
        }
    }
    
    function updateAppointmentStatus($reason=''){
        
        $status=  $this->getStatus();
        if($status=='1'){
            
            $this->db->set('status','1')->where('id',  $this->getId())->update('tbl_appointment');
            
        }else if($status=='2'){
            
            //$this->db->set('status','2')->set('reason',$reason)->where('id',  $this->getId())->update('tbl_appointment');
            $this->db->where('id',  $this->getId())->delete('tbl_appointment');
            
        }
        $appointmentData=$this->db->where('id',$this->getId())->get('tbl_appointment')->row_array();
        return $appointmentData;
        
        
    }


    function getAllNotifications(){

        $notifications=$this->db->select()
                ->where('user_id',$this->getId())
                ->get('tbl_notifications')->result_array();
        return $notifications;

    }


    
    function updateAppointmentDetail(){
        
        $this->db->set('date',  $this->getCreated_on())->where('id',  $this->getId())->update('tbl_appointment');
        return TRUE;
        
    }

}