<?php

class LoginController extends MX_Controller {

    public function __construct() {
        parent::__construct();
        $this->lang->load('en');
    }

    /*     * **********************Login web services start*********************** */

    /**
     * @author Sankarshan Pandey
     * @access public
     * @path  http://52.38.132.133/verify_phone
     * @use   to send the cverification code to the user
     *  */
    public function verify_phone() {

        $json = file_get_contents('php://input');

        if (!empty($json)) {

            $json = json_decode($json, true);

            $this->load->model('Login_model');
            $webObj = new Login_model();
            $webObj->set_mobile_no($json['mobile']);
            $code = $webObj->sendCode();
            response(true, '200', $this->lang->line('verification_code_sent'), array($code));
        } else {
            response(false, '404', $this->lang->line('invalid_json'));
        }
    }

    /**
     * @author Sankarshan Pandey
     * @access public
     * @path  http://52.38.132.133/verify_code
     * @use   to check if the verification code is same as sent 
     *  */
    public function verify_code() {
		
        $json = file_get_contents('php://input');

        if (!empty($json)) {

            $json = json_decode($json, true);

            $this->load->model('Login_model');
            $webObj = new Login_model();
            $webObj->set_mobile_no($json['mobile']);
            $webObj->set_verify_code($json['verifyCode']);

            if ($webObj->checkCode()) {
                response(true, '200', $this->lang->line('verification_correct'));
            } else {
                response(false, '404', $this->lang->line('verification_incorrect'));
            }
        } else {

            response(false, '404', $this->lang->line('invalid_json'));
        }
    }

    /**
     * @author Sankarshan Pandey
     * @access public
     * @path  http://52.38.132.133/login
     * @use   for user login
     *  */
    public function login() {
        //$this->load->helper('token_helper');
        /*
         * {
		  "mobile":"+918527333451",
          "email": "sankarshan100@gmail.com",
          "password": "123456",
          "device_token": "device_token_of_mobile",
          "device_type": "android"
          }
         */
        $json = file_get_contents('php://input');

        if (!empty($json)) {

            $json = json_decode($json, true);
            $this->load->model('Login_model');
            $webObj = new Login_model();
            $webObj->set_email($json['email']);
            $webObj->set_pass(trim($json['password']));
            $webObj->set_device_token($json['device_token']);
            $webObj->set_device_type($json['device_type']);
            $data = $webObj->loginUser($json['mobile']);

            if (!empty($data)) {
                response(true, '200', $this->lang->line('home_page'), array($data));
            } else {
                response(false, '404', $this->lang->line('invalid_credential'));
            }
        } else {

            response(false, '404', $this->lang->line('invalid_json'));
        }
    }
public function registration(){
	 try{
            $identity_proof = $_POST['identity_proof'];
			$device_token = $_POST['device_token'];
			$device_type = $_POST['device_type'];
			$email = $_POST['email'];
			$latitude = $_POST['latitude'];
			$longitude = $_POST['longitude'];
			$mobile = $_POST['mobile'];
			$password = $_POST['password'];
			$user_type = $_POST['user_type'];
			$name = $_POST['name'];
			$fb_id = $_POST['fb_id'];
			$url = $_POST['url'];
			$address = $_POST['address'];
      $fb_id = $_POST['fb_id'];
			
			$this->load->model('Login_model', 'users');
			//echo "<pre>";print_r($_POST);die;
			if(empty($device_token)){
				 throw new Exception("device token is empty", 404);
			}
			if(empty($device_type)){
				 throw new Exception("device type is empty", 404);
			}
			if(empty($email)){
				 throw new Exception("email id is empty", 404);
			}
			if(empty($latitude)){
				 throw new Exception("latitude is empty", 404);
			}
			if(empty($longitude)){
				 throw new Exception("longitude is empty", 404);
			}
			if(empty($mobile)){
				 throw new Exception("mobile is empty", 404);
			}
			if(empty($password)){
				 throw new Exception("password is empty", 404);
			}						
		
			/* if($this->users->check_mobile($mobile)){
				throw new Exception("mobile number already exist", 404);
			}
			if($this->users->check_email()){
				throw new Exception("email id already exist", 404);
			} */
			die("here");
			$_POST['password'] =  md5($_POST['password']);
			 if ($this->users->addUser($_POST)) {
				  $userDetails = $this->users->addUser($_POST);
				  
            $arr = array(
			    "success"=>true,
			    "status"=>200,
			    "message"=>'User registered successfully',
				"Result"=>$userDetails              
            );
			 }	
        } catch (Exception $ex) {          
            $arr = array(
			    "success"=>false,
                "status" => $ex->getCode(),
                "message" => $ex->getMessage()
            );
			
        }
		$json = json_encode($arr, JSON_PRETTY_PRINT);
        echo $json;
}
    /**
     * @author Sankarshan Pandey
     * @access public
     * @path  http://52.38.132.133/registration
     * @use   to check if the verification code is same as sent 
     *  */
    public function registration1() {
        /*
          {
          "email": "marcus@minits.com",
          "password": "123456",
          "mobile": "+918527333451",
          "device_token": "device_token_of_mobile",
          "device_type": "android",
          "latitude": "78235",
          "longitude": "62532",
          "user_type":"1,2,3"
          }
         */
        $json = file_get_contents('php://input');
        //echo $json;die;
        if (!empty($json)) {

            $json = json_decode($json, true);
			//echo $json;die;
            $this->load->model('Login_model');
            $userDetails=array();
          //  print_r($json);exit();
            //$this->load->model('User_posts_model');
            //$objUserPostModel   =   new User_posts_model();
            $webObj = new Login_model();
            $webObj->set_mobile_no($json['mobile']);
            $webObj->set_name($json['user_name']);
            $webObj->set_email($json['email']);
            $webObj->set_pass($json['password']);
            $webObj->set_device_token($json['device_token']);
            $webObj->set_device_type($json['device_type']);
            $webObj->set_latitude($json['latitude']);
            $webObj->set_longitude($json['longitude']);
            $webObj->set_fb_id($json['fb_id']);
            $webObj->set_username($json['name']);
            $webObj->set_url($json['url']);
			 $webObj->set_longitude($json['address']);
            $idProof=fileImageUpload('identity', 'identity_proof');
            // print_r($json);die;
            if ($webObj->check_mobile()) {
			
                $userDetails = $webObj->registerUser($json['user_type'],$idProof);
                response(true, '200', $this->lang->line('home_page'), array($userDetails), true);
            } else {			
                // response
          response(false, '404', $this->lang->line('mobile_exist'),array(), false);                
            }
        } else {
            response(false, '404', $this->lang->line('invalid_json'));
        }
    }

    /**
     * @author Rlogical
     * @access public
     * @path  http://52.38.132.133/forgot
     * @use   for user login
     *  */
    public function forgot_password() {
        /*
          {
          "email": "pdcs051@gmail.com"
          }
         */
        $json = file_get_contents('php://input');
        //print_r($json);
        if (!empty($json)) {
            $json = json_decode($json, true);
            response(true, '200', $this->lang->line('forgot'), array());
        } else {
            response(false, '404', $this->lang->line('invalid_json'));
        }
    }

    /**
     * @author Sankarshan Pandey
     * @access public
     * @path  http://52.38.132.133/change_password
     * @use   for user change password
     *  */
    public function change_password() {
        /*
         * {
          "email": "pdcs051@gmail.com",
          "password":"1991",
          "new_password":"123456"
          }
         */
        $json = file_get_contents('php://input');
        if (!empty($json)) {
            $json = json_decode($json, true);
            $this->load->model('Login_model');
            $webObj = new Login_model();
            $webObj->set_email($json['email']);
            $webObj->set_pass(trim($json['password']));
            $webObj->set_newpass(trim($json['new_password']));
            $data = $webObj->changePassword();
            if ($data['0'] == "1") {
                response(false, '200', "Please enter correct old password", $data);
            } elseif ($data['0'] == "2") {
                response(true, '200', "User password change sucessfully.", $data);
            } else {
                response(false, '200', "please insert all data.", $data);
            }
        } else {
            response(false, '404', $this->lang->line('invalid_json'));
        }
    }
    
    /**
     * @author Sankarshan Pandey
     * @access public
     * @path  http://52.38.132.133/verify_code
     * @use   to check if the verification code is same as sent 
     *  */
    public function user_logout() {

        $json = file_get_contents('php://input');

        if (!empty($json)) {

            $json = json_decode($json, true);

            $this->load->model('Login_model');
            $webObj = new Login_model();
            $webObj->setId($json['id']);
            $webObj->loggedOutuser();
            response(true, '200', $this->lang->line('logout'));
            
        } else {

            response(false, '404', $this->lang->line('invalid_json'));
        }
    }

}

?>  