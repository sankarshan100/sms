<?php

class Service_model extends CI_Model {

    private $_id = "";
    private $_service_name = "";
    private $_price = "";
    private $_store_id = "";
    private $_is_delete = "";
    private $_created_on = "";

    function getId() {
        return $this->_id;
    }

    function getService_name() {
        return $this->_service_name;
    }

    function getPrice() {
        return $this->_price;
    }

    function getStore_id() {
        return $this->_store_id;
    }

    function getIs_delete() {
        return $this->_is_delete;
    }

    function getCreated_on() {
        return $this->_created_on;
    }

    function setId($id) {
        $this->_id = $id;
    }

    function setService_name($service_name) {
        $this->_service_name = $service_name;
    }

    function setPrice($price) {
        $this->_price = $price;
    }

    function setStore_id($store_id) {
        $this->_store_id = $store_id;
    }

    function setIs_delete($is_delete) {
        $this->_is_delete = $is_delete;
    }

    function setCreated_on($created_on) {
        $this->_created_on = $created_on;
    }

    function getAllServices($postdata) {
        $storeId = $this->getStore_id();
        $query = $this->db->select('id as service_id,service_name,user_id,price,service_time,service_description', FALSE)
                ->from('tbl_services');
        //->where('is_delete', '1');
        if ($postdata['user_type'] != '3') {
            $query = $this->db->where('user_id', $postdata['user_id']);
        }
        if ($storeId != '') {
            $query = $this->db->where('store_id', $storeId);
        }
        $query = $this->db->order_by('created_on', 'desc')
                ->get()
                ->result_array();
        //echo $this->db->last_query();die;
        return $query;
    }

    function saveStore($storeData, $image = '') {

        $data['name'] = $storeData['store_name'];
        $data['address'] = $storeData['address'];
        $data['mobile'] = $storeData['mobile'];
        $data['email'] = $storeData['email'];
        $data['description'] = $storeData['description'];
        $data['image'] = $image;
        $data['latitude'] = $storeData['latitude'];
        $data['longitude'] = $storeData['longitude'];
        $data['user_id'] = $storeData['id'];
        $data = array_filter($data);
        $this->db->set($data)->insert('tbl_stores');
        $lastId = $this->db->insert_id();
        $this->db->where('user_id', $lastId)->where('user_type', '2')->delete('tbl_availability');
        $this->saveAvailibility($storeData['availability'], $storeData['professionals'], '2');
        $this->saveServices(explode(",", $storeData['services']), $lastId);
        $this->saveProfessionals(explode(",", $storeData['professionals']), $lastId);
        return array();
    }

    function saveAvailibility($availibility, $professionals, $type) {

//        foreach ($availibility as $sa) {
//            $dataAvailability['user_id'] = $userId;
//            $dataAvailability['user_type'] = $type;
//            $dataAvailability['day'] = $sa['day'];
//            $dataAvailability['start_time'] = $sa['start_time'];
//            $dataAvailability['end_time'] = $sa['end_time'];
//            $this->db->set($dataAvailability)->insert('tbl_availability');
//            
//            
//        }
//        
        $this->db->where('user_id', $userId)->delete('tbl_availability');
        $fiveMinutes = 5 * 60;
        foreach ($professionals as $key => $value) {
            foreach ($availibility as $sa) {
                $startRange = strtotime($sa['start_time']);
                $endRange = strtotime($sa['end_time']);
                for ($i = $startRange; $i <= $endRange; $i+=$fiveMinutes) {
                    $availabilityData['user_id'] = $value;
                    $availabilityData['user_type'] = '2';
                    $availabilityData['day'] = $sa['day'];
                    $availabilityData['start_time'] = date("H:i", $i);
                    $availabilityData['end_time'] = date("H:i", $i + $fiveMinutes);
                    $this->db->set($availabilityData)->insert('tbl_availability');
                }
            }
        }

        return TRUE;
    }

    function saveServices($services, $storeId) {

        foreach ($services as $sa) {
            $dataService['store_id'] = $storeId;
            $dataService['service_id'] = $sa;
            $this->db->set($dataService)->insert('tbl_store_services');
        }

        return TRUE;
    }

    function saveProfessionals($professional, $storeId) {

        foreach ($professional as $sa) {
            $professionalData['store_id'] = $storeId;
            $professionalData['user_id'] = $sa;
            $this->db->set($professionalData)->insert('tbl_professionals');
        }

        return TRUE;
    }

    function saveService($serviceData) {
        $serviceId = $serviceData['service_id'];
        $data['service_name'] = $serviceData['service_name'];
        $data['price'] = $serviceData['service_price'];
        $data['store_id'] = $serviceData['store_id'];
        $data['user_id'] = $serviceData['user_id'];
        $data['user_type'] = $serviceData['user_type'];
        $data['time'] = $serviceData['service_time'];
        $data['created_on'] = gmdate('Y-m-d H:i:s');
        $data['service_time'] = $serviceData['service_time'];
        $data['service_description'] = $serviceData['service_description'];
        if ($serviceId != '') {
            $this->db->set($data)->where('id', $serviceId)->update('tbl_services');
        } else {
            $this->db->set($data)->insert('tbl_services');
        }
        //echo $this->db->last_query();die;
        return array();
    }

    function deleteService() {

        $serviceId = $this->getId();
        $this->db->where('id', $serviceId)->delete('tbl_services');
        return array();
    }

    function getProfessionalsList($storeId) {

        $query = $this->db->select('id,if(user_name IS NULL,email,user_name) as name,image', FALSE)
                ->from('tbl_users')
                ->where('is_deleted', '1')
                ->where('store_id', $storeId)
                ->order_by('created_on', 'desc')
                ->get();
        if ($query->num_rows() > 0) {
            return $query->result_array();
        } else {
            return array();
        }
    }

    function storeDetails() {
        $userId=$this->getId();
        
        $query=  $this->db->select("description,professionals,id as store_id,name,address,if((select avg(rating) from tbl_rating where rating_to=tbl_stores.id and user_type='2') IS NULL,'',if((select avg(rating) from tbl_rating where store_id=tbl_stores.id) IS NULL,'',(select avg(rating) from tbl_rating where store_id=tbl_stores.id))) as rating,image",FALSE)
                ->from('tbl_stores')->where('id',$userId);;    
        
        $query=  $this->db->get();
        //echo $this->db->last_query();die;
        
        $row=$query->row_array();
        $value=$row;
        
        //foreach ($row as $key=>$value){
            //$prof=explode(',',$value['professionals']);
            $prof= json_decode($value['professionals']);
            $service=json_decode($value['services']);

            $rating=$this->db->select('AVG(rating) as rating')->where_in('rating_to',$prof)->get('tbl_rating');
            if($rating->num_rows()>0){
                $ratingRes=$rating->row_array();
                if($ratingRes['rating']>0){
                    $row['rating']=$ratingRes['rating'];
                }else{
                    $row['rating']='0';
                }

            }else{
                $row['rating']='0';
            }
            //print_r($prof);
            //print_r($service);die;
            //$this->db->where_in('id',$prof)->get('tbl_users')->result_array();
            $row['professionalsList']= $this->db->where_in('id',$prof)->get('tbl_users')->result_array();

            if($value['services']!='0'){
            $row['servicesList']= $this->db->where_in('id',$service)->get('tbl_services')->result_array();
         }else{
         	$row['servicesList']= array();
         }
            
        //}
        return $row;
//        if($query->num_rows()>0){
//            return $query->result_array();
//        }else{
//            return array();
//        }
    }

    function getAllServicesForSelectedProfessional($postdata) {

        $query = $this->db->select('id as service_id,service_name,user_id,price', FALSE)
                ->from('tbl_services');
        $query = $this->db->where('user_id', $postdata['professional_id']);
        $query = $this->db->order_by('created_on', 'desc')
                ->get()
                ->result_array();
        //echo $this->db->last_query();die;
        return $query;
    }

    function getServicesforSelectedStore($postdata) {

        $query = $this->db->select('id as service_id,service_name,user_id,price', FALSE)
                ->from('tbl_services');
        $query = $this->db->where('store_id', $postdata['store_id']);
        $query = $this->db->order_by('created_on', 'desc')
                ->get()
                ->result_array();
        //echo $this->db->last_query();die;
        return $query;
    }

    function getProfessionalsForSelectedServices($postdata) {

        $query = $this->db->select('id as service_id,service_name,user_id,price', FALSE)
                ->from('tbl_services');
        $query = $this->db->where('id', $postdata['service_id']);
        $query = $this->db->order_by('created_on', 'desc')
                ->get()
                ->result_array();
        //echo $this->db->last_query();die;
        return $query;
    }

    function getProfessionalsForSelectedStore($postdata) {
        
        $query = $this->db->select('tp.is_accept,tu.is_trail,tu.id,if(tu.user_name IS NULL,tu.email,tu.user_name) as name,tu.email,if(tu.user_name IS NULL,"",tu.user_name) as user_name', FALSE)
                ->from('tbl_professionals as tp')
                ->join('tbl_users as tu','tu.id=tp.user_id','left')
                ->where('tp.store_id',$postdata['store_id'])->where('tu.is_trail', '0');
        if($postdata['user_type']=='3'){
        $query = $this->db->where('tp.is_accept', '1');
        }
        $query = $this->db->order_by('tp.created_on', 'desc')->get();
        //echo $this->db->last_query();die;
        return $query->result_array();
    }

}
