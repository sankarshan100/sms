<?php

class Stores_model extends CI_Model{
    
    private $_id="";
    private $_name="";
    private $_address="";
    private $_mobile="";
    private $_email="";
    private $_availability="";
    private $_description="";
    private $_image="";
    private $_latitude="";
    private $_longitude="";
    private $_is_deleted="";
    private $_created_on="";
    private $_user_id="";
    
    function getId() {
        return $this->_id;
    }

    function getName() {
        return $this->_name;
    }

    function getAddress() {
        return $this->_address;
    }

    function getMobile() {
        return $this->_mobile;
    }

    function getEmail() {
        return $this->_email;
    }

    function getAvailability() {
        return $this->_availability;
    }

    function getDescription() {
        return $this->_description;
    }

    function getImage() {
        return $this->_image;
    }

    function getLatitude() {
        return $this->_latitude;
    }

    function getLongitude() {
        return $this->_longitude;
    }

    function getIs_deleted() {
        return $this->_is_deleted;
    }

    function getCreated_on() {
        return $this->_created_on;
    }

    function getUser_id() {
        return $this->_user_id;
    }

    function setId($id) {
        $this->_id = $id;
    }

    function setName($name) {
        $this->_name = $name;
    }

    function setAddress($address) {
        $this->_address = $address;
    }

    function setMobile($mobile) {
        $this->_mobile = $mobile;
    }

    function setEmail($email) {
        $this->_email = $email;
    }

    function setAvailability($availability) {
        $this->_availability = $availability;
    }

    function setDescription($description) {
        $this->_description = $description;
    }

    function setImage($image) {
        $this->_image = $image;
    }

    function setLatitude($latitude) {
        $this->_latitude = $latitude;
    }

    function setLongitude($longitude) {
        $this->_longitude = $longitude;
    }

    function setIs_deleted($is_deleted) {
        $this->_is_deleted = $is_deleted;
    }

    function setCreated_on($created_on) {
        $this->_created_on = $created_on;
    }

    function setUser_id($user_id) {
        $this->_user_id = $user_id;
    }
    
    function getStoreList($userType){
        $userId=$this->getId();
        $latitude=$userType['latitude'];
        $longitude=$userType['longitude'];
        if($latitude!=''){
        $query=  $this->db->select("services,description,professionals,services,ROUND((((acos(sin((".$latitude."*pi()/180)) * 
            sin((`latitude`*pi()/180))+cos((".$latitude."*pi()/180)) * 
            cos((`latitude`*pi()/180)) * cos(((".$longitude."- `longitude`)* 
            pi()/180))))*180/pi())*60*1.1515
        )) as distance_KM,latitude,longitude,id as store_id,name,address,image,store_openDays,storeS3ImageName,storeEmailAddress,mobile,image",FALSE)
                ->from('tbl_stores');
        $query=  $this->db->having('distance_KM <=','(3*1.1515)');
        }else{
        $query=  $this->db->select("services,description,professionals,tbl_stores.id as store_id,name,address,if((select avg(rating) from tbl_rating where rating_to=tbl_stores.id and user_type='2') IS NULL,'',if((select avg(rating) from tbl_rating where store_id=tbl_stores.id) IS NULL,'',(select avg(rating) from tbl_rating where store_id=tbl_stores.id))) as rating,image",FALSE)
                ->from('tbl_stores');        
        }
        if($userType['user_type']=='3'){
        $query=  $this->db->where('(select count(*) from tbl_professionals where store_id=tbl_stores.id) >','0',FALSE); 
        
        }
        if($userType['search_keyword']!=''){
        $query=  $this->db->like('name',trim($userType['search_keyword']),'both');
        }
        if($userType['user_type']=='2'){
        $query=  $this->db
                ->where('user_id',$userType['user_id']);
        }
        if($userType['store_id']!=''){
            $query=  $this->db->where('id',$userType['store_id']);
        }
        $query=  $this->db->get();
        //echo $this->db->last_query();die;
        
        $row=$query->result_array();
        //print_r($row);die;
        foreach ($row as $key=>$value){            
            //$prof=explode(',',$value['professionals']);
            
            $getProfessional= $this->db->select('group_concat(user_id) as user_id')
                    ->from('tbl_professionals')
                    ->where('store_id',$value['store_id'])
                    ->get();
            $profRes=$getProfessional->row_array();
            if($getProfessional->num_rows()>0){
                $prof= explode(",",$profRes['user_id']);
            }else{
                $prof= array(0);
            }
            
            //$prof= json_decode($value['professionals']);
            $service=json_decode($value['services']);

            $rating=$this->db->select('if(AVG(rating) IS NULL,0,AVG(rating)) as rating')->where_in('rating_to',$prof)->get('tbl_rating');
            if($rating->num_rows()>0){
                $ratingRes=$rating->row_array();
                if($ratingRes['rating']>0){
                    $row[$key]['rating']=$ratingRes['rating'];
                }else{
                    $row[$key]['rating']='0';
                }

            }else{
                $row[$key]['rating']='0';
            }
            
            $row[$key]['professionalsList']= $this->db->where_in('id',$prof)->get('tbl_users')->result_array();

            $isFavourite= $this->db->where('store_id',$value['store_id'])
                                    ->where('user_id',$userType['user_id'])
                                    ->order_by('id','desc')
                                    ->limit(1)
                                    ->get('favorite_items')
                                    ->row_array();
            //$row[$key]['isFavourite']=$isFavourite['isFavourite'];

            if($isFavourite['isFavourite']===NULL){
            $row[$key]['isFavourite']="";    
            }else{
            $row[$key]['isFavourite']=$isFavourite['isFavourite'];    
            }

            if(count($service)>0){
            $row[$key]['servicesList']= $this->db->where_in('id',$service)->get('tbl_services')->result_array();
         }else{
         	$row[$key]['servicesList']= array();
         }
            
        }
        if(count($prof)<=0){
            unset($row[$key]);
        }
        return $row;
//        if($query->num_rows()>0){
//            return $query->result_array();
//        }else{
//            return array();
//        }
    }
    
    function addStore($postData){
       $getUserDetails=getUserDetailsData($postData['user_id']);
       $storeId=$postData['store_id'];
        //$data['device_type']=$postData[];
        //$data['store_id']=$postData['store_id'];
        $data['latitude']=$postData['latitude'];
        $data['longitude']=$postData['longitude'];
        $data['user_type']=$postData['user_type'];
        $data['user_id']=$postData['user_id'];
        $data['name']=$postData['store_name'];
        $data['address']=$postData['address'];
        $data['mobile']=$postData['contact_number'];
        $data['store_open_time']=$postData['store_openTime'];
        $data['store_close_time']=$postData['store_CloseTime'];
        $data['services']=json_encode($postData['services']);
        $data['professionals']=json_encode($postData['professionals'],FALSE);
        //$data['description']=$postData['description'];
        //$data['store_close_date']=json_encode($postData['store_CloseDates'],FALSE);
        $data['store_openDays']=json_encode($postData['store_openDays']);
        $data['storeS3ImageName']=$postData['storeS3ImageName'];
        $data['description']=$postData['description'];
        $data['storeEmailAddress']=$postData['storeEmailAddress'];
        $data['image']=$postData['image'];
        //print_r($data);die;
        if($storeId!=''){
        $this->db->set($data)->where('id',$storeId)->update('tbl_stores');    
        }else{
        $query=$this->db->set($data)->insert('tbl_stores');
        //echo $this->db->last_query();die;
        $professionals=$postData['professionals'];
        $lastInsertId= $this->db->insert_id();
        foreach ($professionals as $key=>$value){
            
        $data1['status'] = '0';
        $data1['user_id'] = $value;
        $data1['store_id'] = $lastInsertId;
        $data1['notification'] = $getUserDetails['first_name']." ".$getUserDetails['last_name']." has invited you to join the store";
        //print_r($data);die;
        $this->db->set($data1)->insert('tbl_notifications');
        sendPushIphone($data['device_token'],$data1['notification'],'1',$data1);
        
        
        $data2['store_id']=$lastInsertId;
        $data2['user_id']=$value;
        $this->db->set($data2)->insert('tbl_professionals');
        
        }

        
        
        
		if(!$query){ return array();}
        }
        return $data;
        
    }
    
    function removeStore($postData){
        
        $this->db->where('id',$postData['store_id'])->delete('tbl_stores');
        return TRUE;
        
    }
    
    function removeService($postData){
        
        $this->db->where('id',$postData['service_id'])->delete('tbl_services');
        return TRUE;
        
    }
    
    function addWalkIn($postData){
        $id=$postData['id'];
        $data['user_id']=$postData['user_id'];
        $data['user_type']=$postData['user_type'];
        $data['person_name']=$postData['person_name'];
        $data['person_contact_number']=$postData['person_contact_number'];
        $data['service_name']=$postData['service_name'];
        $data['device_type']=$postData['device_type'];
        
        $data['service_price']=$postData['service_price'];
        $data['walkin_date']=$postData['walkin_date'];
        $data['walkin_time']=$postData['walkin_time'];
        
        if($id!=''){
        $this->db->set($data)->where('id',$id)->update('tbl_walkin');    
        }else{
        $this->db->set($data)->insert('tbl_walkin');
        }
        return TRUE;
    }
    
    function getAllWalkIns($postData){
        
        $query= $this->db->where('user_id',$postData['user_id'])->where('user_type',$postData['user_type'])->get('tbl_walkin');
        return $query->result_array();
        
    }
    
    function saveFeedback($postData){
        
        $data['user_id']=$postData['user_id'];
        $data['feedback']=$postData['feedback_message'];
        $data['feedback_to']='1';
        $data['feedback_message']=$postData['feedback_message'];
        $data['user_type']=$postData['user_type'];
        $this->db->set($data)->insert('tbl_feedback');
        return TRUE;
    }
    
    function removeProfessionalFromStores($postData){
        
        $data['store_id']=$postData['store_id'];
        $data['professional_id']=$postData['professional_id'];
        $data['removed_by']=$postData['removed_by'];
        $data['reason']=$postData['reason'];
        $this->db->set($data)->insert('professional_removed');
        $this->db->query("UPDATE tbl_stores SET professionals=REPLACE(professionals,'$postData[professional_id]','')");
        
        $data1['is_accept']=$postData['is_request_accepted'];
        $this->db->set($data1)
                ->where('store_id',$postData['store_id'])
                ->where('user_id',$postData['professional_id'])
                ->update('tbl_professionals');
        
        return TRUE;
    }

    function getAllSoloProfessionals(){
        die("here");
        $query=$this->db->select('professionals')->from('tbl_stores')->get()->result_array();
        echo $this->db->last_query();
        foreach ($query as $key => $value) {
            $professionals=array();
            if($value['professionals']){
                $professionals=json_decode($professionals);
                $professionalsArray=array_push($professionalsArray, $professionals);
            }
        }
        $allProfessionalsAssociatedWithStore=array_filter($professionalsArray);
        print_r($allProfessionalsAssociatedWithStore);die;

        $query = $this->db->select('id,if(user_name IS NULL,email,user_name) as name,email,if(user_name IS NULL,"",user_name) as user_name,if(image IS NULL,"",image) as professionalImageUrl,mobile,if(rating IS NULL,"",rating) as rating', FALSE)
                ->from('tbl_users')
                ->where('is_deleted', '1')->where_in('id',$allProfessionalsAssociatedWithStore);
        $query = $this->db->where('user_type', '1')
                ->order_by('created_on', 'desc')
                ->get();
                
                $row=$query->result_array();
                foreach ($row as $key=>$value){
                    
        /*$isFavourite= $this->db->where('professional_id',$value['id'])
                                    ->where('user_id',$this->getId())
                                    ->order_by('id','desc')
                                    ->limit(1)
                                    ->get('favorite_items')
                                    ->row_array();
                                    //echo $this->db->last_query();die;
            if($isFavourite['isFavourite']===NULL){
            $row[$key]['isFavourite']="";    
            }else{
            $row[$key]['isFavourite']=$isFavourite['isFavourite'];    
            }*/
            $row[$key]['isFavourite']="";

    }

    return $row;

}
}