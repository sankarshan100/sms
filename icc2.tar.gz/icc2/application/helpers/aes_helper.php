<?php
$check_version = getallheaders();

 if (array_key_exists("AuthenticationKey",$check_version))
  {
   
        $this->load->library('AES');

        $enc = $this->config->item('auth_key');

         //key for authentication MINBALA
        $aes = new AES('1429256486', 'MINBALA', 128, 'ecb');

        //$enc = $aes->encrypt();echo $enc;die;

        $aes->setData($enc);

        $dec=$aes->decrypt();
        //echo "After encryption: ".$enc."<br/>";
        //echo "After decryption: ".$dec."<br/>";

        $server   = time();  //server timestamp

        //echo $server;
        $diff = $server - $dec;

        //echo $diff;
         if($diff > 60)
           {
               echo json_encode(array('statusCode'=> 200,'Result' => array(),'Message' => 'Access Denied', 'Success'=> false));
               exit;  
           }
          
  }

 




  


?>