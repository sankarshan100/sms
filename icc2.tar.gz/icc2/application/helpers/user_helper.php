<?php

if (!defined('BASEPATH'))
    exit('No direct script access allowed');

//function pre($array) {
//    echo "<pre>";
//    print_r($array);
//    echo "</pre>";
//}

/**
 * @author revati Techahead
 * @access public
 * @use   get the json encoded response
 *  */
function response($success = true, $status = '200', $message, $data = array(), $session = true ) {
    echo json_encode(array(
        "success" => $success,
        "status" => $status,
        "message" => $message,
        "Result" => $data,
        "session"=>$session
    ));
    exit();
}

/**
 * @author Techahead
 * 
 */
function fileImageUpload($folderName, $file_name) {
    $config = array();
    $CI = & get_instance();
    $image = '';
    //print_r($_FILES["$file_name"]);die;
    if ($_FILES["$file_name"]['error'] == 0) {
        $pathToUpload = './assets/' . $folderName;
        if (!is_dir($pathToUpload)) {
            mkdir($pathToUpload, 0777, TRUE);
        }

        $config['upload_path'] = "./assets/$folderName/";
        // Location to save the image
        $config['allowed_types'] = 'gif|jpg|png|jpeg|bmp';
        $config['overwrite'] = FALSE;
        $config['remove_spaces'] = true;
        $config['maintain_ratio'] = TRUE;
        $config['file_name'] = time() . "_" . str_replace(' ', '_', $_FILES["$file_name"]['name']);
        $CI->load->library('upload', $config);
        $CI->upload->initialize($config);
        if (!$CI->upload->do_upload("$file_name")) {
        } else {
            $image = "assets/$folderName/" . $CI->upload->file_name;
        }
        return $image;
    }else{
        return '';
    }
}

// send email global function
function sendEmailGlobal($from_email = '', $email = '', $subject = '', $emailMessage = '', $attachment = '') {
//    $CI = & get_instance();
//    $config['wordwrap'] = TRUE;
//    $config['mailtype'] = 'html';
//    $CI->load->library('email');
//    $CI->email->set_newline("\r\n");
//    $CI->email->initialize($config);
//    $CI->email->from($from_email, $from_email);
//    $CI->email->to($email, $email);
//    $CI->email->subject($subject);
//
//    $CI->email->message($emailMessage);
//    $CI->email->send();
//    if($CI->email->send() == TRUE){
//        echo "hererer";die;
//    }else{
//        echo "dfdsgfg";
//        print_r($this->email->print_debugger());die;
//    }
    
    //send email using php mail function
    $to = $email;
    $subject = $subject;

    $message = "$emailMessage";

    $header = "-f:$from_email \r\n";
    $header .= "MIME-Version: 1.0\r\n";
    $header .= "Content-type: text/html\r\n";

	echo $header;die;
    $retval = mail ($to,$subject,$message,$header);

    if( $retval == true ) {
       echo "Message sent successfully..."; 
    }else {
	//ini_set('display_errors', 'On');
	//	error_reporting(E_ALL);
		
       echo "Message could not be sent...";
       //die;
    }
   return TRUE;
}


//function to conversion string to array
function convertingValues($string =""){
    $result = substr($string,1, -1);
    $result = str_replace('"','',$result);
    $ids = explode(",",$result);
    return $ids;
}