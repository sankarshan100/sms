﻿<?php

function sendAndroidPush($deviceToken, $msg) {
    //$registrationIDs = array($deviceToken);

    if (is_array($deviceToken)) {

        $registrationIDs = $deviceToken;
    } else {
        $registrationIDs = array($deviceToken);
    }

    // Message to be sent
    $message = $msg;
    $id=  rand(1, 100);
    //Set POST variables
    $url = 'https://android.googleapis.com/gcm/send';

    $fields = array(
        'registration_ids' => $registrationIDs,
        'data' => array("message" => $message,'id'=>$id),
    );

    $headers = array(
        'Authorization: key=AIzaSyBzKnW9YfuweTku9NV7YGrHcmvOh1T4FdM',
        'Content-Type: application/json'
    );
    //print_r(json_encode($fields));die;
    //Open connection
    $ch = curl_init();

    //Set the url, number of POST vars, POST data
    curl_setopt($ch, CURLOPT_URL, $url);

    curl_setopt($ch, CURLOPT_POST, true);
    curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);

    curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($fields));

    //Execute post
    $result = curl_exec($ch);
    //echo $result;die;
    //return $result;
    //Close connection
    curl_close($ch);

//    echo $result;
}

function sendAndroidPushAnother($deviceToken, $msg, $rowid) {
    //$registrationIDs = array($deviceToken);

    if (is_array($deviceToken)) {

        $registrationIDs = $deviceToken;
    } else {
        $registrationIDs = array($deviceToken);
    }

    // Message to be sent
    $message = $msg;

    //Set POST variables
    $url = 'https://android.googleapis.com/gcm/send';

    $fields = array(
        'registration_ids' => $registrationIDs,
        'data' => array("message" => $message, "type" => "1", "rowid" => $rowid),
    );

    $headers = array(
        'Authorization: key=AIzaSyAbTrmG-bxoQGomnH0hY5gWMCu6hRBot2U',
        'Content-Type: application/json'
    );

    //Open connection
    $ch = curl_init();

    //Set the url, number of POST vars, POST data
    curl_setopt($ch, CURLOPT_URL, $url);

    curl_setopt($ch, CURLOPT_POST, true);
    curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);

    curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($fields));

    //Execute post
    $result = curl_exec($ch);
    //return $result;
    //Close connection
    curl_close($ch);

    //echo $result;
}

function sendPush($deviceToken, $msg) {

    $apnsHost = 'gateway.sandbox.push.apple.com';   
    //$apnsHost = 'gateway.push.apple.com';
    $apnsPort = '2195';
    $apnsCert = 'apns-dev.pem';
    $passPhrase = '1234';
    $streamContext = stream_context_create();
    stream_context_set_option($streamContext, 'ssl', 'local_cert', $apnsCert);
    $apnsConnection = stream_socket_client('ssl://' . $apnsHost . ':' . $apnsPort, $error, $errorString, 60, STREAM_CLIENT_CONNECT, $streamContext);
    if ($apnsConnection == false) {
        echo "Failed to connect {$error} {$errorString}\n";
        //print "Failed to connect {$error} {$errorString}\n";
        return;
    } else {
        echo "Connection successful";       
    }
    $message = $msg;
    $payload['aps'] = array('alert' => $message, 'sound' => 'default');
    $payload = json_encode($payload);
    
    //$deviceToken = "dfe587d02a99d57fa7d785c1901409d408dfa920fa90890fbe3fed1fc090c7ee";
    //$deviceToken = $deviceToken;//"dfe587d02a99d57fa7d785c1901409d408dfa920fa90890fbe3fed1fc090c7ee";

    try {

        if ($message != "") {
            //echo $deviceToken;
            //echo $message;
            $apnsMessage = chr(0) . pack("n", 32) . pack('H*', str_replace(' ', '', $deviceToken)) . pack("n", strlen($payload)) . $payload;
            if (fwrite($apnsConnection, $apnsMessage)) {
                echo "true";
            } else {
                echo "false";
            }
//            /echo "<pre>";print_R($apnsMessage);die;
        }
    } catch (Exception $e) {
        echo 'Caught exception: ' . $e->getMessage() . "\n";
    }
}

function sendPushIphone($deviceToken, $message, $badge,$data) { 
    //error_reporting(E_ALL);
//    echo $deviceToken;die;
    
    //$apnsHost = 'gateway.sandbox.push.apple.com'; //dev
    $apnsHost = 'gateway.push.apple.com';            //production
    $apnsPort = '2195';
    //$apnsCert = 'ckDev.pem';//dev
    $apnsCert = 'vishnu_apns_distribution.pem';//prod
    $passPhrase = '';
    $streamContext = stream_context_create();
    stream_context_set_option($streamContext, 'ssl', 'local_cert', $apnsCert);
    $apnsConnection = stream_socket_client('ssl://' . $apnsHost . ':' . $apnsPort, $error, $errorString, 60, STREAM_CLIENT_CONNECT, $streamContext);
    
    if ($apnsConnection == false) {
        //echo "Failed to connect {$error} {$errorString}\n";
        //print "Failed to connect {$error} {$errorString}\n";
        return;
    } else {
        //echo "Connection successful";
//        echo $pushData;
    }
    //$data=json_decode($data);
    $payload['aps'] = array("alert" => $message,'badge'=>(int)$badge, "type" => "1","userinfo"=>$data);
    //$payload['aps'] = array();
    $payload = json_encode($payload);
    //print_r($payload);
    //$deviceToken = "dfe587d02a99d57fa7d785c1901409d408dfa920fa90890fbe3fed1fc090c7ee";
    //$deviceToken = $deviceToken;//"dfe587d02a99d57fa7d785c1901409d408dfa920fa90890fbe3fed1fc090c7ee";

    try {

        if ($message != "") {
            //echo $deviceToken;
            //echo $message;
            $apnsMessage = chr(0) . pack("n", 32) . pack('H*', str_replace(' ', '', $deviceToken)) . pack("n", strlen($payload)) . $payload;
            if (fwrite($apnsConnection, $apnsMessage)) {
                //echo "true";
            } else {
                //echo "false";
            }
        }
    } catch (Exception $e) {
        echo 'Caught exception: ' . $e->getMessage() . "\n";
    }
    //die;
}

function generatePush($deviceType, $deviceToken, $message) {
    if ($deviceType == 'android') {
         sendAndroidPush($deviceToken, $message);
    } else if ($deviceType == 'iOS') {
        sendPush($deviceToken, $message);
    } else {

        /*
         * do nothing
         */
    }
}

function getUserDetails($user_id){
    $ci=& get_instance();
    return $ci->db->where('id',$user_id)->get('tbl_users');
}

function getUserDetailsData($user_id){
    $ci=& get_instance();
    return $ci->db->where('id',$user_id)->get('tbl_users')->row_array();
}

function getAppointmentDetails($user_id){
    $ci=& get_instance();
    return $ci->db->where('ta.id',$user_id)->get('tbl_appointment as ta');
}

?>
