<?php
//include 'user_helper.php';
/**
     * @author revati Techahead
     * @access public
     * @use   helper for webservice security
     *  */
//echo "here";die;
$uri_array  =   explode('/', $_SERVER['REQUEST_URI']);
//print_r($uri_array);die;
if($uri_array[3]!='registration'&& $uri_array[3]!='verify_phone' && $uri_array[3]!='verify_code' && $uri_array[3]!='login' && $uri_array[3]!='home_feeds'){
    $check_version = getallheaders();
 $authkey       = $check_version['AuthenticationKey'];
//    echo $authkey;die;
checkToken($authkey);
}
//
// 
function getToken(){
    $ci=& get_instance();
//     mt_srand((double)microtime()*10000);//optional for php 4.2.0 and up.
        $charid = strtoupper(md5(uniqid(rand(), true)));
        $hyphen = chr(45);// "-"
        $uuid = // "{"
            substr($charid, 0, 8).$hyphen
            .substr($charid, 8, 4).$hyphen
            .substr($charid,12, 4).$hyphen
            .substr($charid,16, 4).$hyphen
            .substr($charid,20,12)
            ;// "}"
        
    
        return $uuid;
}


function assignToken($user_id){
    $ci=& get_instance();
}

function checkToken($authkey){
//    echo "here";die;
//    $access_token   =   $this->config->item('access_token');
//    echo $authkey;die;
    $ci=& get_instance();
    if($authkey!=''){
    $query  =   "select * from users where protected_token='$authkey' and expiry_date >= DATE(NOW())";

    $query_result   =   $ci->db->query($query);
    if($query_result->num_rows()=='0'){
//    print_r($query_result->num_rows());die;
            echo json_encode(array(
                "success"=>false,
                "status"=>'404',
                "message"=>'Invalid Token'
            ));
            exit();
        }
    }
    else{
        echo json_encode(array(
                "success"=>false,
                "status"=>'404',
                "message"=>'Invalid Token'
            ));
            exit();
    }
 
}

 function refreshToken($refresh_token) {
     $ci=& get_instance();
     $access_token  = getToken();
        $result =   $ci->db->query("select refreshToken($refresh_token,$access_token)  as result");
//        $result =   
        if($result['result']!='1'){
            echo json_encode(array(
                "success"=>false,
                "status"=>'404',
                "message"=>'Invalid Token'
            ));
            exit();
        }
        else{
            echo json_encode(array(
                "success"=>false,
                "status"=>'200',
                "message"=>'token refreshed'
            ));
            exit();
        }
    }

?>