<?php
function array_sort($arr, $index) {
    $b = array();
    $c = array();
    foreach ($arr as $key => $value) {
        $b[$key] = $value[$index];
    }
    arsort($b);
    foreach ($b as $key => $value) {
        $c[] = $arr[$key];
    }
    return $c;
}
if (!defined('BASEPATH'))
    exit('No direct script access allowed');

//pr($_SERVER);
function showUserImage($path, $imageName) {
    if (file_exists(FCPATH . $path) && $imageName != '') {
        return base_url() . $path;
    } else {
        return base_url() . 'assets/front/img/no-image.png';
    }
}

/*Calculate time difference from server time*/
function calculate_time_span($date)
{
      $mydate= date("Y-m-d H:i:s");
      $theDiff="";
      //echo $mydate;//2014-06-06 21:35:55
      $datetime1 = date_create($date);
      $datetime2 = date_create($mydate);
      $interval = date_diff($datetime1, $datetime2);
      //echo $interval->format('%s Seconds %i Minutes %h Hours %d days %m Months %y Year    Ago')."<br>";
      $min=$interval->format('%i');
      $sec=$interval->format('%s');
      $hour=$interval->format('%h');
      $mon=$interval->format('%m');
      $day=$interval->format('%d');
      $year=$interval->format('%y');
      
      if($interval->format('%i%h%d%m%y')=="00000")
      {
            return $sec." Seconds";
      }else if($interval->format('%h%d%m%y')=="0000"){
            return $min." Minutes";
      }else if($interval->format('%d%m%y')=="000"){
            return $hour." Hours";
      }else if($interval->format('%m%y')=="00"){
            return $day." Days";
      }else if($interval->format('%y')=="0"){
            return $mon." Months";
      }else{
            return $year." Years";
      }

}
/*
  Check if request is ajax or not
 */

function isAjax() {
    if (!empty($_SERVER['HTTP_X_REQUESTED_WITH']) && strtolower($_SERVER['HTTP_X_REQUESTED_WITH']) == 'xmlhttprequest') {
        return true;
    } else {
        return false;
    }
}

function getAdminSession() {
    $CI = & get_instance();
    return $CI->session->userdata('logged_session');
}

//function pr($array) {
//    echo "<pre>";
//    print_r($array);
//    echo "</pre>";
//}

function authAdminLogin() {
    $CI = & get_instance();
    if ($CI->session->userdata('logged_session')) {
        redirect(base_url() . 'dashboard');
        exit;
    }
}

function authAdmin() {
    $CI = & get_instance();
    if (!$CI->session->userdata('logged_session')) {
        redirect(base_url());
        exit;
    }
}

function loginSession() {
    $CI = & get_instance();
    return $CI->session->userdata('logged_session');
}

function user_id() {
    $CI = & get_instance();
    return $CI->session->userdata['logged_session'][0]->user_id;
}

function encrypt_decrypt($action, $string) {
    $output = false;
    $encrypt_method = "AES-256-CBC";
    $secret_key = ENCRYPTION_KEY;
    $secret_iv = 'This is my secret iv';
    // hash
    $key = hash('sha256', $secret_key);
    // iv - encrypt method AES-256-CBC expects 16 bytes - else you will get a warning
    $iv = substr(hash('sha256', $secret_iv), 0, 16);
    if ($action == 'encrypt') {
        $output = openssl_encrypt($string, $encrypt_method, $key, 0, $iv);
        $output = base64_encode($output);
    } else if ($action == 'decrypt') {
        $output = openssl_decrypt(base64_decode($string), $encrypt_method, $key, 0, $iv);
    }
    return $output;
}

function getSiteLogo() {
    return base_url() . 'assets/front/img/mail-logo.png';
}

function validateErrors() {
    $msg = '';
    if (validation_errors()) {
        $msg .= "<div class='ci_error_msg'>";
        $msg .= validation_errors();
        $msg .= "</div>";
        echo $msg;
    }
}

function _errors() {
    $CI = & get_instance();
    $CI->session->flashdata('error');
    $message = '';
    if ($CI->session->flashdata('ci_validate_errors')) {
        $message .= "<div class='ci_error_msg'>";
        $message .= $CI->session->flashdata('ci_validate_errors');
        $message .= "</div>";
    }
    if ($CI->session->flashdata('success')) {
        $message = '<div class="alert alert-success">
						<button aria-hidden="true" data-dismiss="alert" class="close" type="button">×</button>
						<i class="fa fa-check sign"></i><strong>Success!</strong> ' . $CI->session->flashdata('success') . '
					</div>';
    }

    if ($CI->session->flashdata('error')) {
        $message = '<div class="alert alert-danger">
						<button aria-hidden="true" data-dismiss="alert" class="close" type="button">×</button>
						<i class="fa fa-times-circle sign"></i><strong>Error!</strong> ' . $CI->session->flashdata('error') . '
					</div>';
    }
    return $message;
}

function cleanStr($input) {
    return $input = preg_replace("/[^a-zA-Z]+/", "", strtolower($input));
}

function cleanSpecial($string) {
    $string = str_replace(' ', '-', $string); // Replaces all spaces with hyphens.
    return preg_replace('/[^A-Za-z0-9\-]/', '', $string); // Removes special chars.
}

function dayDiff($date) {
    $now = time(); // or your date as well
    $your_date = strtotime($date);
    $datediff = $now - $your_date;
    return floor($datediff / (60 * 60 * 24));
}

function showDateTime($date) {
    $checkDate = dayDiff($date);
    $newDateTime = '';
    if ($checkDate == 0) {
        $newDateTime = date('h:i a', strtotime($date));
    } else {
        $newDateTime = date('m/d, h:i a', strtotime($date));
    }
    return $newDateTime;
}

function dateFormat($date) {
    return date("F d, Y", strtotime($date));
}

function timeElapsedString($time) {
    $time = time() - strtotime($time); // to get the time since that moment
    $tokens = array(
        31536000 => 'year',
        2592000 => 'month',
        604800 => 'week',
        86400 => 'day',
        3600 => 'hour',
        60 => 'minute',
        1 => 'second'
    );

    foreach ($tokens as $unit => $text) {
        if ($time < $unit)
            continue;
        $numberOfUnits = floor($time / $unit);
        return $numberOfUnits . ' ' . $text . (($numberOfUnits > 1) ? 's' : '') . ' ago';
    }
}

function ciPagination($paramsArr) {
    $CI = & get_instance();

    $config['base_url'] = $paramsArr['url'];
    $config['total_rows'] = $paramsArr['totalRecord'];
    $config['per_page'] = $paramsArr['perPage'];
    $config['num_links'] = 2;
    $config['use_page_numbers'] = TRUE;
    $config['page_query_string'] = TRUE;
    $config['query_string_segment'] = 'page';
    $config['first_link'] = '&laquo; First';
    $config['first_tag_open'] = '<li class="prev page">';
    $config['first_tag_close'] = '</li>';
    $config['last_link'] = 'Last &raquo;';
    $config['last_tag_open'] = '<li class="next page">';
    $config['last_tag_close'] = '</li>';
    $config['next_link'] = 'Next '; //&rarr;
    $config['next_tag_open'] = '<li class="next page">';
    $config['next_tag_close'] = '</li>';
    $config['prev_link'] = 'Previous'; //&larr; 
    $config['prev_tag_open'] = '<li class="prev page">';
    $config['prev_tag_close'] = '</li>';
    $config['cur_tag_open'] = '<li class="active"><a href="">';
    $config['cur_tag_close'] = '</a></li>';
    $config['num_tag_open'] = '<li class="page">';
    $config['num_tag_close'] = '</li>';
    $CI->pagination->initialize($config);

    return $CI->pagination->create_links();
}

function _mkDir($path) {
    if (!is_dir($path)) {
        mkdir($path, 0755, true);
        mkBlankFile($path . 'index.html');
    }
}

function mkBlankFile($fileName) {
    $myfile = fopen($fileName, "w");
    $txt = "403 Forbidden \n Directory access is forbidden.";
    fwrite($myfile, $txt);
    fclose($myfile);
}

function do_upload($con) {
    $CI = & get_instance();
    $config['file_name'] = time() . '_' . $_FILES[$con['fileName']]["name"];
    $config['upload_path'] = $con['path'];
    $config['allowed_types'] = $con['allowType'];
    $config['max_size'] = $con['maxSize'];
    //$config['max_width'] = '2000';
    //$config['max_height'] = '2000';
    $CI->load->library('upload', $config);
    $CI->upload->initialize($config);
    unset($config);
    if (!$CI->upload->do_upload($con['fileName'])) {
        return array('error' => $CI->upload->display_errors(), 'status' => 0);
    } else {
        return array('status' => 1, 'upload_data' => $CI->upload->data());
    }
}

function resize_image($con) {
    $CI = & get_instance();
    //$CI->image_lib->clear();
    $config['image_library'] = 'gd2';
    $config['source_image'] = $con['sourcePath'];
    $config['new_image'] = $con['desPath'];
    $config['quality'] = '100%';
    $config['create_thumb'] = TRUE;
    $config['maintain_ratio'] = true;
    $config['thumb_marker'] = '';
    $config['width'] = $con['w'];
    $config['height'] = $con['h'];
    $CI->load->library('image_lib', $config);
    $CI->image_lib->initialize($config);

    if ($CI->image_lib->resize()) {
        if (isset($con['removeSourceimage']) && $con['removeSourceimage'] == true) {
            unlink($con['sourcePath']);
            $CI->image_lib->clear();
        }
        return true;
    } else {
        return false;
    }
}

function _rmDir($path) {
    if (is_dir($path) === true) {
        $files = array_diff(scandir($path), array('.', '..'));
        foreach ($files as $file) {
            _rmDir(realpath($path) . '/' . $file);
        }
        return rmdir($path);
    } else if (is_file($path) === true) {
        return unlink($path);
    }
    return false;
}

function getInArray($array, $field) {
    $arr = array();
    foreach ($array as $val) {
        $arr[] = $val->$field;
    }
    return $arr;
}

function getAllUniversityList() {
    $CI = & get_instance();
    $CI->load->model('admin_university_model');
    return $universityArr = $CI->admin_university_model->getUniversity();
}

function universityDropDownHTML($params = "", $selectedArr = array(), $label = '') {
    $universityArr = getAllUniversityList();
    $selectHtml = "<select $params>";
    $selected = '';
    foreach ($universityArr as $key => $value) {
        if (!empty($selectedArr) && is_array($selectedArr)) {
            $selected = in_array($value->university_id, $selectedArr) ? 'selected' : '';
        }
        $selectHtml .= "<option value='$value->university_id' $selected>$value->university_name</option>";
    }
    $selectHtml .= "</select>";
    return $selectHtml;
}
function sendMailViaAdmin($toEmail, $subject, $mailContent, $attachment = ''){

    $CI =& get_instance();

    $emailConfig['mailtype'] = 'html';

    $emailConfig['charset'] = 'iso-8859-1';

    $CI->email->initialize($emailConfig);

    $CI->email->from(strtolower(ADMIN_EMAIL), SITE_NAME);

    $CI->email->to($toEmail);

    $CI->email->subject($subject);

    $CI->email->message($mailContent);

    if ( $attachment != '') {

        $CI->email->attach($attachment);

    }

    $send = $CI->email->send();



    if($send){

        return true;

    }else{

        return false;

    }

}

function sendPushNotificationAndroid($params) {
    //Google cloud messaging GCM-API url
    $gcmURL = 'https://android.googleapis.com/gcm/send';
    $registatoin_ids = array($params['deviceToken']);
    $message = array("m" => $params['message']);

    $fields = array(
        'registration_ids' => $registatoin_ids,
        'data' => $message,
    );
    // Update your Google Cloud Messaging API Key
    //define("GOOGLE_API_KEY", "AIzaSyANtImVzB49WpNnCfry1-bS7ZKero289Z0");
    
    $headers = array(
        'Authorization: key=' . GOOGLE_API_KEY,
        'Content-Type: application/json'
    );

    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, $gcmURL);
    curl_setopt($ch, CURLOPT_POST, true);
    curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt ($ch, CURLOPT_SSL_VERIFYHOST, 0);
    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
    curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($fields));
    $result = curl_exec($ch);
    curl_close($ch);
    return $result;
}
